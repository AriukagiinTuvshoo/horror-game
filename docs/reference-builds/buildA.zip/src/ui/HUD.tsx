import { useEffect, useRef, useState } from "react";
import {
  Battery, Coffee, Eye, Flashlight, Brain, FlaskConical, ChevronLeft, ChevronRight,
  Video, X, Lightbulb, MapPin, Trophy, ShieldAlert, Volume2, NotebookPen, Pause, Hand,
} from "lucide-react";
import type { HudSnapshot } from "@/game/engine";
import { MISSIONS, VOCAB, DOCS, PHARMACY_CODE, OFFICE_CODE, missionText, type Lang } from "@/game/content";
import { ROOMS, DOORS, GW, GH, cellToWorld } from "@/game/map";
import { tr, tl, ROOM_NAMES_MN } from "@/game/i18n";
import nurseImg from "@/assets/nurse.jpg";

export function formatClock(timeMin: number): string {
  const h = Math.floor(timeMin / 60);
  const m = Math.floor(timeMin % 60);
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${String(m).padStart(2, "0")} AM`;
}

export interface Toast { id: number; text: string; kind?: string }

const ITEM_NAMES: Record<string, string> = {
  wardkey: "Ward Keycard", morguekey: "Morgue Key", exitkey: "Exit Key",
  fuse: "Fuse", radiobattery: "Radio Battery", tape0: "TAPE 0 ★",
};
const ITEM_NAMES_MN: Record<string, string> = {
  wardkey: "Тасгийн карт", morguekey: "Моргийн түлхүүр", exitkey: "Гарах хаалганы түлхүүр",
  fuse: "Гал хамгаалагч", radiobattery: "Радионы батерей", tape0: "0-Р ХАЛЬС ★",
};

export function Hud({
  snap, subtitle, toasts, bannerMission, caughtKey, staticKey, showSubtitles, showMarker, lang, onAction,
}: {
  snap: HudSnapshot;
  subtitle: string | null;
  toasts: Toast[];
  bannerMission: number | null;
  caughtKey: number;
  staticKey: number;
  showSubtitles: boolean;
  showMarker: boolean;
  lang: Lang;
  onAction: (name: string) => void;
}) {
  const [showScare, setShowScare] = useState(false);
  const [showStatic, setShowStatic] = useState(false);
  const first = useRef(true);

  useEffect(() => {
    if (first.current) { first.current = false; return; }
    setShowScare(true);
    const t = setTimeout(() => setShowScare(false), 1200);
    return () => clearTimeout(t);
  }, [caughtKey]);

  useEffect(() => {
    if (staticKey === 0) return;
    setShowStatic(true);
    const t = setTimeout(() => setShowStatic(false), 380);
    return () => clearTimeout(t);
  }, [staticKey]);

  const mission = missionText(MISSIONS[snap.missionIdx], lang);
  const roomName = lang === "mn" ? ROOM_NAMES_MN[snap.room] ?? snap.room : snap.room;
  const chase = snap.enemyState === "chase";
  const lowSanity = snap.sanity < 35;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden font-sans2">
      {/* permanent vignette + danger pulses */}
      <div className="vignette absolute inset-0" />
      {(lowSanity || chase) && <div className="vignette-red pulse-red absolute inset-0" style={{ opacity: chase ? 0.9 : 0.5 }} />}
      {snap.hidden && <div className="locker-slats absolute inset-0" />}
      {showStatic && <div className="static-noise absolute inset-0 opacity-30 mix-blend-screen" />}

      {/* jumpscare */}
      {showScare && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black">
          <img src={nurseImg} alt="" className="jumpscare-pop h-full w-full object-cover" />
          <div className="absolute inset-0 bg-red-900/30 mix-blend-multiply" />
        </div>
      )}

      {/* top-left: clock + mission */}
      <div className="absolute left-3 top-3 sm:left-5 sm:top-4">
        <div className="flex items-center gap-3">
          <span className={`font-mono2 text-2xl font-semibold tracking-wider ${snap.hour >= 5 ? "text-red-400" : "text-[#cfe3f5]"}`} style={{ textShadow: "0 0 14px rgba(110,170,255,0.45)" }}>
            {formatClock(snap.timeMin)}
          </span>
          <span className="hidden items-center gap-1 font-mono2 text-[11px] text-[#7d93ad] sm:flex">
            <MapPin size={12} /> {roomName}
          </span>
          {snap.noisy && <span className="flex items-center gap-1 font-mono2 text-[11px] text-amber-400"><Volume2 size={12} /> {tr(lang, "loud")}</span>}
        </div>
        <div className="mt-1 max-w-[78vw] sm:max-w-md">
          <p className="font-mono2 text-[10px] tracking-[0.25em] text-[#7fb2e5]">{mission.title}</p>
          <p className="text-[13px] leading-5 text-[#d7e6f5]" style={{ textShadow: "0 1px 4px #000" }}>{mission.objective}</p>
        </div>
      </div>

      {/* top-right: score */}
      <div className="absolute right-3 top-3 text-right sm:right-5 sm:top-4">
        <p className="flex items-center justify-end gap-1.5 font-mono2 text-lg text-[#e8cf9a]">
          <Trophy size={15} /> {snap.score}
        </p>
        <p className="font-mono2 text-[10px] tracking-widest text-[#7d93ad]">
          {tr(lang, "evidenceHud")} {snap.evidence}/5 · {tr(lang, "wordsHud")} {snap.vocab.length} · ⌚ {snap.wristbands}/6
        </p>
        {snap.view !== "fp" && (
          <p className="mt-0.5 font-mono2 text-[10px] tracking-widest text-[#7fb2e5]">
            📷 {snap.view === "tp" ? (lang === "mn" ? "3-Р БИЕ" : "3RD PERSON") : (lang === "mn" ? "ТОЙРОГ КАМЕР" : "ORBIT CAM")} [V]
          </p>
        )}
        {snap.crouching && <p className="mt-0.5 font-mono2 text-[10px] tracking-widest text-[#9fe8b0]">{tr(lang, "crouched")}</p>}
        {snap.catches > 0 && (
          <p className="mt-0.5 flex items-center justify-end gap-1 font-mono2 text-[10px] text-red-400">
            <ShieldAlert size={11} /> {tr(lang, "caughtHud")} ×{snap.catches} / 3
          </p>
        )}
      </div>

      {/* compass strip */}
      {!snap.cameraMode && <Compass snap={snap} showMarker={showMarker} />}

      {/* detection eye */}
      {snap.detection > 0.04 && !snap.cameraMode && (
        <div className="absolute left-1/2 top-[16%] -translate-x-1/2 text-center">
          <Eye size={30} className={chase ? "text-red-500" : "text-amber-300"} style={{ opacity: 0.35 + snap.detection * 0.65, filter: "drop-shadow(0 0 8px rgba(255,60,40,0.7))" }} />
          <div className="mx-auto mt-1 h-1 w-20 bg-white/15">
            <div className={`h-full ${chase ? "bg-red-500" : "bg-amber-300"}`} style={{ width: `${snap.detection * 100}%` }} />
          </div>
          {chase && <p className="blink-soft mt-1 font-mono2 text-[11px] tracking-[0.3em] text-red-400">RUN</p>}
        </div>
      )}

      {/* mission banner */}
      {bannerMission !== null && (
        <div key={bannerMission} className="rise-in absolute left-1/2 top-[24%] w-full max-w-lg -translate-x-1/2 px-4 text-center">
          <p className="font-mono2 text-[10px] tracking-[0.4em] text-[#7fb2e5]">{tr(lang, "newObjective")}</p>
          <p className="mt-1 font-type text-3xl text-[#eaf4ff]" style={{ textShadow: "0 0 22px rgba(110,170,255,0.6), 0 2px 6px #000" }}>
            {missionText(MISSIONS[bannerMission], lang).title}
          </p>
          <p className="mt-1 text-sm text-[#b9cfe4]" style={{ textShadow: "0 1px 4px #000" }}>{missionText(MISSIONS[bannerMission], lang).objective}</p>
        </div>
      )}

      {/* crosshair + prompt */}
      {!snap.cameraMode && (
        <>
          <div className={`absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full ${snap.prompt ? "bg-[#ffd98a] shadow-[0_0_8px_#ffd98a]" : "bg-white/50"}`} />
          {snap.prompt && (
            <div className="absolute left-1/2 top-[58%] -translate-x-1/2 whitespace-nowrap border border-[#2b3d59] bg-black/70 px-3 py-1.5">
              <span className="mr-2 inline-block border border-[#5f83ad] bg-[#16233a] px-1.5 font-mono2 text-xs text-[#cfe3f5]">E</span>
              <span className="text-sm text-[#eaf4ff]">{tl(snap.prompt, lang)}</span>
            </div>
          )}
        </>
      )}

      {/* bottom-left: survival bars */}
      <div className="absolute bottom-3 left-3 w-44 sm:bottom-5 sm:left-5 sm:w-52">
        <Bar icon={<Brain size={13} />} label={tr(lang, "sanity")} value={snap.sanity} color={lowSanity ? "#e0342f" : "#7fb2e5"} />
        <Bar icon={<Flashlight size={13} />} label={snap.flashlightOn ? tr(lang, "lightOn") : tr(lang, "lightOff")} value={snap.battery} color={snap.battery < 20 ? "#e8b34b" : "#a8d89a"} />
        <Bar icon={<span className="font-mono2 text-[9px]">RUN</span>} label={tr(lang, "stamina")} value={snap.stamina} color="#5f748e" thin />
      </div>

      {/* bottom-right: consumables (clickable) */}
      <div className="pointer-events-auto absolute bottom-3 right-3 flex flex-col items-end gap-1.5 sm:bottom-5 sm:right-5">
        {snap.items.length > 0 && (
          <div className="mb-1 flex max-w-[46vw] flex-wrap justify-end gap-1">
            {snap.items.map((it) => (
              <span key={it} className="border border-[#4a3d1e] bg-[#171208]/85 px-1.5 py-0.5 font-mono2 text-[10px] text-[#e8cf9a]">
                {(lang === "mn" ? ITEM_NAMES_MN[it] : ITEM_NAMES[it]) ?? it}
              </span>
            ))}
          </div>
        )}
        <div className="flex gap-1.5">
          <InvBtn icon={<Battery size={15} />} count={snap.batteries} k="B" onClick={() => onAction("battery")} />
          <InvBtn icon={<Coffee size={15} />} count={snap.coffees} k="G" onClick={() => onAction("coffee")} />
          <InvBtn icon={<FlaskConical size={15} />} count={snap.vials} k="Q" onClick={() => onAction("throw")} />
        </div>
      </div>

      {/* toasts */}
      <div className="absolute right-3 top-24 flex w-64 flex-col gap-1.5 sm:right-5">
        {toasts.map((t) => (
          <div key={t.id} className={`toast-in border px-2.5 py-1.5 text-xs leading-4 ${
            t.kind === "warn" ? "border-red-900 bg-red-950/80 text-red-200"
            : t.kind === "vocab" ? "border-[#3f5a34] bg-[#101a0c]/85 text-[#b5dd9a]"
            : t.kind === "item" ? "border-[#4a3d1e] bg-[#171208]/85 text-[#e8cf9a]"
            : "border-[#223048] bg-[#0a0f16]/85 text-[#cfe3f5]"
          }`}>
            {t.text}
          </div>
        ))}
      </div>

      {/* subtitle */}
      {showSubtitles && subtitle && (
        <div className="absolute bottom-[13%] left-1/2 w-full max-w-2xl -translate-x-1/2 px-4 text-center">
          <span className="inline-block bg-black/65 px-3 py-1.5 text-[15px] leading-6 text-[#f2e9c9]">{subtitle}</span>
        </div>
      )}

      {/* CCTV overlay */}
      {snap.cameraMode && (
        <div className="absolute inset-0">
          <div className="scanlines absolute inset-0 opacity-70" />
          <div className="absolute left-4 top-16 font-mono2 text-sm text-[#9fe8b0]" style={{ textShadow: "0 0 8px rgba(80,255,140,.6)" }}>
            <p className="flex items-center gap-2"><Video size={15} /> {snap.camName}</p>
            <p className="mt-1 text-xs opacity-80">{formatClock(snap.timeMin)} · ST. MERCY SURVEILLANCE</p>
            {snap.camMotion && <p className="blink-soft mt-2 inline-block bg-red-700 px-2 py-0.5 text-xs font-bold text-white">{tr(lang, "camMotion")}</p>}
          </div>
          <div className="absolute right-4 top-16 flex items-center gap-2 font-mono2 text-xs text-red-400">
            <span className="blink-soft h-2.5 w-2.5 rounded-full bg-red-500" /> REC
          </div>
          <p className="absolute bottom-24 left-1/2 -translate-x-1/2 whitespace-nowrap font-mono2 text-[11px] text-[#9fe8b0]/80">
            {tr(lang, "camYouStand")}
          </p>
          <div className="pointer-events-auto absolute bottom-6 left-1/2 flex -translate-x-1/2 items-center gap-2">
            <button onClick={() => onAction("camPrev")} className="btn-ghost flex h-11 w-11 items-center justify-center rounded-full"><ChevronLeft /></button>
            <span className="min-w-36 text-center font-mono2 text-xs text-[#cfe3f5]">{snap.camIndex + 1} / 5</span>
            <button onClick={() => onAction("camNext")} className="btn-ghost flex h-11 w-11 items-center justify-center rounded-full"><ChevronRight /></button>
            <button onClick={() => onAction("camExit")} className="ml-2 flex h-11 items-center gap-1 border border-red-900 bg-red-950/70 px-4 font-mono2 text-xs text-red-200">
              <X size={14} /> {tr(lang, "camExit")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Compass({ snap, showMarker }: { snap: HudSnapshot; showMarker: boolean }) {
  const heading = -snap.yaw; // 0 = north (-z), increases toward east
  const wrap = (a: number) => {
    let x = (a + Math.PI) % (Math.PI * 2);
    if (x < 0) x += Math.PI * 2;
    return x - Math.PI;
  };
  const RANGE = 1.35; // visible half-range in radians
  const toX = (bearing: number) => (wrap(bearing - heading) / RANGE) * 50; // % from center
  const cardinals: [string, number][] = [["N", 0], ["E", Math.PI / 2], ["S", Math.PI], ["W", -Math.PI / 2]];
  let objX: number | null = null;
  let objDist = 0;
  let objPinned = false;
  if (snap.objectiveCell) {
    const ow = cellToWorld(snap.objectiveCell.gx, snap.objectiveCell.gy);
    const dx = ow.x - snap.px, dz = ow.z - snap.pz;
    objDist = Math.round(Math.hypot(dx, dz));
    const rel = wrap(Math.atan2(dx, -dz) - heading);
    objPinned = Math.abs(rel) > RANGE;
    objX = (Math.max(-RANGE, Math.min(RANGE, rel)) / RANGE) * 50;
  }
  return (
    <div className="absolute left-1/2 top-2.5 w-[240px] -translate-x-1/2 sm:w-[300px]">
      <div className="relative h-6 overflow-hidden border-b border-white/15 [mask-image:linear-gradient(90deg,transparent,#000_18%,#000_82%,transparent)]">
        {/* ticks every 15 degrees */}
        {Array.from({ length: 24 }).map((_, i) => {
          const b = (i * Math.PI) / 12;
          const x = toX(b);
          if (Math.abs(x) > 52) return null;
          return <span key={i} className="absolute top-3.5 h-1.5 w-px bg-white/30" style={{ left: `${50 + x}%` }} />;
        })}
        {cardinals.map(([label, b]) => {
          const x = toX(b);
          if (Math.abs(x) > 52) return null;
          return (
            <span key={label} className={`absolute top-0 -translate-x-1/2 font-mono2 text-[11px] font-semibold ${label === "N" ? "text-red-400" : "text-[#cfe3f5]"}`}
              style={{ left: `${50 + x}%`, textShadow: "0 1px 3px #000" }}>
              {label}
            </span>
          );
        })}
        {showMarker && objX !== null && (
          <span className="absolute top-[13px] -translate-x-1/2" style={{ left: `${50 + objX}%`, opacity: objPinned ? 0.45 : 1 }}>
            <span className="block h-2 w-2 rotate-45 bg-[#ffd98a] shadow-[0_0_7px_#ffd98a]" />
          </span>
        )}
        <span className="absolute left-1/2 top-0 h-2 w-px -translate-x-1/2 bg-[#ffd98a]" />
      </div>
      {showMarker && objX !== null && !objPinned && (
        <p className="mt-0.5 text-center font-mono2 text-[9px] tracking-widest text-[#ffd98a]/90">◆ {objDist}m</p>
      )}
    </div>
  );
}

function Bar({ icon, label, value, color, thin }: { icon: React.ReactNode; label: string; value: number; color: string; thin?: boolean }) {
  return (
    <div className={thin ? "mt-1" : "mt-1.5"}>
      <div className="flex items-center gap-1.5 font-mono2 text-[9px] tracking-widest text-[#8fa8c8]" style={{ textShadow: "0 1px 3px #000" }}>
        {icon} {label} <span className="ml-auto">{Math.round(value)}</span>
      </div>
      <div className={`mt-0.5 w-full bg-black/60 ${thin ? "h-1" : "h-1.5"}`}>
        <div className="h-full transition-[width] duration-200" style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: color, boxShadow: `0 0 8px ${color}` }} />
      </div>
    </div>
  );
}

function InvBtn({ icon, count, k, onClick }: { icon: React.ReactNode; count: number; k: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`relative flex h-11 w-11 items-center justify-center border ${count > 0 ? "border-[#2b3d59] bg-[#0d1624]/85 text-[#cfe3f5] hover:border-[#5f83ad]" : "border-[#1b2739] bg-black/50 text-[#41546e]"}`}
      title={`[${k}]`}
    >
      {icon}
      <span className="absolute -right-1 -top-1 bg-[#16233a] px-1 font-mono2 text-[10px] text-[#ffd98a]">{count}</span>
      <span className="absolute bottom-0 right-0.5 font-mono2 text-[8px] text-[#5f748e]">{k}</span>
    </button>
  );
}

// ----------------------------------------------------------------- notebook
export function NotebookPanel({
  snap, lang, onClose, onOpenDoc, onQuizReward, onHint,
}: {
  snap: HudSnapshot; lang: Lang; onClose: () => void; onOpenDoc: (id: string) => void;
  onQuizReward: (word: string) => void; onHint: () => void;
}) {
  const [tab, setTab] = useState<"mission" | "vocab" | "map" | "docs">("mission");
  const [showHint, setShowHint] = useState(false);
  const tabs = [
    { id: "mission" as const, label: tr(lang, "tabMission") },
    { id: "vocab" as const, label: `${tr(lang, "tabVocab")} (${snap.vocab.length})` },
    { id: "map" as const, label: tr(lang, "tabMap") },
    { id: "docs" as const, label: `${tr(lang, "tabDocs")} (${snap.docsRead.length})` },
  ];
  const curMission = missionText(MISSIONS[snap.missionIdx], lang);
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/75 p-3 backdrop-blur-[2px]">
      <div className="rise-in flex max-h-[88vh] w-full max-w-2xl flex-col border border-[#223048] bg-[#0a0f16]/97">
        <div className="flex items-center gap-1 border-b border-[#223048] px-3 pt-3">
          <span className="mr-2 hidden items-center gap-1.5 font-type text-sm text-[#e8dfc4] sm:flex"><NotebookPen size={15} /> {tr(lang, "notebook")}</span>
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`px-2.5 py-1.5 font-mono2 text-[11px] tracking-wider ${tab === t.id ? "bg-[#16233a] text-white" : "text-[#7d93ad] hover:text-[#cfe3f5]"}`}>
              {t.label}
            </button>
          ))}
          <button onClick={onClose} className="btn-ghost ml-auto mb-2 flex h-7 w-7 items-center justify-center rounded-full"><X size={14} /></button>
        </div>
        <div className="overflow-y-auto p-4 sm:p-5">
          {tab === "mission" && (
            <div>
              <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#7fb2e5]">{tr(lang, "curObjective")}</p>
              <p className="mt-1 font-type text-xl text-[#eaf4ff]">{curMission.title}</p>
              <p className="mt-1 text-sm leading-6 text-[#b9cfe4]">{curMission.objective}</p>
              <button onClick={() => { if (!showHint) { setShowHint(true); onHint(); } }} className="mt-3 flex items-center gap-2 text-xs text-[#e8b34b] hover:underline">
                <Lightbulb size={14} /> {tr(lang, "missionHint")}
              </button>
              {showHint && <p className="mt-2 border border-[#4a3d1e] bg-[#171208] p-3 text-sm text-[#e8cf9a]">{curMission.hint}</p>}
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <div className="border border-[#223048] p-3">
                  <p className="font-mono2 text-[10px] tracking-widest text-[#7d93ad]">{tr(lang, "notesCodes")}</p>
                  <ul className="mt-2 space-y-1 text-sm text-[#cfe3f5]">
                    <li>{tr(lang, "pharmacyCode")}: {snap.codePharmacyKnown ? <b className="font-mono2">{PHARMACY_CODE}</b> : <span className="text-[#5f748e]">{tr(lang, "codeUnknownA")}</span>}</li>
                    <li>{tr(lang, "officeCode")}: {snap.codeOfficeKnown ? <b className="font-mono2">{OFFICE_CODE}</b> : <span className="text-[#5f748e]">{tr(lang, "codeUnknownB")}</span>}</li>
                    <li>{tr(lang, "evidenceWord")}: <b>{snap.evidence}/5</b> · ⌚ {snap.wristbands}/6</li>
                    <li>{tr(lang, "shiftEnds")}</li>
                    <li><i>{tr(lang, "rule3")}</i></li>
                  </ul>
                </div>
                <div className="border border-[#223048] p-3">
                  <p className="font-mono2 text-[10px] tracking-widest text-[#7d93ad]">{tr(lang, "shiftProgress")}</p>
                  <ul className="mt-2 space-y-1 text-[13px]">
                    {MISSIONS.map((m, i) => (
                      <li key={m.title} className={i < snap.missionIdx ? "text-green-400 line-through opacity-70" : i === snap.missionIdx ? "text-[#ffd98a]" : "text-[#41546e]"}>
                        {i < snap.missionIdx ? "✓ " : i === snap.missionIdx ? "▸ " : "· "}{missionText(m, lang).title}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
          {tab === "vocab" && <VocabTab snap={snap} lang={lang} onQuizReward={onQuizReward} />}
          {tab === "map" && <FloorPlan snap={snap} lang={lang} />}
          {tab === "docs" && (
            <div className="grid gap-2">
              {DOCS.filter((d) => snap.docsRead.includes(d.id)).length === 0 && (
                <p className="text-sm text-[#7d93ad]">{tr(lang, "noDocs")}</p>
              )}
              {DOCS.filter((d) => snap.docsRead.includes(d.id)).map((d) => (
                <button key={d.id} onClick={() => onOpenDoc(d.id)} className="btn-ghost flex items-center justify-between px-3 py-2.5 text-left">
                  <span className="font-type text-sm">{lang === "mn" ? d.titleMn : d.title}</span>
                  {d.evidence && <span className="font-mono2 text-[10px] text-red-400">{tr(lang, "evidenceTag")}</span>}
                </button>
              ))}
              <p className="mt-2 text-xs text-[#5f748e]">{tr(lang, "rereadTip")}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function VocabTab({ snap, lang, onQuizReward }: { snap: HudSnapshot; lang: Lang; onQuizReward: (w: string) => void }) {
  const [quiz, setQuiz] = useState<{ word: string; options: string[]; answer: number } | null>(null);
  const [quizResult, setQuizResult] = useState<string | null>(null);
  const learnedWords = VOCAB.filter((v) => snap.vocab.includes(v.word));
  const defOf = (v: (typeof VOCAB)[number]) => (lang === "mn" ? v.defMn : v.def);
  const exOf = (v: (typeof VOCAB)[number]) => (lang === "mn" ? v.exampleMn : v.example);

  const startQuiz = () => {
    if (learnedWords.length < 3) return;
    const pick = learnedWords[(Math.random() * learnedWords.length) | 0];
    const wrong = VOCAB.filter((v) => v.word !== pick.word).sort(() => Math.random() - 0.5).slice(0, 2);
    const options = [defOf(pick), defOf(wrong[0]), defOf(wrong[1])].sort(() => Math.random() - 0.5);
    setQuiz({ word: pick.word, options, answer: options.indexOf(defOf(pick)) });
    setQuizResult(null);
  };

  return (
    <div>
      {learnedWords.length >= 3 && (
        <div className="mb-4 border border-[#223048] bg-[#0d1624] p-3">
          {!quiz ? (
            <button onClick={startQuiz} className="btn-ghost w-full py-2 font-mono2 text-xs tracking-wider">{tr(lang, "reviewQuiz")}</button>
          ) : (
            <div>
              <p className="text-sm text-[#cfe3f5]">{tr(lang, "whatMeans")} <b className="font-type text-base text-[#ffd98a]">“{quiz.word}”</b> {tr(lang, "whatMeans2")}</p>
              <div className="mt-2 grid gap-1.5">
                {quiz.options.map((op, i) => (
                  <button key={op} onClick={() => {
                    if (i === quiz.answer) { setQuizResult(tr(lang, "quizRight")); onQuizReward(quiz.word); }
                    else setQuizResult(tr(lang, "quizWrong"));
                  }} className="btn-ghost px-3 py-2 text-left text-[13px]">{op}</button>
                ))}
              </div>
              {quizResult && (
                <div className="mt-2 flex items-center justify-between">
                  <p className="text-xs text-[#9fe8b0]">{quizResult}</p>
                  <button onClick={startQuiz} className="text-xs text-[#7fb2e5] hover:underline">{tr(lang, "nextWord")}</button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      <div className="grid gap-2 sm:grid-cols-2">
        {VOCAB.map((v) => {
          const got = snap.vocab.includes(v.word);
          return (
            <div key={v.word} className={`border p-2.5 ${got ? "border-[#2b3d59] bg-[#0d1624]" : "border-[#16202e] bg-black/30 opacity-50"}`}>
              <p className="font-type text-[15px] text-[#eaf4ff]">{got ? v.word : "· · · · ·"} <span className="ml-1 font-sans2 text-[10px] italic text-[#7d93ad]">{got ? v.pos : ""}</span></p>
              {got ? (
                <>
                  <p className="mt-0.5 text-[12px] leading-4 text-[#b9cfe4]">{defOf(v)}</p>
                  <p className="mt-0.5 text-[11px] italic leading-4 text-[#6d84a0]">“{exOf(v)}”</p>
                </>
              ) : (
                <p className="mt-0.5 text-[11px] text-[#41546e]">{tr(lang, "hiddenWord")}</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function FloorPlan({ snap, lang }: { snap: HudSnapshot; lang: Lang }) {
  const S = 13;
  return (
    <div>
      <svg viewBox={`0 0 ${GW * S} ${GH * S}`} className="w-full border border-[#223048] bg-[#060a10]">
        {ROOMS.map((r) => (
          <g key={r.id}>
            <rect x={r.x1 * S} y={r.y1 * S} width={(r.x2 - r.x1 + 1) * S} height={(r.y2 - r.y1 + 1) * S}
              fill={r.id.includes("corr") || r.id === "spine" ? "#101b2a" : "#16233a"} stroke="#2b3d59" strokeWidth={0.6} />
            {r.x2 - r.x1 >= 3 && r.y2 - r.y1 >= 2 && (
              <text x={((r.x1 + r.x2 + 1) / 2) * S} y={((r.y1 + r.y2 + 1) / 2) * S} fill="#7d93ad" fontSize={8.5} textAnchor="middle" fontFamily="monospace">
                {(lang === "mn" ? ROOM_NAMES_MN[r.name] ?? r.name : r.name).toUpperCase()}
              </text>
            )}
          </g>
        ))}
        {DOORS.map((d) => (
          <rect key={d.id} x={d.gx * S + 2} y={d.gy * S + 2} width={S - 4} height={S - 4} fill={d.lock === "exit" ? "#e0342f" : d.lock !== "none" ? "#e8b34b" : "#3a5878"} />
        ))}
        <circle cx={(snap.playerCell.gx + 0.5) * S} cy={(snap.playerCell.gy + 0.5) * S} r={5} fill="#ffd98a" stroke="#000" strokeWidth={1}>
          <animate attributeName="r" values="4;6;4" dur="1.6s" repeatCount="indefinite" />
        </circle>
      </svg>
      <p className="mt-2 font-mono2 text-[10px] leading-4 text-[#7d93ad]">
        <span className="text-[#ffd98a]">●</span> <span className="text-[#e8b34b]">■</span> <span className="text-[#e0342f]">■</span> <span className="text-[#3a5878]">■</span> {tr(lang, "mapLegend")}
      </p>
      <p className="mt-1 text-xs text-[#5f748e]">{tr(lang, "curLocation")}: <b className="text-[#cfe3f5]">{lang === "mn" ? ROOM_NAMES_MN[snap.room] ?? snap.room : snap.room}</b>. {tr(lang, "mapNote")}</p>
    </div>
  );
}

// ------------------------------------------------------------ touch controls
export function TouchControls({
  onMove, onLook, onAction, sprint, setSprint, lang,
}: {
  onMove: (x: number, y: number) => void;
  onLook: (dx: number, dy: number) => void;
  onAction: (name: string) => void;
  sprint: boolean; setSprint: (b: boolean) => void;
  lang: Lang;
}) {
  const joyRef = useRef<HTMLDivElement>(null);
  const joyId = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });

  const joyMove = (e: React.PointerEvent) => {
    const el = joyRef.current;
    if (!el || joyId.current !== e.pointerId) return;
    const rect = el.getBoundingClientRect();
    let dx = e.clientX - (rect.left + rect.width / 2);
    let dy = e.clientY - (rect.top + rect.height / 2);
    const len = Math.hypot(dx, dy);
    const max = rect.width / 2 - 6;
    if (len > max) { dx = (dx / len) * max; dy = (dy / len) * max; }
    setKnob({ x: dx, y: dy });
    onMove(dx / max, dy / max);
  };

  return (
    <div className="absolute inset-0 z-[15]">
      {/* look area (right side) */}
      <div
        className="absolute bottom-0 right-0 top-0 w-[58%] touch-none"
        onPointerDown={(e) => { lookId.current = e.pointerId; lookLast.current = { x: e.clientX, y: e.clientY }; (e.target as HTMLElement).setPointerCapture(e.pointerId); }}
        onPointerMove={(e) => {
          if (lookId.current !== e.pointerId) return;
          onLook(e.clientX - lookLast.current.x, e.clientY - lookLast.current.y);
          lookLast.current = { x: e.clientX, y: e.clientY };
        }}
        onPointerUp={() => { lookId.current = null; }}
        onPointerCancel={() => { lookId.current = null; }}
      />
      {/* joystick */}
      <div
        ref={joyRef}
        className="absolute bottom-24 left-5 h-32 w-32 touch-none rounded-full border border-white/20 bg-white/5"
        onPointerDown={(e) => { joyId.current = e.pointerId; (e.target as HTMLElement).setPointerCapture(e.pointerId); joyMove(e); }}
        onPointerMove={joyMove}
        onPointerUp={() => { joyId.current = null; setKnob({ x: 0, y: 0 }); onMove(0, 0); }}
        onPointerCancel={() => { joyId.current = null; setKnob({ x: 0, y: 0 }); onMove(0, 0); }}
      >
        <div className="absolute left-1/2 top-1/2 h-14 w-14 rounded-full border border-white/30 bg-white/15" style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }} />
      </div>
      {/* buttons */}
      <div className="absolute bottom-24 right-4 flex touch-none flex-col items-end gap-2">
        <button onPointerDown={() => onAction("pause")} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-full"><Pause size={16} /></button>
        <button onPointerDown={() => onAction("notebook")} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-full"><NotebookPen size={16} /></button>
        <button onPointerDown={() => onAction("camera")} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-full" aria-label="Camera view"><Video size={16} /></button>
        <button onPointerDown={() => onAction("flashlight")} className="btn-ghost flex h-10 w-10 items-center justify-center rounded-full"><Flashlight size={16} /></button>
        <button
          onPointerDown={() => setSprint(!sprint)}
          className={`flex h-12 w-12 items-center justify-center rounded-full border font-mono2 text-[10px] ${sprint ? "border-amber-400 bg-amber-900/60 text-amber-200" : "btn-ghost"}`}
        >
          {tr(lang, "run")}
        </button>
        <button onPointerDown={() => onAction("crouch")} className="btn-ghost flex h-10 w-12 items-center justify-center rounded-full font-mono2 text-[9px]">
          {lang === "mn" ? "СУУХ" : "CROUCH"}
        </button>
        <button onPointerDown={() => onAction("interact")} className="flex h-16 w-16 items-center justify-center rounded-full border border-[#ffd98a]/60 bg-[#241b08]/80 text-[#ffd98a]">
          <Hand size={24} />
        </button>
      </div>
    </div>
  );
}
