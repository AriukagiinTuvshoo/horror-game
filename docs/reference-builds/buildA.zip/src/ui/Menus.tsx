import { useState } from "react";
import {
  Play, RotateCcw, Settings as SettingsIcon, BookOpenText, ScrollText, Trophy,
  ChevronLeft, Save, Home, Skull, DoorOpen, FileSearch, Sparkles, Volume2, Sun, MousePointer2,
  Captions, Mic, GraduationCap, Eye, Navigation, Waves, Languages, UserCog,
} from "lucide-react";
import {
  ENDINGS, CONTROLS_LIST, CONTROLS_LIST_MN, AVATARS,
  type Diff, type Settings, type EndingId, type Lang, type AvatarId,
} from "@/game/content";
import { tr } from "@/game/i18n";
import { formatClock } from "./HUD";
import corridorImg from "@/assets/corridor.jpg";
import nurseImg from "@/assets/nurse.jpg";

const L = (lang: Lang, en: React.ReactNode, mn: React.ReactNode): React.ReactNode => (lang === "mn" ? mn : en);

export interface ScoreEntry {
  name: string; score: number; ending: string; time: number; date: string;
}

export type MenuPage = "home" | "settings" | "howto" | "credits" | "scores";

const DIFF_INFO: { id: Diff; label: string; desc: string }[] = [
  { id: "beginner", label: "BEGINNER", desc: "Simple sentences, key words explained. The horror stays — the English is gentle." },
  { id: "intermediate", label: "INTERMEDIATE", desc: "Natural hospital English. Some reading between the lines required." },
  { id: "advanced", label: "ADVANCED", desc: "Dense clinical prose for confident readers. She respects that." },
];

function Shell({ children, img }: { children: React.ReactNode; img?: string }) {
  return (
    <div className="grain absolute inset-0 overflow-hidden bg-[#05070b]">
      <img src={img ?? corridorImg} alt="" className="absolute inset-0 h-full w-full object-cover opacity-45" />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/40 to-black/85" />
      <div className="vignette absolute inset-0" />
      <div className="scanlines absolute inset-0 opacity-60" />
      <div className="relative z-10 flex h-full flex-col items-center overflow-y-auto px-4 py-6">{children}</div>
    </div>
  );
}

export function TitleScreen({
  hasSave, scores, difficulty, avatar, lang, onDifficulty, onAvatar, onLang, onNew, onContinue, go,
}: {
  hasSave: boolean; scores: ScoreEntry[]; difficulty: Diff; avatar: AvatarId; lang: Lang;
  onDifficulty: (d: Diff) => void; onAvatar: (a: AvatarId) => void; onLang: (l: Lang) => void;
  onNew: () => void; onContinue: () => void;
  go: (p: MenuPage) => void;
}) {
  const [tab, setTab] = useState<"avatar" | "level">("avatar");
  return (
    <Shell>
      <div className="mt-2 w-full max-w-sm">
        <div className="grid grid-cols-2 gap-1 border border-[#223048] bg-black/50 p-1">
          {(["avatar", "level"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)}
              className={`py-1.5 font-mono2 text-[11px] tracking-wider ${tab === t ? "bg-[#16233a] text-white" : "text-[#7d93ad]"}`}>
              {t === "avatar" ? tr(lang, "chooseGuard") : tr(lang, "englishLevel")}
            </button>
          ))}
        </div>
      </div>

      {tab === "level" && (
        <div className="mt-3 w-full max-w-sm">
          <div className="grid grid-cols-3 gap-1.5">
            {DIFF_INFO.map((d) => (
              <button key={d.id} onClick={() => onDifficulty(d.id)}
                className={`border px-2 py-2 text-left transition ${difficulty === d.id ? "border-[#e8b34b] bg-[#241b08]/90" : "border-[#223048] bg-black/50 hover:border-[#5f83ad]"}`}>
                <span className={`font-mono2 text-[11px] tracking-wider ${difficulty === d.id ? "text-[#ffd98a]" : "text-[#cfe3f5]"}`}>{d.label}</span>
              </button>
            ))}
          </div>
          <p className="mt-1.5 min-h-8 text-center text-[11px] leading-4 text-[#8fa8c8]">
            {lang === "mn"
              ? { beginner: "Хялбаран үгээр товч, үгийн тайлбартай. Аймшиг хэвээр — хэл нь ээлжлэг.", intermediate: "Ердийн эмнэлгийн англи. Нэг доод мөч уншиж ойлгох шаардлагатай.", advanced: "Нүүдэл төв дээд түвшний эмнэлгийн бичиг. Тэр ч хүндэд хүнд." }[difficulty]
              : DIFF_INFO.find((d) => d.id === difficulty)?.desc}
          </p>
        </div>
      )}

      {tab === "avatar" && (
        <div className="mt-3 grid w-full max-w-sm grid-cols-2 gap-1.5">
          {AVATARS.map((a) => (
            <button key={a.id} onClick={() => onAvatar(a.id)}
              className={`border p-2 text-left transition ${avatar === a.id ? "border-[#e8b34b] bg-[#241b08]/90" : "border-[#223048] bg-black/50 hover:border-[#5f83ad]"}`}>
              <span className="flex items-center gap-1.5">
                <span className="h-3 w-3 shrink-0 rounded-full" style={{ background: `#${a.uniform.toString(16).padStart(6, "0")}`, boxShadow: `0 0 8px #${a.accent.toString(16).padStart(6, "0")}` }} />
                <span className={`font-mono2 text-[11px] ${avatar === a.id ? "text-[#ffd98a]" : "text-[#cfe3f5]"}`}>{a.name}</span>
              </span>
              <span className="mt-0.5 block text-[10px] text-[#8fa8c8]">{a.role[lang]}</span>
              <span className="mt-0.5 block text-[10px] leading-4 text-[#6d84a0]">{a.desc[lang]}</span>
            </button>
          ))}
        </div>
      )}

      <div className="mt-2 text-center sm:mt-4">
        <p className="font-mono2 text-[10px] tracking-[0.5em] text-[#7d93ad]">{tr(lang, "est")}</p>
        <h1 className="flicker-title mt-2 font-type text-4xl leading-tight text-[#eaf4ff] sm:text-6xl" style={{ textShadow: "0 0 30px rgba(110,170,255,0.5), 0 4px 10px #000" }}>
          {L(lang, <>THE LAST<br />NIGHT SHIFT</>, <>СҮҮЛИЙН<br />ЭЭЛЖ</>)}
        </h1>
        <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-[#b9cfe4]">{tr(lang, "tagline")}</p>
      </div>

      <div className="mt-4 grid w-full max-w-sm gap-2">
        <button onClick={onNew} className="group flex items-center justify-center gap-2 border border-[#e8b34b]/70 bg-[#241b08]/90 py-3.5 font-type text-lg text-[#ffd98a] transition hover:bg-[#33270d] hover:shadow-[0_0_24px_rgba(232,179,75,0.25)]">
          <Play size={18} /> {tr(lang, "newShift")}
        </button>
        <button onClick={onContinue} disabled={!hasSave} className="btn-ghost flex items-center justify-center gap-2 py-3 font-type text-base">
          <RotateCcw size={16} /> {tr(lang, "continueShift")} {hasSave ? "" : tr(lang, "noSave")}
        </button>
        <div className="grid grid-cols-5 gap-1.5">
          <MenuBtn icon={<SettingsIcon size={15} />} label={tr(lang, "settings")} onClick={() => go("settings")} />
          <MenuBtn icon={<BookOpenText size={15} />} label={tr(lang, "howto")} onClick={() => go("howto")} />
          <MenuBtn icon={<Trophy size={15} />} label={tr(lang, "scores")} onClick={() => go("scores")} />
          <MenuBtn icon={<ScrollText size={15} />} label={tr(lang, "credits")} onClick={() => go("credits")} />
          <button onClick={() => onLang(lang === "en" ? "mn" : "en")} className="btn-ghost flex flex-col items-center gap-1 py-2.5 font-mono2 text-[10px] tracking-wider">
            <Languages size={15} /> {lang === "en" ? "МОНГОЛ" : "ENGLISH"}
          </button>
        </div>
      </div>

      {scores.length > 0 && (
        <div className="mt-5 w-full max-w-sm border border-[#223048] bg-black/55 p-3">
          <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#e8cf9a]">{tr(lang, "prevGuards")}</p>
          {scores.slice(0, 3).map((s, i) => (
            <p key={i} className="mt-1 flex justify-between font-mono2 text-xs text-[#b9cfe4]">
              <span>{i + 1}. {s.name}</span><span>{s.score} · {s.ending}</span>
            </p>
          ))}
        </div>
      )}
      <p className="mt-auto pt-4 text-center font-mono2 text-[10px] leading-4 text-[#41546e]">{tr(lang, "footer")}</p>
    </Shell>
  );
}

function MenuBtn({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="btn-ghost flex flex-col items-center gap-1 py-2.5 font-mono2 text-[10px] tracking-wider">
      {icon} {label}
    </button>
  );
}

function BackBtn({ onClick, lang }: { onClick: () => void; lang: Lang }) {
  return (
    <button onClick={onClick} className="btn-ghost mb-4 flex items-center gap-1 self-start px-3 py-1.5 font-mono2 text-xs">
      <ChevronLeft size={14} /> {tr(lang, "back")}
    </button>
  );
}

export function SettingsPanel({
  settings, onChange, onBack,
}: {
  settings: Settings; onChange: (s: Settings) => void; onBack: () => void;
}) {
  const set = (patch: Partial<Settings>) => onChange({ ...settings, ...patch });
  const lang = settings.language;
  return (
    <Shell>
      <div className="w-full max-w-md">
        <BackBtn onClick={onBack} lang={lang} />
        <h2 className="font-type text-2xl text-[#eaf4ff]">{tr(lang, "settings")}</h2>
        <div className="mt-4 space-y-4 border border-[#223048] bg-black/60 p-4">
          <div>
            <p className="flex items-center gap-2 text-sm text-[#cfe3f5]"><Languages size={15} /> {tr(lang, "language")}</p>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {(["en", "mn"] as const).map((l) => (
                <button key={l} onClick={() => set({ language: l })}
                  className={`border px-2 py-2 font-mono2 text-[11px] ${lang === l ? "border-[#e8b34b] bg-[#241b08] text-[#ffd98a]" : "btn-ghost"}`}>
                  {l === "en" ? "ENGLISH" : "МОНГОЛ"}
                </button>
              ))}
            </div>
          </div>
          <SettingSlider icon={<Volume2 size={15} />} label={tr(lang, "volume")} value={settings.volume} min={0} max={1} step={0.05}
            fmt={(v) => `${Math.round(v * 100)}%`} onChange={(v) => set({ volume: v })} />
          <SettingSlider icon={<Sun size={15} />} label={tr(lang, "brightness")} value={settings.brightness} min={0.6} max={1.6} step={0.05}
            fmt={(v) => v.toFixed(2)} onChange={(v) => set({ brightness: v })} />
          <SettingSlider icon={<MousePointer2 size={15} />} label={tr(lang, "sensitivity")} value={settings.sensitivity} min={0.4} max={2.2} step={0.1}
            fmt={(v) => v.toFixed(1)} onChange={(v) => set({ sensitivity: v })} />
          <SettingSlider icon={<Eye size={15} />} label={tr(lang, "fov")} value={settings.fov} min={62} max={92} step={1}
            fmt={(v) => `${Math.round(v)}°`} onChange={(v) => set({ fov: v })} />
          <div>
            <p className="flex items-center gap-2 text-sm text-[#cfe3f5]"><Sparkles size={15} /> {tr(lang, "graphicsQ")}</p>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {(["high", "low"] as const).map((q) => (
                <button key={q} onClick={() => set({ graphics: q })}
                  className={`border px-2 py-2 font-mono2 text-[11px] ${settings.graphics === q ? "border-[#e8b34b] bg-[#241b08] text-[#ffd98a]" : "btn-ghost"}`}>
                  {q === "high" ? tr(lang, "gHigh") : tr(lang, "gLow")}
                </button>
              ))}
            </div>
          </div>
          <SettingToggle icon={<Captions size={15} />} label={tr(lang, "subtitles")} desc={tr(lang, "subtitlesD")} value={settings.subtitles} onChange={(v) => set({ subtitles: v })} />
          <SettingToggle icon={<Navigation size={15} />} label={tr(lang, "objMarker")} desc={tr(lang, "objMarkerD")} value={settings.objectiveMarker} onChange={(v) => set({ objectiveMarker: v })} />
          <SettingToggle icon={<Waves size={15} />} label={tr(lang, "headbob")} desc={tr(lang, "headbobD")} value={settings.headbob} onChange={(v) => set({ headbob: v })} />
          <SettingToggle icon={<Mic size={15} />} label={tr(lang, "voice")} desc={tr(lang, "voiceD")} value={settings.voice} onChange={(v) => set({ voice: v })} />
          <div>
            <p className="flex items-center gap-2 text-sm text-[#cfe3f5]"><GraduationCap size={15} /> {tr(lang, "englishLevel")}</p>
            <div className="mt-2 grid grid-cols-3 gap-1.5">
              {DIFF_INFO.map((d) => (
                <button key={d.id} onClick={() => set({ difficulty: d.id })}
                  className={`border px-2 py-2 font-mono2 text-[11px] ${settings.difficulty === d.id ? "border-[#e8b34b] bg-[#241b08] text-[#ffd98a]" : "btn-ghost"}`}>
                  {d.label}
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] text-[#7d93ad]">{tr(lang, "langNote")}</p>
          </div>
          <div>
            <p className="flex items-center gap-2 text-sm text-[#cfe3f5]"><UserCog size={15} /> {tr(lang, "chooseGuard")}</p>
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              {AVATARS.map((a) => (
                <button key={a.id} onClick={() => set({ avatar: a.id })}
                  className={`border px-2 py-2 font-mono2 text-[11px] ${settings.avatar === a.id ? "border-[#e8b34b] bg-[#241b08] text-[#ffd98a]" : "btn-ghost"}`}>
                  {a.name} · {a.role[lang]}
                </button>
              ))}
            </div>
          </div>
        </div>
        <p className="mt-3 text-center font-mono2 text-[10px] text-[#41546e]">{tr(lang, "settingsNote")}</p>
      </div>
    </Shell>
  );
}

function SettingSlider({ icon, label, value, min, max, step, fmt, onChange }: {
  icon: React.ReactNode; label: string; value: number; min: number; max: number; step: number;
  fmt: (v: number) => string; onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <span className="flex items-center gap-2 text-sm text-[#cfe3f5]">{icon} {label} <span className="ml-auto font-mono2 text-xs text-[#ffd98a]">{fmt(value)}</span></span>
      <input type="range" className="mt-1.5 w-full" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </label>
  );
}

function SettingToggle({ icon, label, desc, value, onChange }: {
  icon: React.ReactNode; label: string; desc: string; value: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="flex items-center gap-2 text-sm text-[#cfe3f5]">{icon} {label}</span>
      <span className="text-[11px] text-[#5f748e]">{desc}</span>
      <button onClick={() => onChange(!value)} className={`ml-auto h-6 w-11 shrink-0 rounded-full border transition ${value ? "border-green-700 bg-green-900" : "border-[#2b3d59] bg-[#101826]"}`}>
        <span className={`block h-4 w-4 rounded-full bg-white transition-transform ${value ? "translate-x-6" : "translate-x-1"}`} />
      </button>
    </div>
  );
}

export function HowToPlay({ onBack, lang }: { onBack: () => void; lang: Lang }) {
  const controls = lang === "mn" ? CONTROLS_LIST_MN : CONTROLS_LIST;
  return (
    <Shell>
      <div className="w-full max-w-lg">
        <BackBtn onClick={onBack} lang={lang} />
        <h2 className="font-type text-2xl text-[#eaf4ff]">{tr(lang, "howToSurvive")}</h2>
        <div className="mt-4 space-y-4">
          <div className="border border-[#223048] bg-black/60 p-4">
            <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#7fb2e5]">{tr(lang, "theShift")}</p>
            {lang === "mn" ? (
              <p className="mt-2 text-sm leading-6 text-[#b9cfe4]">
                Чи 1999 онд зөрчилгүй <i>явдал</i>-ын дараа хаагдсан Гэгээн Нинж эмнэлгийн шөнийн харуул. Мэндрийнхээ дугуйлж,
                даалгавруудыг дагаж, лоббигоор гар — гарах түлхүүртэй эсвэл өглөөний 6 цагт.
                Бүгдийг унш. Энэ эмнэлэгт <b className="text-[#ffd98a]">англи хэлийг ойлгох нь амьд үлдэх ур чадвар</b> байна:
                код өвчтөний түүхээр нуугдана, захиргаа тасарсан радио яриана, нэг дүрэм хамгийн чухал —
                <i> "Чиний ард байгаа зүйл чи түүнийг харж байх үедээ хөдөлж чадахгүй."</i>
              </p>
            ) : (
              <p className="mt-2 text-sm leading-6 text-[#b9cfe4]">
                You are the night guard at St. Mercy Hospital, closed since a mysterious <i>incident</i> in 1999.
                Complete your rounds, follow mission objectives, and leave through the Lobby — with the Exit Key, or when the clock reaches 6:00 AM.
                Read everything. In this hospital, <b className="text-[#ffd98a]">understanding English is a survival skill</b>: codes hide in patient charts,
                orders arrive as broken radio speech, and one rule matters most —
                <i> “The thing behind you cannot move while you are watching it.”</i>
              </p>
            )}
          </div>
          <div className="border border-[#223048] bg-black/60 p-4">
            <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#7fb2e5]">{tr(lang, "controls")}</p>
            <div className="mt-2 grid gap-x-4 gap-y-1.5 sm:grid-cols-2">
              {controls.map(([k, v]) => (
                <p key={k} className="flex gap-2 text-[13px]"><span className="min-w-20 shrink-0 border border-[#2b3d59] bg-[#101826] px-1.5 text-center font-mono2 text-[11px] text-[#ffd98a]">{k}</span><span className="text-[#b9cfe4]">{v}</span></p>
              ))}
            </div>
          </div>
          <div className="border border-[#4a2320] bg-[#160a0c]/70 p-4">
            <p className="font-mono2 text-[10px] tracking-[0.3em] text-red-400">{tr(lang, "herRules")}</p>
            <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm leading-6 text-[#e0c9c5]">
              {lang === "mn" ? (
                <>
                  <li>Тэр <b>хараа, дуу</b>-гаар андуурна. Гүйх, буруу код оруулах нь ЧАНГА.</li>
                  <li>Чийдэн танд харах тус болно — түүнд <b>чамайг</b> харах тус болно. Харанхуй нуугдлаа ч ухаан санааг ижилнэ.</li>
                  <li><b>Шүүгээ</b> нуугдлуулна — тэр орж байхыг хараагүй л бол. <b>Шилэн сав</b> (Q) түүнийг сатааруулна.</li>
                  <li>Хаалттай хаалга түүнийг улирлана. Түгжээтэй хаалга зогсоно. Аюулгүй байдлын өрөө ухаан санаа сэргээнэ.</li>
                  <li>Гурван удаа баригдсан — эсвэл ухаан санаа тэг бол чи <b>хэвтүүлэгдэнэ</b>. Бүрд.</li>
                </>
              ) : (
                <>
                  <li>She hunts by <b>sight and sound</b>. Sprinting and wrong keypad codes are LOUD.</li>
                  <li>Your flashlight helps you see — and helps her see <b>you</b>. Darkness hides you but eats your sanity.</li>
                  <li><b>Lockers</b> hide you, unless she watches you climb in. <b>Glass vials</b> (Q) lure her away.</li>
                  <li>Closed doors slow her down. Locked doors stop her. The Security Room restores sanity.</li>
                  <li>Caught three times — or sanity at zero — and you are <b>admitted</b>. Permanently.</li>
                </>
              )}
            </ul>
          </div>
          <div className="border border-[#223048] bg-black/60 p-4">
            <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#7fb2e5]">{tr(lang, "fourEndings")}</p>
            <p className="mt-2 text-sm leading-6 text-[#b9cfe4]">
              {lang === "mn" ? (
                <>
                  <b>Зугтсан</b> — амьд гарна · <b>Үнэн ил боллоо</b> — 3+ баримттай · <b>Хэвтүүлсэн</b> (муу төгсгөл) ·
                  бас <b className="text-[#ffd98a]">нууц төгсгөл</b> — бүх баримт, нууц хальс олж, тэр хэн <i>байсан</i>-ыг хэлж чаддаг харуулд.
                  Чиний шийдвүүд — нэг дуудлагатай Including — өглөө чинь хэнийг чинь тодорхойлно.
                </>
              ) : (
                <>
                  <b>Escape</b> with your life · <b>Truth Revealed</b> with 3+ evidence documents · <b>Admitted</b> (bad ending) ·
                  and a <b className="text-[#ffd98a]">secret ending</b> for guards who find every document, a hidden tape, and learn to say who she <i>was</i>.
                  Your decisions — including one phone call — decide which morning you get.
                </>
              )}
            </p>
          </div>
        </div>
      </div>
    </Shell>
  );
}

export function CreditsPanel({ onBack, lang }: { onBack: () => void; lang: Lang }) {
  return (
    <Shell>
      <div className="w-full max-w-md">
        <BackBtn onClick={onBack} lang={lang} />
        <h2 className="font-type text-2xl text-[#eaf4ff]">{tr(lang, "credits")}</h2>
        <div className="mt-4 border border-[#223048] bg-black/60 p-5 font-type text-[15px] leading-8 text-[#cfe3f5]">
          <p><span className="text-[#7d93ad]">Game</span> — THE LAST NIGHT SHIFT</p>
          <p><span className="text-[#7d93ad]">Hospital</span> — St. Mercy (est. 1974, closed 1999, never empty)</p>
          <p><span className="text-[#7d93ad]">Built with</span> — React · Three.js · Tailwind CSS · WebAudio</p>
          <p><span className="text-[#7d93ad]">Sound</span> — 100% procedural. No nurses were recorded.</p>
          <p><span className="text-[#7d93ad]">English curriculum</span> — M. Mercy, Head Nurse (deceased)</p>
          <p><span className="text-[#7d93ad]">Playtesting</span> — the previous guards (missing)</p>
          <p className="mt-3 text-[#8fa8c8]">Count the beds before you count the bodies.</p>
        </div>
      </div>
    </Shell>
  );
}

export function ScoresPanel({ scores, onBack, lang }: { scores: ScoreEntry[]; onBack: () => void; lang: Lang }) {
  return (
    <Shell>
      <div className="w-full max-w-md">
        <BackBtn onClick={onBack} lang={lang} />
        <h2 className="flex items-center gap-2 font-type text-2xl text-[#eaf4ff]"><Trophy size={20} className="text-[#e8cf9a]" /> {tr(lang, "guardRecords")}</h2>
        <div className="mt-4 border border-[#223048] bg-black/60 p-4">
          {scores.length === 0 && <p className="text-sm text-[#7d93ad]">No guard has finished a shift on this device. The book is empty. The book is hungry.</p>}
          {scores.map((s, i) => (
            <div key={i} className="flex items-baseline gap-2 border-b border-[#16202e] py-2 font-mono2 text-sm last:border-0">
              <span className="w-6 text-[#7d93ad]">{i + 1}.</span>
              <span className="text-[#eaf4ff]">{s.name}</span>
              <span className="ml-auto text-[#ffd98a]">{s.score}</span>
              <span className="w-24 text-right text-[11px] text-[#8fa8c8]">{s.ending}</span>
              <span className="w-16 text-right text-[11px] text-[#5f748e]">{formatClock(s.time)}</span>
            </div>
          ))}
        </div>
      </div>
    </Shell>
  );
}

export function PauseMenu({
  lang, onResume, onSettings, onRestart, onSaveQuit, onQuit,
}: {
  lang: Lang; onResume: () => void; onSettings: () => void; onRestart: () => void; onSaveQuit: () => void; onQuit: () => void;
}) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/75 backdrop-blur-[2px]">
      <div className="rise-in w-full max-w-xs border border-[#223048] bg-[#0a0f16]/97 p-5">
        <h3 className="text-center font-type text-2xl text-[#eaf4ff]">{tr(lang, "paused")}</h3>
        <p className="mt-1 text-center font-mono2 text-[10px] tracking-[0.3em] text-[#7d93ad]">{tr(lang, "pausedSub")}</p>
        <div className="mt-5 grid gap-2">
          <button onClick={onResume} className="flex items-center gap-2 border border-[#e8b34b]/60 bg-[#241b08] px-4 py-3 font-type text-[#ffd98a] transition hover:bg-[#33270d]"><Play size={16} /> {tr(lang, "resume")}</button>
          <button onClick={onSettings} className="btn-ghost flex items-center gap-2 px-4 py-2.5 text-sm"><SettingsIcon size={15} /> {tr(lang, "settings")}</button>
          <button onClick={onRestart} className="btn-ghost flex items-center gap-2 px-4 py-2.5 text-sm"><RotateCcw size={15} /> {tr(lang, "restartNight")}</button>
          <button onClick={onSaveQuit} className="btn-ghost flex items-center gap-2 px-4 py-2.5 text-sm"><Save size={15} /> {tr(lang, "saveQuit")}</button>
          <button onClick={onQuit} className="flex items-center gap-2 border border-red-900 bg-red-950/40 px-4 py-2.5 text-sm text-red-200 transition hover:bg-red-900/40"><Home size={15} /> {tr(lang, "abandon")}</button>
        </div>
      </div>
    </div>
  );
}

export function EndingScreen({
  endingId, lang, results, scores, saved, onSaveScore, onRestart, onMenu,
}: {
  endingId: EndingId; lang: Lang;
  results: { score: number; timeMin: number; catches: number; evidence: number; vocab: number; missions: number };
  scores: ScoreEntry[]; saved: boolean;
  onSaveScore: (name: string) => void; onRestart: () => void; onMenu: () => void;
}) {
  const e = ENDINGS[endingId];
  const [name, setName] = useState(() => localStorage.getItem("lns_name") ?? "GUARD");
  const Icon = endingId === "bad" ? Skull : endingId === "secret" ? Sparkles : endingId === "truth" ? FileSearch : DoorOpen;
  return (
    <Shell img={endingId === "bad" ? nurseImg : corridorImg}>
      <div className="w-full max-w-lg pt-4 text-center">
        <Icon size={40} className={`mx-auto ${endingId === "bad" ? "text-red-500" : endingId === "secret" ? "text-[#ffd98a]" : "text-[#7fb2e5]"}`} />
        <h2 className="flicker-title mt-3 font-type text-3xl text-[#eaf4ff] sm:text-4xl" style={{ textShadow: "0 0 24px rgba(110,170,255,0.5)" }}>
          {lang === "mn" ? e.titleMn : e.title}
        </h2>
        <p className="mt-1 font-mono2 text-xs tracking-[0.25em] text-[#e8cf9a]">{(lang === "mn" ? e.subMn : e.sub).toUpperCase()}</p>
        <p className="mx-auto mt-4 max-w-md text-[15px] leading-7 text-[#d7e6f5]" style={{ textShadow: "0 1px 4px #000" }}>{lang === "mn" ? e.textMn : e.text}</p>

        <div className="mx-auto mt-6 grid max-w-md grid-cols-3 gap-2 font-mono2">
          <Stat label={tr(lang, "statScore")} value={String(results.score)} big />
          <Stat label={tr(lang, "statSurvived")} value={formatClock(Math.min(results.timeMin, 359.9))} />
          <Stat label={tr(lang, "statCaught")} value={`×${results.catches}`} />
          <Stat label={tr(lang, "statEvidence")} value={`${results.evidence}/5`} />
          <Stat label={tr(lang, "statWords")} value={String(results.vocab)} />
          <Stat label={tr(lang, "statMissions")} value={`${results.missions}/9`} />
        </div>

        {!saved ? (
          <form
            className="mx-auto mt-5 flex max-w-md gap-2"
            onSubmit={(ev) => { ev.preventDefault(); onSaveScore(name.trim().toUpperCase().slice(0, 10) || "GUARD"); }}
          >
            <input
              value={name}
              onChange={(ev) => setName(ev.target.value)}
              placeholder={tr(lang, "yourName")}
              maxLength={10}
              className="min-w-0 flex-1 border border-[#2b3d59] bg-black/70 px-3 py-2.5 font-mono2 text-sm tracking-widest text-[#ffd98a] outline-none focus:border-[#e8b34b]"
            />
            <button type="submit" className="shrink-0 border border-[#e8b34b]/70 bg-[#241b08] px-4 font-mono2 text-xs text-[#ffd98a] transition hover:bg-[#33270d]">
              {tr(lang, "signLog")}
            </button>
          </form>
        ) : (
          <div className="mx-auto mt-5 max-w-md border border-[#223048] bg-black/55 p-3 text-left">
            <p className="font-mono2 text-[10px] tracking-[0.3em] text-[#e8cf9a]">{tr(lang, "guardRecords")}</p>
            {scores.slice(0, 5).map((s, i) => (
              <p key={i} className="mt-1 flex justify-between font-mono2 text-xs text-[#b9cfe4]">
                <span>{i + 1}. {s.name}</span><span>{s.score} · {s.ending}</span>
              </p>
            ))}
          </div>
        )}

        <div className="mx-auto mt-5 grid max-w-md grid-cols-2 gap-2">
          <button onClick={onRestart} className="flex items-center justify-center gap-2 border border-[#e8b34b]/70 bg-[#241b08] py-3 font-type text-[#ffd98a] transition hover:bg-[#33270d]">
            <RotateCcw size={15} /> {tr(lang, "anotherShift")}
          </button>
          <button onClick={onMenu} className="btn-ghost flex items-center justify-center gap-2 py-3 font-type">
            <Home size={15} /> {tr(lang, "mainMenu")}
          </button>
        </div>
      </div>
    </Shell>
  );
}

function Stat({ label, value, big }: { label: string; value: string; big?: boolean }) {
  return (
    <div className="border border-[#223048] bg-black/55 px-2 py-2.5">
      <p className={`text-[#eaf4ff] ${big ? "text-2xl text-[#ffd98a]" : "text-base"}`}>{value}</p>
      <p className="mt-0.5 text-[9px] tracking-[0.2em] text-[#7d93ad]">{label}</p>
    </div>
  );
}
