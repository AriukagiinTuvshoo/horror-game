import { useEffect, useMemo, useState } from "react";
import { X, Lightbulb, Volume2, CheckCheck, BookOpen, PhoneCall, Ghost, Skull } from "lucide-react";
import {
  ANNA_QUESTION, ANNA_QUESTION_MN, RADIO_PUZZLE, RADIO_PUZZLE_MN, VOCAB_MATCH_WORDS, docById, vocabByWord,
  type Diff, type Lang,
} from "@/game/content";
import { tr } from "@/game/i18n";

// ---------------------------------------------------------------- document
export function DocBody({
  docId, difficulty, lang, learned, onLearn,
}: {
  docId: string; difficulty: Diff; lang: Lang; learned: string[]; onLearn: (w: string) => void;
}) {
  const doc = docById(docId);
  const text = lang === "mn" ? doc.textMn : doc.text[difficulty] ?? doc.text.intermediate;
  const [selected, setSelected] = useState<string | null>(null);
  const [localLearned, setLocalLearned] = useState<Set<string>>(new Set());
  const isLearned = (w: string) => learned.includes(w) || localLearned.has(w);

  const parts = text.split(/(\[\[.+?\]\])/g);
  const sel = selected ? vocabByWord(selected) : null;

  return (
    <div>
      <div className="whitespace-pre-wrap font-type text-[15px] leading-7 sm:text-base">
        {parts.map((p, i) => {
          const m = p.match(/^\[\[(.+?)\]\]$/);
          if (!m) return <span key={i}>{p}</span>;
          const display = m[1];
          const key = display.toLowerCase();
          return (
            <button
              key={i}
              className={`vocab-word ${isLearned(key) ? "learned" : ""}`}
              onClick={() => {
                setSelected(key);
                if (!isLearned(key)) { setLocalLearned((s) => new Set(s).add(key)); onLearn(key); }
              }}
            >
              {display}
            </button>
          );
        })}
      </div>
      {sel ? (
        <div className="rise-in mt-4 border border-[#8a7a52] bg-[#efe6cb] p-3 text-[#23201a]">
          <div className="flex items-baseline gap-2">
            <span className="font-type text-lg font-bold">{sel.word}</span>
            <span className="text-xs italic opacity-70">{sel.pos}</span>
            <span className="ml-auto flex items-center gap-1 text-[11px] font-semibold text-green-800">
              <CheckCheck size={13} /> {tr(lang, "inNotebook")}
            </span>
          </div>
          <p className="mt-1 text-sm">{lang === "mn" ? sel.defMn : sel.def}</p>
          <p className="mt-1 text-sm italic opacity-80">“{lang === "mn" ? sel.exampleMn : sel.example}”</p>
        </div>
      ) : (
        <p className="mt-4 flex items-center gap-2 text-xs italic text-[#5a5240]">
          <BookOpen size={13} /> {tr(lang, "tapWords")}
        </p>
      )}
    </div>
  );
}

export function DocReader({
  docId, difficulty, lang, learned, onLearn, onClose,
}: {
  docId: string; difficulty: Diff; lang: Lang; learned: string[]; onLearn: (w: string) => void; onClose: () => void;
}) {
  const doc = docById(docId);
  return (
    <ModalShell onClose={onClose}>
      <div className="paper max-h-[82vh] w-full max-w-xl overflow-y-auto p-6 sm:p-8">
        <div className="mb-4 flex items-start justify-between gap-3">
          <h3 className="font-type text-lg tracking-wide">{lang === "mn" ? doc.titleMn : doc.title}</h3>
          {doc.evidence && (
            <span className="shrink-0 border border-red-900 px-2 py-0.5 font-type text-[11px] text-red-900">{tr(lang, "evidenceTag")}</span>
          )}
        </div>
        <DocBody docId={docId} difficulty={difficulty} lang={lang} learned={learned} onLearn={onLearn} />
        <button onClick={onClose} className="mt-6 w-full border border-[#6b5f43] bg-[#2a2519] py-2 font-type text-sm text-[#e8dfc4] transition hover:bg-[#3a3323]">
          {tr(lang, "putAway")}
        </button>
      </div>
    </ModalShell>
  );
}

export function ModalShell({ children, onClose }: { children: React.ReactNode; onClose?: () => void }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 p-3 backdrop-blur-[2px] sm:p-6">
      <div className="rise-in relative flex max-h-full justify-center">
        {onClose && (
          <button onClick={onClose} className="btn-ghost absolute -top-2 right-0 z-10 flex h-8 w-8 translate-x-1/2 items-center justify-center rounded-full" aria-label="Close">
            <X size={16} />
          </button>
        )}
        {children}
      </div>
    </div>
  );
}

// ------------------------------------------------------------ reading puzzle
export function ChartPuzzle({
  difficulty, lang, learned, onLearn, onAnswer, onHint, onClose,
}: {
  difficulty: Diff; lang: Lang; learned: string[]; onLearn: (w: string) => void;
  onAnswer: (idx: number) => boolean; onHint: () => void; onClose: () => void;
}) {
  const q = lang === "mn" ? ANNA_QUESTION_MN : ANNA_QUESTION[difficulty];
  const [wrong, setWrong] = useState<number | null>(null);
  const [showHint, setShowHint] = useState(false);
  return (
    <ModalShell onClose={onClose}>
      <div className="flex max-h-[86vh] w-full max-w-3xl flex-col gap-3 overflow-y-auto md:flex-row">
        <div className="paper flex-1 overflow-y-auto p-6">
          <h3 className="mb-3 font-type text-lg">{lang === "mn" ? "ӨВЧНИЙ ТҮҮХ — АННА РЕЙЕС" : "PATIENT CHART — ANNA REYES"}</h3>
          <DocBody docId="anna" difficulty={difficulty} lang={lang} learned={learned} onLearn={onLearn} />
        </div>
        <div className="w-full shrink-0 border border-[#223048] bg-[#0a0f16]/95 p-5 md:w-72">
          <p className="font-mono2 text-[11px] tracking-widest text-[#7d93ad]">{tr(lang, "readingCheck")}</p>
          <p className="mt-2 font-sans2 text-sm text-[#cfe3f5]">{q.q}</p>
          <div className="mt-4 grid gap-2">
            {q.options.map((op, i) => (
              <button
                key={op}
                onClick={() => { const ok = onAnswer(i); if (!ok) setWrong(i); }}
                className={`btn-ghost px-3 py-2.5 text-left font-mono2 text-lg tracking-[0.3em] ${wrong === i ? "!border-red-500 !text-red-400" : ""}`}
              >
                {op}
              </button>
            ))}
          </div>
          {wrong !== null && <p className="mt-3 text-xs text-red-400">{tr(lang, "wrongRustle")}</p>}
          <button
            onClick={() => { if (!showHint) { setShowHint(true); onHint(); } }}
            className="mt-4 flex items-center gap-2 text-xs text-[#e8b34b] hover:underline"
          >
            <Lightbulb size={14} /> {tr(lang, "explainEn")}
          </button>
          {showHint && <p className="mt-2 border border-[#4a3d1e] bg-[#171208] p-2 text-xs leading-5 text-[#e8cf9a]">{q.hint}</p>}
        </div>
      </div>
    </ModalShell>
  );
}

// ------------------------------------------------------------------- keypad
export function KeypadPuzzle({
  title, lang, codeHint, onSubmit, onClose,
}: {
  title: string; lang: Lang; codeHint?: string; onSubmit: (code: string) => boolean; onClose: () => void;
}) {
  const [code, setCode] = useState("");
  const [error, setError] = useState(0);
  const press = (d: string) => setCode((c) => (c.length < 4 ? c + d : c));
  const enter = () => {
    if (code.length < 4) return;
    const ok = onSubmit(code);
    if (!ok) { setError((e) => e + 1); setCode(""); }
  };
  return (
    <ModalShell onClose={onClose}>
      <div className="w-[300px] border border-[#223048] bg-[#0a0f16]/97 p-5 shadow-2xl">
        <p className="text-center font-mono2 text-[11px] tracking-[0.3em] text-[#7d93ad]">{title}</p>
        <div key={error} className={`mt-3 border bg-black px-3 py-3 text-center font-mono2 text-3xl tracking-[0.5em] ${error ? "animate-pulse border-red-700 text-red-400" : "border-[#2b3d59] text-[#9fe8b0]"}`}>
          {(code + "····").slice(0, 4)}
        </div>
        {codeHint ? (
          <p className="mt-2 text-center text-xs text-[#8fa8c8]">{tr(lang, "keypadFromNb")} <span className="font-mono2 text-[#cfe3f5]">{codeHint}</span></p>
        ) : (
          <p className="mt-2 text-center text-xs text-[#5f748e]">{tr(lang, "keypadUnknown")}</p>
        )}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⏎"].map((d) => (
            <button
              key={d}
              onClick={() => (d === "C" ? setCode("") : d === "⏎" ? enter() : press(d))}
              className={`py-3 font-mono2 text-lg ${d === "⏎" ? "border border-green-800 bg-green-950 text-green-300 hover:bg-green-900" : "btn-ghost"}`}
            >
              {d}
            </button>
          ))}
        </div>
        {error > 0 && <p className="mt-3 text-center text-xs text-red-400">{tr(lang, "keypadWrong")}</p>}
      </div>
    </ModalShell>
  );
}

// ------------------------------------------------------------- radio puzzle
export function RadioPuzzle({
  voiceOn, lang, onPlay, onAnswer, onHint, onClose,
}: {
  voiceOn: boolean; lang: Lang; onPlay: (done: () => void) => void;
  onAnswer: (idx: number) => boolean; onHint: () => void; onClose: () => void;
}) {
  const P = lang === "mn" ? RADIO_PUZZLE_MN : RADIO_PUZZLE;
  const [played, setPlayed] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [wrong, setWrong] = useState<number | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [, setTick] = useState(0);
  // animate the waveform while receiving
  useEffect(() => {
    if (!playing) return;
    const iv = window.setInterval(() => setTick((t) => t + 1), 140);
    return () => window.clearInterval(iv);
  }, [playing]);
  const play = () => {
    setPlaying(true);
    onPlay(() => { setPlaying(false); setPlayed(true); });
  };
  return (
    <ModalShell onClose={onClose}>
      <div className="w-full max-w-md border border-[#223048] bg-[#0a0f16]/97 p-6">
        <div className="flex items-center justify-between">
          <p className="font-mono2 text-[11px] tracking-[0.3em] text-[#7d93ad]">FREQUENCY 66.6 FM</p>
          <span className={`h-2 w-2 rounded-full ${playing ? "blink-soft bg-red-500" : "bg-[#2b3d59]"}`} />
        </div>
        <div className="mt-4 flex h-14 items-end justify-center gap-1 border border-[#223048] bg-black px-3 py-2">
          {Array.from({ length: 28 }).map((_, i) => (
            <div
              key={i}
              className="w-1.5 bg-[#57d977]"
              style={{
                height: playing ? `${18 + Math.abs(Math.sin(i * 1.7 + Date.now() / 160)) * 70}%` : "12%",
                transition: "height 0.15s",
                opacity: playing ? 1 : 0.35,
              }}
            />
          ))}
        </div>
        <p className="mt-3 min-h-10 text-center font-mono2 text-xs leading-5 text-[#8fb8d8]">
          {played || playing
            ? voiceOn
              ? "“… [static] … NOT the year we [static] … the year we [static] …”"
              : `“${RADIO_PUZZLE.spoken}”`
            : tr(lang, "radioDeadFreq")}
        </p>
        <button onClick={play} disabled={playing} className="btn-ghost mt-2 flex w-full items-center justify-center gap-2 py-3 font-mono2 text-sm">
          <Volume2 size={16} /> {playing ? tr(lang, "receiving") : played ? tr(lang, "playAgain") : tr(lang, "playTransmission")}
        </button>
        {!voiceOn && <p className="mt-2 text-center text-[11px] text-[#5f748e]">{tr(lang, "radioVoiceOff")}</p>}
        {played && (
          <div className="rise-in mt-5">
            <p className="font-sans2 text-sm text-[#cfe3f5]">{P.question}</p>
            <div className="mt-3 grid gap-2">
              {P.options.map((op, i) => (
                <button
                  key={op}
                  onClick={() => { const ok = onAnswer(i); if (!ok) setWrong(i); }}
                  className={`btn-ghost px-3 py-2.5 text-left font-sans2 text-sm ${wrong === i ? "!border-red-500 !text-red-400" : ""}`}
                >
                  {op}
                </button>
              ))}
            </div>
            {wrong !== null && <p className="mt-2 text-xs text-red-400">{tr(lang, "radioWrong")}</p>}
          </div>
        )}
        <button onClick={() => { if (!showHint) { setShowHint(true); onHint(); } }} className="mt-4 flex items-center gap-2 text-xs text-[#e8b34b] hover:underline">
          <Lightbulb size={14} /> {tr(lang, "explainEn")}
        </button>
        {showHint && <p className="mt-2 border border-[#4a3d1e] bg-[#171208] p-2 text-xs leading-5 text-[#e8cf9a]">{P.hint}</p>}
      </div>
    </ModalShell>
  );
}

// ------------------------------------------------------------ vocab matching
export function VocabMatchPuzzle({
  lang, onComplete, onStrike, onHint, onClose,
}: {
  lang: Lang; onComplete: () => void; onStrike: () => void; onHint: () => void; onClose: () => void;
}) {
  const defOf = (w: string) => { const v = vocabByWord(w)!; return lang === "mn" ? v.defMn : v.def; };
  const exOf = (w: string) => { const v = vocabByWord(w)!; return lang === "mn" ? v.exampleMn : v.example; };
  const defs = useMemo(() => {
    const arr = VOCAB_MATCH_WORDS.map((w) => ({ word: w, def: defOf(w) }));
    for (let i = arr.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [arr[i], arr[j]] = [arr[j], arr[i]]; }
    return arr;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang]);
  const [sel, setSel] = useState<string | null>(null);
  const [matched, setMatched] = useState<Set<string>>(new Set());
  const [flashWrong, setFlashWrong] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(false);

  const chooseDef = (word: string) => {
    if (!sel || matched.has(word)) return;
    if (sel === word) {
      const next = new Set(matched).add(word);
      setMatched(next);
      setSel(null);
      if (next.size === VOCAB_MATCH_WORDS.length) setTimeout(onComplete, 650);
    } else {
      setFlashWrong(word);
      onStrike();
      setTimeout(() => setFlashWrong(null), 600);
    }
  };

  return (
    <ModalShell onClose={onClose}>
      <div className="w-full max-w-lg border border-[#223048] bg-[#0a0f16]/97 p-6">
        <p className="font-mono2 text-[11px] tracking-[0.3em] text-[#7d93ad]">{tr(lang, "wordLock")}</p>
        <p className="mt-2 font-sans2 text-sm text-[#cfe3f5]">{tr(lang, "wordLockDesc")}</p>
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="grid gap-2">
            {VOCAB_MATCH_WORDS.map((w) => (
              <button
                key={w}
                disabled={matched.has(w)}
                onClick={() => setSel(w)}
                className={`px-3 py-3 text-left font-type text-base ${
                  matched.has(w)
                    ? "border border-green-800 bg-green-950/60 text-green-300"
                    : sel === w
                      ? "border border-[#e8b34b] bg-[#241b08] text-[#ffd98a]"
                      : "btn-ghost"
                }`}
              >
                {w} {matched.has(w) && "✓"}
              </button>
            ))}
          </div>
          <div className="grid gap-2">
            {defs.map((d) => (
              <button
                key={d.word}
                disabled={matched.has(d.word)}
                onClick={() => chooseDef(d.word)}
                className={`px-3 py-2 text-left font-sans2 text-[13px] leading-5 ${
                  matched.has(d.word)
                    ? "border border-green-800 bg-green-950/60 text-green-300"
                    : flashWrong === d.word
                      ? "border border-red-600 bg-red-950/60 text-red-300"
                      : "btn-ghost"
                }`}
              >
                {d.def}
              </button>
            ))}
          </div>
        </div>
        <button onClick={() => { if (!showHint) { setShowHint(true); onHint(); } }} className="mt-4 flex items-center gap-2 text-xs text-[#e8b34b] hover:underline">
          <Lightbulb size={14} /> {tr(lang, "explainWords")}
        </button>
        {showHint && (
          <div className="mt-2 border border-[#4a3d1e] bg-[#171208] p-2 text-xs leading-5 text-[#e8cf9a]">
            {VOCAB_MATCH_WORDS.map((w) => (
              <p key={w}><b>{w}</b> — {exOf(w)}</p>
            ))}
          </div>
        )}
      </div>
    </ModalShell>
  );
}

// ------------------------------------------------------------------ choices
export function ChoiceDialog({ id, lang, onChoose }: { id: string; lang: Lang; onChoose: (c: string) => void }) {
  const [asked, setAsked] = useState(false);
  if (id === "phone") {
    return (
      <ModalShell>
        <div className="w-full max-w-md border border-[#4a2320] bg-[#120a0c]/97 p-6">
          <p className="flex items-center gap-2 font-mono2 text-[11px] tracking-[0.3em] text-red-400">
            <PhoneCall size={14} /> {lang === "mn" ? "ЗАХИРЛЫН УТАС ЗВОН ДАРИГДАЖ БАЙНА" : "THE OFFICE PHONE RINGS"}
          </p>
          {lang === "mn" ? (
            <p className="mt-3 font-sans2 text-sm leading-6 text-[#e8d8d5]">
              “Харуул. Анхааралтай сонс. Тэр хавтас надаас ч амьд хүн хүрцийг амьд үлдээгээгүй.
              <b> Шатаа</b>, сейф дахь мөнгийг ав, зургаан цагтаа гарч энэ газрыг март. Эсвэл
              гадагш нь гарга — <i>тэр</i> чамайг хэзээ ч гарахгүй болгохоор хэлнэ.”
            </p>
          ) : (
            <p className="mt-3 font-sans2 text-sm leading-6 text-[#e8d8d5]">
              “Guard. Listen carefully. That folder has killed better people than you.
              <b> Burn it</b>, take the cash in the safe, walk out at six and forget this place.
              Or carry it out — and <i>she</i> will make certain you never leave.”
            </p>
          )}
          {asked && (
            <p className="rise-in mt-3 border-l-2 border-red-800 pl-3 text-sm italic text-[#c9a8a3]">
              {lang === "mn"
                ? "“Би хэн бэ гэж үзье? 1974 онд түүний жорд гарын үсэг зурсан тэр хүн. Тавь дахин тавь дахин арван таван жилийн турш St. Mercy-г цагаарчилж байна. Намайг ч цагаарчих хэрэгтэй болохгүй.”"
                : "“Who am I? I'm the man who signed her prescriptions in 1974. I've been erasing St. Mercy for fifty years. Don't make me erase you too.”"}
            </p>
          )}
          <div className="mt-5 grid gap-2">
            {!asked && (
              <button onClick={() => setAsked(true)} className="btn-ghost px-4 py-3 text-left text-sm">{lang === "mn" ? "“Та хэн бэ?”" : "“Who is this?”"}</button>
            )}
            <button onClick={() => onChoose("burn")} className="border border-red-900 bg-red-950/50 px-4 py-3 text-left text-sm text-red-200 transition hover:bg-red-900/50">
              {lang === "mn" ? "Баримтыг шатаа. Мөнгөө ав." : "Burn the evidence. Take the money."} <span className="opacity-60">{lang === "mn" ? "(Үнэн төгсгөлүүд хаагддана)" : "(locks out the Truth endings)"}</span>
            </button>
            <button onClick={() => onChoose("keep")} className="btn-ghost px-4 py-3 text-left text-sm">
              {lang === "mn" ? "Хавтасыг хадгала. Анна үнэнтэй тэнцэх ёстой." : "Keep the folder. Anna deserves the truth."} <span className="opacity-60">{lang === "mn" ? "(тэр ирнэ)" : "(she will come for it)"}</span>
            </button>
          </div>
        </div>
      </ModalShell>
    );
  }
  if (id === "whisper") {
    return (
      <ModalShell>
        <div className="w-full max-w-md border border-[#223048] bg-[#0a0f16]/97 p-6">
          <p className="flex items-center gap-2 font-mono2 text-[11px] tracking-[0.3em] text-[#7d93ad]">
            <Ghost size={14} /> {lang === "mn" ? "ХҮҮХЭД ШИВНЭНЭ" : "A CHILD WHISPERS"}
          </p>
          {lang === "mn" ? (
            <>
              <p className="mt-3 font-sans2 text-sm leading-6 text-[#cfe3f5]">Үгэн түгжээтэй шүүгээний дотроос жижиг дуу — есөн настай охин:</p>
              <p className="mt-2 font-type text-base text-[#e8dfc4]">“Надад хамт тоглоод… Би гялтран юм нуусан. Юмс ЮУ болохыг хэл — онгойдоно.”</p>
            </>
          ) : (
            <>
              <p className="mt-3 font-sans2 text-sm leading-6 text-[#cfe3f5]">From inside the word-lock cabinet, a small voice — a girl, maybe nine years old:</p>
              <p className="mt-2 font-type text-base text-[#e8dfc4]">“Play with me… I hid something shiny. Say what things ARE, and it opens.”</p>
            </>
          )}
          <div className="mt-5 grid gap-2">
            <button onClick={() => onChoose("follow")} className="btn-ghost px-4 py-3 text-left text-sm">
              {lang === "mn" ? "Хариул. Шүүгээг нээн үз." : "Answer her. Try the cabinet."} <span className="opacity-60">{lang === "mn" ? "(чимээ чимээ… анхааргал татдаг)" : "(your voice may attract… attention)"}</span>
            </button>
            <button onClick={() => onChoose("ignore")} className="btn-ghost px-4 py-3 text-left text-sm">
              {lang === "mn" ? "Аль ч үг хэлэхгүй. 3-р дүрэм: түүнд хариулж болохгүй." : "Say nothing. Rule 3: do not answer her."}
            </button>
          </div>
        </div>
      </ModalShell>
    );
  }
  // confront
  return (
    <ModalShell>
      <div className="w-full max-w-md border border-[#223048] bg-[#0a0f16]/97 p-6">
        <p className="flex items-center gap-2 font-mono2 text-[11px] tracking-[0.3em] text-[#e8b34b]">
          <Skull size={14} /> {lang === "mn" ? "9-Р ЦОГЦОС — НЭРЛЭХ ҮЕЙ" : "BODY 9 — THE NAMING"}
        </p>
        {lang === "mn" ? (
          <>
            <p className="mt-3 font-sans2 text-sm leading-6 text-[#cfe3f5]">
              Та үнэний бүх таван хэсгийг барьж байна. 0-р хальс хийхдээгүйгээр ямарныг чинь хувиргана.
              Чамайн өмнөх даавуу өндийнө. Буурна. Дээрдэх. Илүү хурдтай.
            </p>
            <p className="mt-2 font-type text-base text-[#e8dfc4]">“Зөв хэл, жаахан харуул аа. Би сувилагч <i>БАЙСАН</i>.”</p>
          </>
        ) : (
          <>
            <p className="mt-3 font-sans2 text-sm leading-6 text-[#cfe3f5]">
              You hold all five pieces of the truth, and Tape 0 turns slowly in your pocket.
              The sheet before you rises. Falls. Rises — faster.
            </p>
            <p className="mt-2 font-type text-base text-[#e8dfc4]">
              “Say it correctly, little keeper. I <i>WAS</i> a nurse.”
            </p>
          </>
        )}
        <div className="mt-5 grid gap-2">
          <button onClick={() => onChoose("name")} className="border border-[#6b5320] bg-[#241b08] px-4 py-3 text-left text-sm text-[#ffd98a] transition hover:bg-[#33270d]">
            {lang === "mn" ? "“Та Мариголд Mercy байсан. Ахлах сувилагч. Та тэднийг хамгаалсан.”" : "“You were Marigold Mercy. Head Nurse. You protected them.”"} <span className="opacity-70">{lang === "mn" ? "(түүний ээлжийг төгсөлнө — НУУЦ)" : "(end her shift — SECRET)"}</span>
          </button>
          <button onClick={() => onChoose("leave")} className="btn-ghost px-4 py-3 text-left text-sm">
            {lang === "mn" ? "Тэгээд ухар. Одоо биш." : "Step back. Not yet."}
          </button>
        </div>
      </div>
    </ModalShell>
  );
}
