// ---------------------------------------------------------------------------
// THE LAST NIGHT SHIFT — game engine (Three.js)
// Player controller, enemy AI, quests, doors, CCTV, survival systems,
// post-processing (bloom + film grade), parallax detail props, cinematics.
// ---------------------------------------------------------------------------

import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  GW, GH, CELL, WALL_H, ROOMS, DOORS, FURNITURE, LOCKERS, PICKUPS, INTERACTABLES,
  CAMERAS, WAYPOINTS, PLAYER_SPAWN, CHECKPOINT, ENEMY_SPAWN,
  cellToWorld, worldToCell, roomAt, buildGrid,
  type DoorDef, type PickupKind,
} from "./map";
import {
  MISSIONS, HOUR_LINES, HOUR_LINES_MN, PHARMACY_CODE, OFFICE_CODE, docById, avatarById,
  type Diff, type Settings, type EndingId, type Lang, type AvatarId,
} from "./content";
import { AudioEngine } from "./audio";

export type GameEvent =
  | { type: "mission"; index: number }
  | { type: "openPuzzle"; id: string }
  | { type: "openDoc"; id: string }
  | { type: "choice"; id: string }
  | { type: "subtitle"; text: string }
  | { type: "toast"; text: string; kind?: "item" | "vocab" | "warn" | "info" }
  | { type: "caught"; catches: number }
  | { type: "ending"; id: EndingId }
  | { type: "cameraMode"; on: boolean }
  | { type: "requestPause" }
  | { type: "openNotebook" }
  | { type: "checkpoint" }
  | { type: "staticBurst" };

export interface HudSnapshot {
  timeMin: number; hour: number; sanity: number; battery: number;
  batteries: number; coffees: number; vials: number; flashlightOn: boolean;
  score: number; missionIdx: number; room: string; detection: number;
  enemyState: string; prompt: string | null; promptAction: string | null;
  cameraMode: boolean; camIndex: number; camName: string; camMotion: boolean;
  hidden: boolean; stamina: number; items: string[]; evidence: number;
  evidenceIds: string[]; vocab: string[]; docsRead: string[];
  codePharmacyKnown: boolean; codeOfficeKnown: boolean; noisy: boolean;
  playerCell: { gx: number; gy: number }; catches: number; over: boolean;
  yaw: number; px: number; pz: number;
  objectiveCell: { gx: number; gy: number } | null;
  wristbands: number; crouching: boolean;
  view: string; lang: Lang;
}

export interface SaveData {
  v: number; timeMin: number; missionIdx: number; score: number; sanity: number;
  battery: number; batteries: number; coffees: number; vials: number;
  items: string[]; flags: Record<string, boolean>; evidence: string[];
  docsRead: string[]; vocab: string[]; quizzed: string[]; catches: number;
  takenPickups: string[]; unlockedDoors: string[]; player: { gx: number; gy: number; yaw: number };
  codes: { pharmacy: boolean; office: boolean }; difficulty: Diff;
}

interface DoorState {
  def: DoorDef; locked: boolean; open: boolean; open01: number;
  mesh: THREE.Mesh; horiz: boolean; slideDir: number; basePos: THREE.Vector3;
}

type EnemyState = "dormant" | "patrol" | "investigate" | "search" | "chase" | "watcher" | "banished";

const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

const GradeShader = {
  uniforms: {
    tDiffuse: { value: null },
    uTime: { value: 0 },
    uChroma: { value: 0.0012 },
    uGrain: { value: 0.05 },
    uVig: { value: 0.42 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() { vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime, uChroma, uGrain, uVig;
    varying vec2 vUv;
    float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
    void main() {
      vec2 d = vUv - 0.5;
      float r2 = dot(d, d);
      vec2 off = d * uChroma * (1.0 + r2 * 3.0);
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + off).r;
      col.g = texture2D(tDiffuse, vUv).g;
      col.b = texture2D(tDiffuse, vUv - off).b;
      float lum = dot(col, vec3(0.299, 0.587, 0.114));
      col = mix(col, vec3(lum), 0.14);                       // slight desaturation
      col *= vec3(0.94, 1.0, 1.08);                          // cold grade
      col *= 1.0 - uVig * smoothstep(0.12, 0.85, r2 * 1.9);  // vignette
      col += (hash(vUv * vec2(1920.0, 1080.0) + fract(uTime) * 7.0) - 0.5) * uGrain;
      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

export class Engine {
  readonly audio = new AudioEngine();
  private container: HTMLElement;
  private onEvent: (e: GameEvent) => void;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private cam: THREE.PerspectiveCamera;
  private cctv: THREE.PerspectiveCamera;
  private composer!: EffectComposer;
  private renderPass!: RenderPass;
  private bloomPass!: UnrealBloomPass;
  private gradePass!: ShaderPass;
  private raf = 0;
  private lastT = 0;
  private disposed = false;
  private frameCount = 0;

  // settings
  private settings: Settings | null = null;
  difficulty: Diff = "intermediate";
  touchMode = false;
  private baseFov = 74;
  private headbobOn = true;

  // world
  private grid = buildGrid();
  private heightGrid = new Float32Array(GW * GH);
  private doors: DoorState[] = [];
  private doorByCell = new Map<string, DoorState>();
  private pickupMeshes = new Map<string, THREE.Group>();
  private lockerMeshes: { gx: number; gy: number; door: THREE.Mesh }[] = [];
  private practicalLights: { light: THREE.PointLight; base: number; bad?: boolean; deadT: number; fixPos: THREE.Vector3 }[] = [];
  private monitorMats: THREE.MeshBasicMaterial[] = [];
  private monitorLiveMat: THREE.MeshBasicMaterial | null = null;
  private monitorStaticTex: THREE.Texture | null = null;
  private dust!: THREE.Points;
  private dustBase!: Float32Array;
  private effects: { mesh: THREE.Mesh; ttl: number }[] = [];
  private bursts: { points: THREE.Points; vel: Float32Array; ttl: number; life: number }[] = [];
  private clockHands: { hour: THREE.Mesh; min: THREE.Mesh }[] = [];
  private rainTexs: THREE.Texture[] = [];
  private swingPivot: THREE.Group | null = null;
  private lightShafts: { mat: THREE.MeshBasicMaterial; idx: number }[] = [];
  private wheelchair: THREE.Group | null = null;
  private wcWheels: THREE.Mesh[] = [];
  private wcRoll = -1;
  private wcSqueakT = 0;
  private previewRT!: THREE.WebGLRenderTarget;
  private previewCam!: THREE.PerspectiveCamera;
  private previewIdx = 0;
  private previewT = 0;

  // player
  private pPos = new THREE.Vector3();
  private vel = new THREE.Vector3();
  private yaw = 0; // facing north (-z)
  private pitch = 0;
  private keys = new Set<string>();
  private flashlight!: THREE.SpotLight;
  private phoneGlow!: THREE.PointLight;
  private bobT = 0;
  private shake = 0;
  private crouch = false;
  private eyeH = 1.62;
  private hiddenLocker: { gx: number; gy: number; door: THREE.Mesh } | null = null;
  private touchMove = { x: 0, y: 0 };
  private touchLook = { x: 0, y: 0 };
  private touchSprint = false;
  private stepTimer = 0;
  private intro = 0;
  // viewmodel
  private viewmodel!: THREE.Group;
  private vmLensMat!: THREE.MeshBasicMaterial;
  private vmConeMat!: THREE.MeshBasicMaterial;
  private vmSway = { x: 0, y: 0 };
  private lastYaw = 0;
  private lastPitch = 0;

  // enemy
  private enemy = new THREE.Group();
  private enemyParts: {
    headGroup?: THREE.Group; jaw?: THREE.Mesh; eyes?: THREE.Mesh[];
    armL?: THREE.Group; armR?: THREE.Group; skirt?: THREE.Mesh; torso?: THREE.Mesh;
  } = {};
  private eState: EnemyState = "dormant";
  private ePos = new THREE.Vector3();
  private eFacing = 0;
  private ePath: THREE.Vector3[] = [];
  private ePathIdx = 0;
  private eTarget = new THREE.Vector3();
  private eRepath = 0;
  private eWait = 0;
  private eDoorTimer = 0;
  private eStepTimer = 0;
  private eWalkPhase = 0;
  private eMoving = false;
  private detection = 0;
  private loseTimer = 0;
  private lastKnown = new THREE.Vector3();
  private banishTimer = 0;
  private graceTimer = 0;
  private chaseAnnounced = false;

  // game state
  running = false;
  paused = false;
  private over = false;
  private timeMin = 0;
  private lastHour = 0;
  private missionIdx = 0;
  private score = 0;
  private sanity = 100;
  private battery = 65;
  private batteries = 0;
  private coffees = 0;
  private vials = 0;
  private stamina = 100;
  private flashlightOn = true;
  private items = new Set<string>();
  private flags: Record<string, boolean> = {};
  private evidence = new Set<string>();
  private docsRead = new Set<string>();
  private vocab = new Set<string>();
  private quizzed = new Set<string>();
  private catches = 0;
  private codes = { pharmacy: false, office: false };
  private takenPickups = new Set<string>();
  private eventTimer = 9;
  private introTimers: { t: number; fn: () => void }[] = [];
  private vialTimers: { t: number; pos: THREE.Vector3 }[] = [];
  private promptTarget: { kind: string; id: string; label: string } | null = null;
  private cameraMode = false;
  private camIndex = 0;
  private camEventT = 0;
  private checkpointT = 0;
  private flickerBurst = 0;
  private catchLock = 0;

  // language, camera views, avatar
  lang: Lang = "en";
  private viewMode: "fp" | "tp" | "orbit" = "fp";
  private orbitAngle = 0;
  private tpCamPos = new THREE.Vector3();
  private tpInit = false;
  private avatar = new THREE.Group();
  private avatarParts: {
    legL?: THREE.Group; legR?: THREE.Group; armL?: THREE.Group; armR?: THREE.Group;
    headG?: THREE.Group; torso?: THREE.Mesh; hips?: THREE.Group;
  } = {};
  private avatarMats: {
    uniform?: THREE.MeshStandardMaterial; pants?: THREE.MeshStandardMaterial;
    skin?: THREE.MeshStandardMaterial; accent?: THREE.MeshStandardMaterial;
  } = {};
  private avatarExtras: Record<string, THREE.Object3D> = {};
  private avatarFacing = Math.PI;
  private avWalkPhase = 0;
  private perkStamina = 1;
  private perkRegen = 1;
  private perkNoise = 1;
  private perkCrouch = 1;
  private perkCoffee = 32;
  private onBlur = () => { this.keys.clear(); this.dragging = false; };

  constructor(container: HTMLElement, onEvent: (e: GameEvent) => void) {
    this.container = container;
    this.onEvent = onEvent;
    this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    container.appendChild(this.renderer.domElement);

    this.cam = new THREE.PerspectiveCamera(this.baseFov, container.clientWidth / container.clientHeight, 0.08, 90);
    this.cam.rotation.order = "YXZ";
    this.cam.layers.enable(1); // viewmodel layer
    this.scene.add(this.cam);
    this.cctv = new THREE.PerspectiveCamera(60, container.clientWidth / container.clientHeight, 0.1, 90);
    this.previewCam = new THREE.PerspectiveCamera(60, 4 / 3, 0.1, 90);
    this.previewRT = new THREE.WebGLRenderTarget(256, 192);

    // ---- post-processing chain
    const rt = new THREE.WebGLRenderTarget(container.clientWidth, container.clientHeight, {
      samples: 4, type: THREE.HalfFloatType,
    });
    this.composer = new EffectComposer(this.renderer, rt);
    this.composer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
    this.renderPass = new RenderPass(this.scene, this.cam);
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(container.clientWidth, container.clientHeight), 0.55, 0.55, 0.82);
    this.gradePass = new ShaderPass(GradeShader);
    this.composer.addPass(this.renderPass);
    this.composer.addPass(this.bloomPass);
    this.composer.addPass(this.gradePass);
    this.composer.addPass(new OutputPass());

    // subtle environment reflections for metals / wet floor sheen
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.13;

    for (const f of FURNITURE) this.heightGrid[f.gy * GW + f.gx] = Math.max(this.heightGrid[f.gy * GW + f.gx], f.h);
    for (const l of LOCKERS) this.heightGrid[l.gy * GW + l.gx] = 2.0;

    this.buildWorld();
    this.buildViewmodel();
    this.buildAvatar();
    this.resetPositions();
    this.bindInput();
    this.lastT = performance.now();
    const loop = (t: number) => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(loop);
      const dt = clamp((t - this.lastT) / 1000, 0, 0.05);
      this.lastT = t;
      this.tick(dt, t / 1000);
    };
    this.raf = requestAnimationFrame(loop);
  }

  // ============================================================ public API
  applySettings(s: Settings) {
    this.settings = s;
    this.lang = s.language;
    this.setAvatar(s.avatar);
    this.audio.setVolume(s.volume);
    this.audio.voiceEnabled = s.voice;
    this.renderer.toneMappingExposure = s.brightness;
    this.baseFov = s.fov;
    this.headbobOn = s.headbob;
    const high = s.graphics === "high";
    this.bloomPass.enabled = high;
    const pr = high ? Math.min(window.devicePixelRatio, 1.75) : 1;
    this.renderer.setPixelRatio(pr);
    this.composer.setPixelRatio(pr);
    this.onResize();
    if (this.flashlight) {
      this.flashlight.castShadow = high;
      const size = high ? 2048 : 1024;
      if (this.flashlight.shadow.mapSize.x !== size) {
        this.flashlight.shadow.mapSize.set(size, size);
        if (this.flashlight.shadow.map) { this.flashlight.shadow.map.dispose(); this.flashlight.shadow.map = null; }
      }
    }
  }

  newGame(diff: Diff) {
    this.difficulty = diff;
    this.resetState();
    this.resetPositions();
    this.running = true;
    this.paused = false;
    this.over = false;
    this.intro = 3.4;
    this.audio.init();
    this.emit({ type: "mission", index: 0 });
    this.introTimers = [
      { t: 1.4, fn: () => this.subtitle("St. Mercy Hospital. Closed since 1999. You are tonight's only guard.") },
      { t: 6.0, fn: () => this.subtitle("Twelve to six. Six hours. How hard can it be?") },
      { t: 10.0, fn: () => { this.audio.clang(); this.flickerBurst = 0.7; this.subtitle("…What was that? — Find the SECURITY ROOM. Sign in."); } },
    ];
    if (!this.touchMode) this.lockPointer();
  }

  loadGame(s: SaveData) {
    this.difficulty = s.difficulty;
    this.resetState();
    this.intro = 0;
    this.timeMin = s.timeMin; this.lastHour = Math.floor(s.timeMin / 60);
    this.missionIdx = s.missionIdx; this.score = s.score; this.sanity = s.sanity;
    this.battery = s.battery; this.batteries = s.batteries; this.coffees = s.coffees; this.vials = s.vials;
    this.items = new Set(s.items); this.flags = { ...s.flags };
    this.evidence = new Set(s.evidence); this.docsRead = new Set(s.docsRead);
    this.vocab = new Set(s.vocab); this.quizzed = new Set(s.quizzed);
    this.catches = s.catches; this.codes = { ...s.codes };
    this.takenPickups = new Set(s.takenPickups);
    for (const id of this.takenPickups) { const m = this.pickupMeshes.get(id); if (m) m.visible = false; }
    for (const d of this.doors) if (s.unlockedDoors.includes(d.def.id)) d.locked = false;
    const safe = this.cellBlockedForPlayer(s.player.gx, s.player.gy) ? CHECKPOINT : s.player;
    const w = cellToWorld(safe.gx, safe.gy);
    this.pPos.set(w.x, 1.62, w.z); this.yaw = s.player.yaw; this.pitch = 0;
    if (this.missionIdx === 7 && this.flags.powerCut && !this.flags.breakerDone) {
      this.startWatcher();
    } else if (this.timeMin >= 60) {
      this.teleportEnemy(31, 8); this.eState = "patrol"; this.enemy.visible = true; this.pickPatrolTarget();
    } else {
      this.teleportEnemy(ENEMY_SPAWN.gx, ENEMY_SPAWN.gy); this.eState = "dormant";
      this.enemy.visible = !this.flags.camEventDone;
    }
    this.running = true; this.paused = false; this.over = false;
    this.audio.init();
    this.emit({ type: "mission", index: this.missionIdx });
    this.subtitle("Shift resumed. She remembers you.");
    if (!this.touchMode) this.lockPointer();
  }

  serialize(): SaveData {
    const c = worldToCell(this.pPos.x, this.pPos.z);
    return {
      v: 1, timeMin: this.timeMin, missionIdx: this.missionIdx, score: this.score,
      sanity: this.sanity, battery: this.battery, batteries: this.batteries,
      coffees: this.coffees, vials: this.vials, items: [...this.items],
      flags: { ...this.flags }, evidence: [...this.evidence], docsRead: [...this.docsRead],
      vocab: [...this.vocab], quizzed: [...this.quizzed], catches: this.catches,
      takenPickups: [...this.takenPickups],
      unlockedDoors: this.doors.filter((d) => !d.locked && d.def.lock !== "none").map((d) => d.def.id),
      player: { gx: clamp(c.gx, 1, GW - 2), gy: clamp(c.gy, 1, GH - 2), yaw: this.yaw },
      codes: { ...this.codes }, difficulty: this.difficulty,
    };
  }

  getResults() {
    return {
      score: this.score, timeMin: this.timeMin, catches: this.catches,
      evidence: this.evidence.size, vocab: this.vocab.size, missions: this.missionIdx,
    };
  }

  setPaused(b: boolean) {
    this.paused = b;
    if (b) { this.audio.setHeartbeat(0); this.audio.setBreath(0); this.audio.stopSpeak(); if (document.pointerLockElement) document.exitPointerLock(); }
    else if (this.running && !this.over && !this.cameraMode && !this.touchMode) this.lockPointer();
  }

  lockPointer() {
    try {
      const el = this.renderer.domElement;
      const p = el.requestPointerLock() as unknown as Promise<void> | undefined;
      if (p && typeof p.catch === "function") p.catch(() => { /* browser cooldown */ });
    } catch { /* noop */ }
  }

  private wristbandCount(): number {
    return PICKUPS.filter((p) => p.kind === "wristband" && this.takenPickups.has(p.id)).length;
  }

  private objectiveCell(): { gx: number; gy: number } | null {
    if (this.over) return null;
    const doorLocked = (id: string) => this.doors.find((d) => d.def.id === id)?.locked ?? false;
    switch (this.missionIdx) {
      case 0: return { gx: 28, gy: 19 };
      case 1: return this.items.has("fuse") ? { gx: 33, gy: 19 } : { gx: 6, gy: 2 };
      case 2: return { gx: 30, gy: 19 };
      case 3: return { gx: 4, gy: 11 };
      case 4: return doorLocked("d_pharmacy") ? { gx: 23, gy: 6 } : { gx: 23, gy: 3 };
      case 5: return { gx: 29, gy: 4 };
      case 6:
        if (doorLocked("d_office")) return { gx: 25, gy: 14 };
        if (!this.docsRead.has("folder")) return { gx: 25, gy: 11 };
        if (!this.flags.keysTaken) return { gx: 26, gy: 12 };
        return { gx: 25, gy: 11 };
      case 7: return { gx: 12, gy: 12 };
      case 8: return { gx: 18, gy: 25 };
      default: return null;
    }
  }

  getSnapshot(): HudSnapshot {
    const c = worldToCell(this.pPos.x, this.pPos.z);
    const room = roomAt(c.gx, c.gy);
    return {
      timeMin: this.timeMin, hour: Math.floor(this.timeMin / 60), sanity: this.sanity,
      battery: this.battery, batteries: this.batteries, coffees: this.coffees, vials: this.vials,
      flashlightOn: this.flashlightOn && this.battery > 0, score: this.score,
      missionIdx: this.missionIdx, room: room?.name ?? "—", detection: this.detection,
      enemyState: this.eState, prompt: this.promptTarget?.label ?? null,
      promptAction: this.promptTarget ? "E" : null,
      cameraMode: this.cameraMode, camIndex: this.camIndex,
      camName: CAMERAS[this.camIndex]?.name ?? "", camMotion: this.camSeesEnemy(),
      hidden: !!this.hiddenLocker, stamina: this.stamina, items: [...this.items],
      evidence: this.evidence.size, evidenceIds: [...this.evidence], vocab: [...this.vocab],
      docsRead: [...this.docsRead], codePharmacyKnown: this.codes.pharmacy,
      codeOfficeKnown: this.codes.office, noisy: this.isSprinting() && this.vel.length() > 2,
      playerCell: c, catches: this.catches, over: this.over,
      yaw: this.yaw, px: this.pPos.x, pz: this.pPos.z,
      objectiveCell: this.objectiveCell(),
      wristbands: this.wristbandCount(), crouching: this.crouch,
      view: this.viewMode, lang: this.lang,
    };
  }

  // ---- commands from UI --------------------------------------------------
  action(name: string) {
    if (!this.running || this.over) return;
    this.intro = 0;
    if (this.cameraMode) {
      if (name === "camPrev") this.switchCam(-1);
      if (name === "camNext") this.switchCam(1);
      if (name === "camExit" || name === "interact") this.exitCameraMode();
      return;
    }
    switch (name) {
      case "interact": this.doInteract(); break;
      case "flashlight": this.toggleFlashlight(); break;
      case "throw": this.throwVial(); break;
      case "battery": this.swapBattery(); break;
      case "coffee": this.drinkCoffee(); break;
      case "notebook": this.emit({ type: "openNotebook" }); break;
      case "crouch": this.crouch = !this.crouch; break;
      case "camera": this.cycleView(); break;
      case "avatar": if (this.settings) this.setAvatar(this.settings.avatar); break;
    }
  }

  setTouchMove(x: number, y: number) { this.touchMove.x = x; this.touchMove.y = y; }
  addTouchLook(dx: number, dy: number) { this.touchLook.x += dx; this.touchLook.y += dy; }
  setTouchSprint(b: boolean) { this.touchSprint = b; }

  learnWord(word: string): boolean {
    const w = word.toLowerCase();
    if (this.vocab.has(w)) return false;
    this.vocab.add(w);
    this.addScore(25);
    this.emit({ type: "toast", text: `Vocabulary learned: "${w}" +25`, kind: "vocab" });
    return true;
  }

  quizReward(word: string) {
    if (this.quizzed.has(word)) return;
    this.quizzed.add(word);
    this.addScore(15);
  }

  hintUsed() { this.addScore(-25); }

  onDocClosed(id: string) {
    if (id === "folder" && !this.flags.phoneDone && this.running && !this.over) {
      this.flags.phoneRing = true;
      this.audio.phoneRing();
      setTimeout(() => { if (this.running && !this.over) this.emit({ type: "choice", id: "phone" }); }, 1200);
    }
  }

  resolvePuzzle(id: string, ok: boolean) {
    if (!ok) {
      this.audio.fail();
      this.sanity = Math.max(1, this.sanity - 4);
      this.emitNoise(this.pPos, 13);
      this.emit({ type: "toast", text: "Wrong. Somewhere, something heard that.", kind: "warn" });
      return;
    }
    this.audio.success();
    this.addScore(75);
    if (id === "chart") {
      this.flags.chartSolved = true;
      this.codes.pharmacy = true;
      this.grantEvidence("anna");
      this.docsRead.add("anna");
      this.emit({ type: "toast", text: `Pharmacy code noted: ${PHARMACY_CODE}`, kind: "item" });
      if (this.missionIdx === 3) this.advanceMission();
      this.checkpoint();
    } else if (id === "radio") {
      this.flags.radioSolved = true;
      this.codes.office = true;
      this.emit({ type: "toast", text: `Office code noted: the year it closed — ${OFFICE_CODE}`, kind: "item" });
      if (this.missionIdx === 5) this.advanceMission();
      this.checkpoint();
    } else if (id === "cabinet") {
      this.flags.cabinetSolved = true;
      this.items.add("tape0");
      this.addScore(100);
      this.emit({ type: "toast", text: "Found: TAPE 0 (secret)", kind: "item" });
      this.checkpoint();
      setTimeout(() => this.openDocument("tape0"), 350);
    }
  }

  tryKeypad(doorId: string, code: string): boolean {
    const door = this.doors.find((d) => d.def.id === doorId);
    if (!door) return false;
    const expected = door.def.lock === "keypadPharmacy" ? PHARMACY_CODE : OFFICE_CODE;
    if (code === expected) {
      door.locked = false; door.open = true;
      this.audio.unlock(); this.audio.door();
      this.addScore(50);
      this.checkpoint();
      return true;
    }
    this.audio.keypadBeep(false);
    this.emitNoise(this.pPos, 13);
    this.sanity = Math.max(1, this.sanity - 2);
    return false;
  }

  makeChoice(id: string, choice: string) {
    if (id === "phone") {
      this.flags.phoneDone = true;
      if (choice === "burn") {
        this.flags.burned = true;
        this.evidence.delete("folder");
        this.addScore(150);
        this.subtitle("You burn the folder. The safe clicks open: cash, and quiet. She… approves.");
        this.emit({ type: "toast", text: "Blood money +150. The truth is ash.", kind: "warn" });
      } else {
        this.audio.stinger();
        this.shake = 0.5;
        this.subtitle("\"Then she will keep you, keeper.\" The line dies. So do the lights.");
      }
      this.flags.powerCut = true;
      this.flickerBurst = 1.6;
      this.audio.breaker();
      if (this.missionIdx === 6) this.advanceMission();
      this.startWatcher();
      this.checkpoint();
    } else if (id === "whisper") {
      this.flags.whisperDone = true;
      if (choice === "follow") {
        this.subtitle("A giggle, from inside the word-lock cabinet. \"Say what things ARE…\"");
        this.emitNoise(this.pPos, 12);
      } else {
        this.subtitle("You do not answer. The giggling stops — disappointed.");
      }
    } else if (id === "confront") {
      if (choice === "name") {
        this.flags.confronted = true;
        this.finishGame("secret");
      } else {
        this.subtitle("Not yet. You step back from Body 9. Its chest rises — once.");
      }
    }
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("mousemove", this.onMouseMove);
    window.removeEventListener("mousedown", this.onMouseDown);
    window.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("pointerlockchange", this.onLockChange);
    this.audio.stopSpeak();
    this.composer?.dispose();
    this.previewRT?.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container)
      this.container.removeChild(this.renderer.domElement);
  }

  // ============================================================ state setup
  private resetState() {
    this.timeMin = 0; this.lastHour = 0; this.missionIdx = 0; this.score = 0;
    this.sanity = 100; this.battery = 65; this.batteries = 0; this.coffees = 0; this.vials = 0;
    this.stamina = 100; this.flashlightOn = true; this.items.clear(); this.flags = {};
    this.evidence.clear(); this.docsRead.clear(); this.vocab.clear(); this.quizzed.clear();
    this.catches = 0; this.codes = { pharmacy: false, office: false };
    this.takenPickups.clear(); this.detection = 0; this.cameraMode = false;
    this.hiddenLocker = null; this.introTimers = []; this.vialTimers = [];
    this.vel.set(0, 0, 0); this.crouch = false; this.eyeH = 1.62; this.wcRoll = -1;
    for (const [, m] of this.pickupMeshes) m.visible = true;
    for (const d of this.doors) {
      d.locked = d.def.lock !== "none"; d.open = false; d.open01 = 0;
      d.mesh.position.copy(d.basePos);
    }
    for (const pl of this.practicalLights) pl.deadT = 0;
    if (this.wheelchair) {
      const w = cellToWorld(3, 15);
      this.wheelchair.position.set(w.x, 0, w.z - 0.4);
      this.wheelchair.rotation.set(0, -Math.PI / 2, 0);
    }
    if (this.monitorLiveMat && this.monitorStaticTex) {
      this.monitorLiveMat.map = this.monitorStaticTex;
      this.monitorLiveMat.color.setRGB(0.5, 0.6, 0.55);
      this.monitorLiveMat.needsUpdate = true;
    }
    this.viewMode = "fp";
    this.tpInit = false;
    this.enemy.visible = true;
  }

  private resetPositions() {
    const w = cellToWorld(PLAYER_SPAWN.gx, PLAYER_SPAWN.gy);
    this.pPos.set(w.x, 1.62, w.z);
    this.yaw = 0; this.pitch = 0;
    this.teleportEnemy(ENEMY_SPAWN.gx, ENEMY_SPAWN.gy);
    this.eState = "dormant";
    this.eFacing = Math.PI / 2;
  }

  private teleportEnemy(gx: number, gy: number) {
    const w = cellToWorld(gx, gy);
    this.ePos.set(w.x, 0, w.z);
    this.ePath = [];
  }

  private emit(e: GameEvent) { this.onEvent(e); }
  private subtitle(text: string) { this.emit({ type: "subtitle", text }); }
  private addScore(n: number) { this.score = Math.max(0, this.score + n); }
  private checkpoint() { this.emit({ type: "checkpoint" }); }

  private advanceMission() {
    if (this.missionIdx < MISSIONS.length - 1) {
      this.missionIdx++;
      this.addScore(100);
      this.audio.success();
      this.emit({ type: "mission", index: this.missionIdx });
      this.emit({ type: "toast", text: `Mission complete +100 — ${MISSIONS[this.missionIdx].title}`, kind: "info" });
    }
  }

  private syncMission() {
    let guard = 0;
    while (guard++ < 9) {
      const m = this.missionIdx;
      if (m === 0 && this.flags.signedIn) this.advanceMission();
      else if (m === 1 && this.flags.camsOnline) this.advanceMission();
      else if (m === 2 && this.flags.camEventDone) this.advanceMission();
      else if (m === 3 && this.flags.chartSolved) this.advanceMission();
      else if (m === 4 && this.items.has("radiobattery")) this.advanceMission();
      else if (m === 5 && this.flags.radioSolved) this.advanceMission();
      else if (m === 6 && this.flags.phoneDone) this.advanceMission();
      else if (m === 7 && this.flags.breakerDone) this.advanceMission();
      else break;
    }
  }

  private grantEvidence(id: string) {
    if (!this.evidence.has(id)) {
      this.evidence.add(id);
      this.addScore(150);
      this.emit({ type: "toast", text: `Evidence secured (${this.evidence.size}/5) +150`, kind: "item" });
    }
  }

  private openDocument(id: string) {
    const doc = docById(id);
    if (!this.docsRead.has(id)) {
      this.docsRead.add(id);
      this.addScore(10);
      if (doc.evidence) this.grantEvidence(id);
    }
    this.audio.ui();
    this.emit({ type: "openDoc", id });
  }

  // ============================================================ world build
  private canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D, w: number, h: number) => void): THREE.CanvasTexture {
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const g = c.getContext("2d")!;
    draw(g, w, h);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4;
    return t;
  }

  // derive a tangent-space normal map from a grayscale height canvas
  private normalFromHeight(src: HTMLCanvasElement, strength = 2.2): THREE.CanvasTexture {
    const w = src.width, h = src.height;
    const sctx = src.getContext("2d")!;
    const srcData = sctx.getImageData(0, 0, w, h).data;
    const out = document.createElement("canvas"); out.width = w; out.height = h;
    const octx = out.getContext("2d")!;
    const img = octx.createImageData(w, h);
    const heightAt = (x: number, y: number) => {
      const xi = (x + w) % w, yi = (y + h) % h;
      const i = (yi * w + xi) * 4;
      return (srcData[i] * 0.3 + srcData[i + 1] * 0.59 + srcData[i + 2] * 0.11) / 255;
    };
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const dx = (heightAt(x - 1, y) - heightAt(x + 1, y)) * strength;
      const dy = (heightAt(x, y - 1) - heightAt(x, y + 1)) * strength;
      const inv = 1 / Math.hypot(dx, dy, 1);
      const i = (y * w + x) * 4;
      img.data[i] = (dx * inv * 0.5 + 0.5) * 255;
      img.data[i + 1] = (dy * inv * 0.5 + 0.5) * 255;
      img.data[i + 2] = (inv * 0.5 + 0.5) * 255;
      img.data[i + 3] = 255;
    }
    octx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(out);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    return t;
  }

  private makeSurface(
    size: number,
    draw: (g: CanvasRenderingContext2D, s: number) => void,
    normalStrength = 2.0,
  ): { map: THREE.CanvasTexture; normalMap: THREE.CanvasTexture } {
    const c = document.createElement("canvas"); c.width = c.height = size;
    const g = c.getContext("2d")!;
    draw(g, size);
    const map = new THREE.CanvasTexture(c);
    map.wrapS = map.wrapT = THREE.RepeatWrapping;
    map.colorSpace = THREE.SRGBColorSpace;
    map.anisotropy = 4;
    const normalMap = this.normalFromHeight(c, normalStrength);
    return { map, normalMap };
  }

  private buildWorld() {
    this.scene.background = new THREE.Color(0x030409);
    this.scene.fog = new THREE.FogExp2(0x04060a, 0.03);

    const wallSurf = this.makeSurface(512, (g, s) => {
      // two-tone hospital wall: pale top, institutional teal wainscot
      g.fillStyle = "#7d8fa0"; g.fillRect(0, 0, s, s * 0.58);
      g.fillStyle = "#3f5c5c"; g.fillRect(0, s * 0.58, s, s * 0.42);
      g.fillStyle = "#22333a"; g.fillRect(0, s * 0.565, s, s * 0.03);
      g.fillStyle = "#141d24"; g.fillRect(0, s * 0.93, s, s * 0.07);
      // tile grid on lower half
      g.strokeStyle = "rgba(10,18,20,0.5)"; g.lineWidth = 2;
      for (let x = 0; x <= 8; x++) { g.beginPath(); g.moveTo(x * s / 8, s * 0.58); g.lineTo(x * s / 8, s); g.stroke(); }
      for (let y = 0; y <= 3; y++) { g.beginPath(); g.moveTo(0, s * 0.58 + y * s * 0.14); g.lineTo(s, s * 0.58 + y * s * 0.14); g.stroke(); }
      // subtle block lines up top
      g.strokeStyle = "rgba(40,52,66,0.35)";
      for (let x = 0; x <= 4; x++) { g.beginPath(); g.moveTo(x * s / 4, 0); g.lineTo(x * s / 4, s * 0.58); g.stroke(); }
      // grime, streaks, scuffs
      for (let i = 0; i < 46; i++) { g.fillStyle = `rgba(12,17,22,${rand(0.04, 0.15)})`; g.beginPath(); g.ellipse(rand(0, s), rand(0, s), rand(8, 70), rand(5, 30), rand(0, 3), 0, 7); g.fill(); }
      for (let i = 0; i < 22; i++) { const x = rand(0, s); g.fillStyle = `rgba(20,26,30,${rand(0.08, 0.2)})`; g.fillRect(x, rand(0, s * 0.3), rand(1, 4), rand(30, 160)); }
      for (let i = 0; i < 30; i++) { g.fillStyle = `rgba(8,10,12,${rand(0.1, 0.28)})`; g.fillRect(rand(0, s), rand(s * 0.6, s), rand(6, 42), rand(1, 3)); }
      // peeling paint patches
      for (let i = 0; i < 12; i++) { g.fillStyle = `rgba(96,110,120,${rand(0.15, 0.3)})`; g.beginPath(); g.ellipse(rand(0, s), rand(0, s * 0.55), rand(6, 26), rand(4, 16), rand(0, 3), 0, 7); g.fill(); }
      // faint handprint smears
      for (let i = 0; i < 3; i++) {
        const x = rand(30, s - 30), y = rand(s * 0.25, s * 0.5);
        g.fillStyle = "rgba(30,20,18,0.20)";
        g.beginPath(); g.ellipse(x, y, 9, 12, 0.4, 0, 7); g.fill();
        for (let f = 0; f < 4; f++) { g.beginPath(); g.ellipse(x - 8 + f * 5, y - 14 + Math.abs(f - 1.5) * 2, 2.4, 6, 0.3, 0, 7); g.fill(); }
      }
    }, 1.6);

    const floorSurf = this.makeSurface(512, (g, s) => {
      for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
        g.fillStyle = (x + y) % 2 ? "#2b3644" : "#212a36"; g.fillRect(x * s / 4, y * s / 4, s / 4, s / 4);
        g.fillStyle = `rgba(255,255,255,${rand(0.01, 0.045)})`; g.fillRect(x * s / 4, y * s / 4, s / 4, s / 8);
      }
      g.strokeStyle = "rgba(0,0,0,0.6)"; g.lineWidth = 3;
      for (let i = 0; i <= 4; i++) { g.beginPath(); g.moveTo(i * s / 4, 0); g.lineTo(i * s / 4, s); g.stroke(); g.beginPath(); g.moveTo(0, i * s / 4); g.lineTo(s, i * s / 4); g.stroke(); }
      // cracks
      g.strokeStyle = "rgba(0,0,0,0.5)"; g.lineWidth = 1.4;
      for (let i = 0; i < 7; i++) {
        let x = rand(0, s), y = rand(0, s); g.beginPath(); g.moveTo(x, y);
        for (let k = 0; k < 6; k++) { x += rand(-36, 36); y += rand(-36, 36); g.lineTo(x, y); }
        g.stroke();
      }
      for (let i = 0; i < 30; i++) { g.fillStyle = `rgba(0,0,0,${rand(0.05, 0.22)})`; g.beginPath(); g.ellipse(rand(0, s), rand(0, s), rand(6, 48), rand(4, 22), rand(0, 3), 0, 7); g.fill(); }
      for (let i = 0; i < 10; i++) { g.fillStyle = "rgba(84,22,19,0.13)"; g.beginPath(); g.ellipse(rand(0, s), rand(0, s), rand(3, 12), rand(3, 9), 0, 0, 7); g.fill(); }
      // scuff arcs
      g.strokeStyle = "rgba(160,180,200,0.07)"; g.lineWidth = 3;
      for (let i = 0; i < 10; i++) { g.beginPath(); g.arc(rand(0, s), rand(0, s), rand(14, 60), rand(0, 3), rand(3, 5.5)); g.stroke(); }
    }, 2.2);
    floorSurf.map.repeat.set(GW / 2, GH / 2);
    floorSurf.normalMap.repeat.set(GW / 2, GH / 2);

    const ceilSurf = this.makeSurface(256, (g, s) => {
      g.fillStyle = "#434f5c"; g.fillRect(0, 0, s, s);
      g.strokeStyle = "rgba(0,0,0,0.5)"; g.lineWidth = 3; g.strokeRect(1, 1, s - 2, s - 2);
      for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(0,0,0,${rand(0.05, 0.16)})`; g.fillRect(rand(0, s), rand(0, s), 2, 2); }
      for (let i = 0; i < 5; i++) { g.fillStyle = `rgba(94,72,36,${rand(0.1, 0.24)})`; g.beginPath(); g.ellipse(rand(0, s), rand(0, s), rand(10, 42), rand(6, 24), rand(0, 3), 0, 7); g.fill(); }
    }, 1.2);
    ceilSurf.map.repeat.set(GW, GH);
    ceilSurf.normalMap.repeat.set(GW, GH);

    const wallMat = new THREE.MeshStandardMaterial({
      map: wallSurf.map, normalMap: wallSurf.normalMap, roughness: 0.88, metalness: 0.05,
    });
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorSurf.map, normalMap: floorSurf.normalMap, roughness: 0.42, metalness: 0.22,
      envMapIntensity: 0.7,
    });
    const ceilMat = new THREE.MeshStandardMaterial({
      map: ceilSurf.map, normalMap: ceilSurf.normalMap, roughness: 0.95,
    });

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(GW * CELL, GH * CELL), floorMat);
    floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true;
    this.scene.add(floor);
    const ceil = new THREE.Mesh(new THREE.PlaneGeometry(GW * CELL, GH * CELL), ceilMat);
    ceil.rotation.x = Math.PI / 2; ceil.position.y = WALL_H;
    this.scene.add(ceil);

    // merged wall runs
    const isFloorBase = (gx: number, gy: number) =>
      gx >= 0 && gy >= 0 && gx < GW && gy < GH &&
      (ROOMS.some((r) => gx >= r.x1 && gx <= r.x2 && gy >= r.y1 && gy <= r.y2) ||
        DOORS.some((d) => d.gx === gx && d.gy === gy));
    for (let gy = 0; gy < GH; gy++) {
      let runStart = -1;
      for (let gx = 0; gx <= GW; gx++) {
        const wall = gx < GW && !isFloorBase(gx, gy);
        const touchesFloor = wall && (isFloorBase(gx - 1, gy) || isFloorBase(gx + 1, gy) || isFloorBase(gx, gy - 1) || isFloorBase(gx, gy + 1) || isFloorBase(gx - 1, gy - 1) || isFloorBase(gx + 1, gy + 1) || isFloorBase(gx - 1, gy + 1) || isFloorBase(gx + 1, gy - 1));
        if (touchesFloor && runStart < 0) runStart = gx;
        if ((!touchesFloor || gx === GW) && runStart >= 0) {
          const len = gx - runStart;
          const geo = new THREE.BoxGeometry(len * CELL, WALL_H, CELL);
          const m = new THREE.Mesh(geo, wallMat);
          const a = cellToWorld(runStart, gy); const b = cellToWorld(gx - 1, gy);
          m.position.set((a.x + b.x) / 2, WALL_H / 2, a.z);
          m.castShadow = true; m.receiveShadow = true;
          this.scene.add(m);
          runStart = -1;
        }
      }
    }

    // doors + frames + signs
    const doorTex = this.canvasTex(256, 512, (g) => {
      g.fillStyle = "#526274"; g.fillRect(0, 0, 256, 512);
      const grad = g.createLinearGradient(0, 0, 256, 0);
      grad.addColorStop(0, "rgba(0,0,0,0.25)"); grad.addColorStop(0.5, "rgba(255,255,255,0.06)"); grad.addColorStop(1, "rgba(0,0,0,0.25)");
      g.fillStyle = grad; g.fillRect(0, 0, 256, 512);
      g.strokeStyle = "rgba(14,20,28,0.8)"; g.lineWidth = 6; g.strokeRect(8, 8, 240, 496);
      // wired-glass window
      g.fillStyle = "#101820"; g.fillRect(88, 52, 80, 190);
      g.fillStyle = "rgba(150,195,230,0.30)"; g.fillRect(88, 52, 80, 190);
      g.strokeStyle = "rgba(200,220,240,0.20)"; g.lineWidth = 1;
      for (let i = 0; i < 9; i++) { g.beginPath(); g.moveTo(88, 52 + i * 24); g.lineTo(168, 52 + i * 24 - 12); g.stroke(); g.beginPath(); g.moveTo(88, 52 + i * 24 - 12); g.lineTo(168, 52 + i * 24); g.stroke(); }
      g.strokeStyle = "#0c1219"; g.lineWidth = 6; g.strokeRect(88, 52, 80, 190);
      // push plate + kick plate + handle
      g.fillStyle = "#77879a"; g.fillRect(16, 268, 224, 54);
      g.fillStyle = "#2a3542"; g.fillRect(0, 420, 256, 92);
      g.fillStyle = "#c8ccd2"; g.beginPath(); g.arc(206, 286, 11, 0, 7); g.fill();
      g.fillStyle = "#3a4656"; g.fillRect(190, 296, 34, 9);
      for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(8,12,16,${rand(0.08, 0.22)})`; g.fillRect(rand(0, 246), rand(330, 500), rand(3, 30), rand(1, 3)); }
      for (let i = 0; i < 10; i++) { g.fillStyle = `rgba(70,30,22,${rand(0.1, 0.22)})`; g.fillRect(rand(0, 250), rand(430, 505), rand(2, 8), rand(6, 26)); }
    });
    const doorMat = new THREE.MeshStandardMaterial({ map: doorTex, roughness: 0.5, metalness: 0.45, envMapIntensity: 0.6 });
    const exitMat = new THREE.MeshStandardMaterial({ color: 0x6e2a24, roughness: 0.55, metalness: 0.35 });
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x232f3e, roughness: 0.5, metalness: 0.5 });

    for (const def of DOORS) {
      const horiz = isFloorBase(def.gx, def.gy - 1) || isFloorBase(def.gx, def.gy + 1);
      const geo = horiz ? new THREE.BoxGeometry(CELL * 0.96, 2.5, 0.16) : new THREE.BoxGeometry(0.16, 2.5, CELL * 0.96);
      const mesh = new THREE.Mesh(geo, def.lock === "exit" ? exitMat : doorMat);
      const w = cellToWorld(def.gx, def.gy);
      mesh.position.set(w.x, 1.25, w.z);
      mesh.castShadow = true; mesh.receiveShadow = true;
      this.scene.add(mesh);
      // frame: lintel + jambs
      const jambGeo = horiz ? new THREE.BoxGeometry(0.16, 2.62, 0.34) : new THREE.BoxGeometry(0.34, 2.62, 0.16);
      for (const sd of [-1, 1]) {
        const j = new THREE.Mesh(jambGeo, frameMat);
        if (horiz) j.position.set(w.x + sd * (CELL / 2 - 0.02), 1.31, w.z);
        else j.position.set(w.x, 1.31, w.z + sd * (CELL / 2 - 0.02));
        j.castShadow = true;
        this.scene.add(j);
      }
      const lintel = new THREE.Mesh(horiz ? new THREE.BoxGeometry(CELL + 0.1, 0.16, 0.34) : new THREE.BoxGeometry(0.34, 0.16, CELL + 0.1), frameMat);
      lintel.position.set(w.x, 2.6, w.z);
      this.scene.add(lintel);

      const slideDir = horiz
        ? (!isFloorBase(def.gx + 1, def.gy) ? 1 : -1)
        : (!isFloorBase(def.gx, def.gy + 1) ? 1 : -1);
      const st: DoorState = { def, locked: def.lock !== "none", open: false, open01: 0, mesh, horiz, slideDir, basePos: mesh.position.clone() };
      this.doors.push(st);
      this.doorByCell.set(`${def.gx},${def.gy}`, st);

      const signTex = this.canvasTex(256, 48, (g) => {
        g.fillStyle = def.lock === "exit" ? "#3d0f0d" : "#16202e"; g.fillRect(0, 0, 256, 48);
        g.strokeStyle = "rgba(200,220,240,0.5)"; g.strokeRect(2, 2, 252, 44);
        g.fillStyle = def.lock === "exit" ? "#ff6b5e" : "#cfe3f5";
        g.font = "bold 26px monospace"; g.textAlign = "center"; g.textBaseline = "middle";
        g.fillText(def.sign, 128, 25);
        for (let i = 0; i < 8; i++) { g.fillStyle = `rgba(0,0,0,${rand(0.1, 0.3)})`; g.fillRect(rand(0, 256), rand(0, 48), rand(4, 30), 2); }
      });
      const signBase = new THREE.Color(def.lock === "exit" ? 0xff5040 : 0xbfd9ee);
      const signMat = new THREE.MeshBasicMaterial({ map: signTex, color: signBase.clone().multiplyScalar(def.lock === "exit" ? 1.9 : 0.95) });
      for (const side of [1, -1]) {
        const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 0.3), signMat);
        if (horiz) { sign.position.set(w.x, 2.82, w.z + side * (CELL / 2 + 0.03)); sign.rotation.y = side > 0 ? 0 : Math.PI; }
        else { sign.position.set(w.x + side * (CELL / 2 + 0.03), 2.82, w.z); sign.rotation.y = side > 0 ? Math.PI / 2 : -Math.PI / 2; }
        this.scene.add(sign);
      }
    }

    // furniture (with trim details)
    for (const f of FURNITURE) {
      const w = cellToWorld(f.gx, f.gy);
      const mat = new THREE.MeshStandardMaterial({ color: f.color, roughness: 0.82, metalness: 0.12 });
      const m = new THREE.Mesh(new THREE.BoxGeometry(f.w, f.h, f.d), mat);
      m.position.set(w.x, f.h / 2, w.z);
      m.castShadow = true; m.receiveShadow = true;
      this.scene.add(m);
      if (f.kind === "bed" || f.kind === "gurney") {
        const sheet = new THREE.Mesh(new THREE.BoxGeometry(f.w * 0.92, 0.13, f.d * 0.94),
          new THREE.MeshStandardMaterial({ color: 0xaeb9c2, roughness: 0.96 }));
        sheet.position.set(w.x, f.h + 0.06, w.z);
        sheet.castShadow = true;
        this.scene.add(sheet);
        const pillow = new THREE.Mesh(new THREE.BoxGeometry(f.w * 0.66, 0.12, 0.4),
          new THREE.MeshStandardMaterial({ color: 0xc9d3da, roughness: 0.96 }));
        pillow.position.set(w.x, f.h + 0.16, w.z - f.d * 0.3);
        pillow.rotation.y = rand(-0.15, 0.15);
        this.scene.add(pillow);
        // stain on some beds
        if (Math.random() < 0.55) {
          const stain = new THREE.Mesh(new THREE.CircleGeometry(rand(0.18, 0.34), 12),
            new THREE.MeshStandardMaterial({ color: 0x4d2b20, roughness: 1, transparent: true, opacity: 0.55 }));
          stain.rotation.x = -Math.PI / 2;
          stain.position.set(w.x + rand(-0.2, 0.2), f.h + 0.13, w.z + rand(-0.4, 0.4));
          this.scene.add(stain);
        }
        // wheels for gurneys
        if (f.kind === "gurney") {
          const wheelMat = new THREE.MeshStandardMaterial({ color: 0x1c222b, roughness: 0.6, metalness: 0.4 });
          for (const [ox, oz] of [[-f.w / 2 + 0.12, -f.d / 2 + 0.15], [f.w / 2 - 0.12, -f.d / 2 + 0.15], [-f.w / 2 + 0.12, f.d / 2 - 0.15], [f.w / 2 - 0.12, f.d / 2 - 0.15]]) {
            const wh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.05, 10), wheelMat);
            wh.rotation.z = Math.PI / 2;
            wh.position.set(w.x + ox, 0.09, w.z + oz);
            this.scene.add(wh);
          }
        }
      }
      if (f.kind === "shelf") {
        for (let sN = 0; sN < 3; sN++) {
          const itemsRow = new THREE.Mesh(new THREE.BoxGeometry(f.w * 0.9, 0.06, f.d * 0.85),
            new THREE.MeshStandardMaterial({ color: 0x2c3745, roughness: 0.7, metalness: 0.3 }));
          itemsRow.position.set(w.x, 0.45 + sN * (f.h / 3), w.z);
          this.scene.add(itemsRow);
          // clutter: small boxes & bottles on each shelf level
          const n = 3 + ((Math.random() * 3) | 0);
          for (let k = 0; k < n; k++) {
            const bw = rand(0.14, 0.3), bh = rand(0.16, 0.34);
            const item = new THREE.Mesh(
              Math.random() < 0.5 ? new THREE.BoxGeometry(bw, bh, bw) : new THREE.CylinderGeometry(bw / 2, bw / 2, bh, 8),
              new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(rand(0, 1), 0.25, rand(0.25, 0.5)).getHex(), roughness: 0.8 }));
            item.position.set(w.x + rand(-f.w / 2 + 0.2, f.w / 2 - 0.2), 0.48 + sN * (f.h / 3) + bh / 2, w.z + rand(-0.08, 0.08));
            item.castShadow = true;
            this.scene.add(item);
          }
        }
      }
      if (f.kind === "desk") {
        // desktop clutter: paper stack + mug
        const papers = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.03, 0.46),
          new THREE.MeshStandardMaterial({ color: 0xcfc4a6, roughness: 0.95 }));
        papers.position.set(w.x + rand(-0.3, 0.3), f.h + 0.02, w.z + rand(-0.12, 0.12));
        papers.rotation.y = rand(0, 3);
        this.scene.add(papers);
      }
    }

    // lockers with vents + handles
    const lockerMat = new THREE.MeshStandardMaterial({ color: 0x3c5a50, roughness: 0.45, metalness: 0.55, envMapIntensity: 0.7 });
    for (const l of LOCKERS) {
      const w = cellToWorld(l.gx, l.gy);
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.95, 2.0, 0.6), lockerMat);
      body.position.set(w.x, 1.0, w.z);
      body.castShadow = true; body.receiveShadow = true;
      this.scene.add(body);
      const doorM = new THREE.Mesh(new THREE.BoxGeometry(0.85, 1.9, 0.06),
        new THREE.MeshStandardMaterial({ color: 0x47705f, roughness: 0.42, metalness: 0.55, envMapIntensity: 0.7 }));
      doorM.position.set(w.x, 0.98, w.z + 0.34);
      this.scene.add(doorM);
      for (let v = 0; v < 3; v++) {
        const vent = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.035, 0.02),
          new THREE.MeshStandardMaterial({ color: 0x14201b, roughness: 0.8 }));
        vent.position.set(w.x, 1.68 - v * 0.09, w.z + 0.375);
        this.scene.add(vent);
      }
      const handle = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.18, 0.04),
        new THREE.MeshStandardMaterial({ color: 0xb9c2cc, metalness: 0.8, roughness: 0.3 }));
      handle.position.set(w.x + 0.32, 1.05, w.z + 0.39);
      this.scene.add(handle);
      this.lockerMeshes.push({ gx: l.gx, gy: l.gy, door: doorM });
    }

    this.buildProps();
    this.buildDetails();
    this.buildPickups();
    this.buildLights();
    this.buildEnemy();
    this.buildDust();
    this.buildPosters();
  }

  private propBox(x: number, y: number, z: number, w: number, h: number, d: number, color: number, emissive = 0) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d),
      new THREE.MeshStandardMaterial({ color, roughness: 0.7, metalness: 0.2, emissive: color, emissiveIntensity: emissive }));
    m.position.set(x, y, z); m.castShadow = true;
    this.scene.add(m);
    return m;
  }

  private buildProps() {
    const at = (gx: number, gy: number) => cellToWorld(gx, gy);
    const monPos = at(30, 19);
    const screenTex = this.canvasTex(128, 96, (g) => {
      g.fillStyle = "#0a1a12"; g.fillRect(0, 0, 128, 96);
      for (let i = 0; i < 300; i++) { g.fillStyle = `rgba(90,255,170,${rand(0.04, 0.2)})`; g.fillRect(rand(0, 128), rand(0, 96), 2, 2); }
      g.fillStyle = "#7dffb0"; g.font = "bold 13px monospace"; g.fillText("CAM ●REC", 8, 18);
      g.fillStyle = "rgba(125,255,176,0.13)"; g.fillRect(0, rand(0, 90), 128, 6);
    });
    this.monitorStaticTex = screenTex;
    for (let i = -1; i <= 1; i++) {
      const mat = new THREE.MeshBasicMaterial({ map: screenTex, color: new THREE.Color(0.5, 0.6, 0.55) });
      const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 0.5), mat);
      scr.position.set(monPos.x + i * 0.82, 1.35, monPos.z - 0.32);
      scr.rotation.y = Math.PI; scr.rotation.x = 0.08;
      this.scene.add(scr);
      this.monitorMats.push(mat);
      if (i === 0) this.monitorLiveMat = mat; // center screen shows the live feed
      const back = this.propBox(monPos.x + i * 0.82, 1.2, monPos.z - 0.36, 0.78, 0.7, 0.08, 0x1a222e);
      back.castShadow = false;
      const stand = this.propBox(monPos.x + i * 0.82, 0.95, monPos.z - 0.34, 0.3, 0.2, 0.2, 0x141a24);
      stand.castShadow = false;
    }
    // keyboard + mug on the monitor desk
    this.propBox(monPos.x, 0.9, monPos.z + 0.25, 0.7, 0.04, 0.26, 0x222c3a);
    const termPos = at(28, 19);
    const termMat = new THREE.MeshBasicMaterial({ map: screenTex, color: new THREE.Color(0.35, 0.45, 0.6) });
    const term = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.46), termMat);
    term.position.set(termPos.x, 1.32, termPos.z - 0.3); term.rotation.y = Math.PI;
    this.scene.add(term);
    this.monitorMats.push(termMat);
    const fb = at(33, 18);
    this.propBox(fb.x, 1.7, fb.z + 0.55, 0.6, 0.85, 0.18, 0x707a86);
    this.propBox(fb.x, 1.95, fb.z + 0.65, 0.1, 0.1, 0.05, 0xff3322, 2.2);
    const rp = at(29, 4);
    this.propBox(rp.x, 1.02, rp.z, 0.55, 0.3, 0.24, 0x3a2f22);
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.9),
      new THREE.MeshStandardMaterial({ color: 0x9aa4ae, metalness: 0.8, roughness: 0.3 }));
    ant.position.set(rp.x + 0.2, 1.55, rp.z); ant.rotation.z = 0.5;
    this.scene.add(ant);
    this.propBox(rp.x - 0.12, 1.02, rp.z + 0.13, 0.09, 0.09, 0.04, 0xd8b25a, 0.6);
    // speaker grille dots
    for (let gx2 = 0; gx2 < 4; gx2++) for (let gy2 = 0; gy2 < 3; gy2++)
      this.propBox(rp.x + 0.08 + gx2 * 0.045, 0.97 + gy2 * 0.05, rp.z + 0.125, 0.02, 0.02, 0.01, 0x14100b);
    const xp = at(33, 3);
    const xrayTex = this.canvasTex(128, 128, (g) => {
      g.fillStyle = "#cfe6f5"; g.fillRect(0, 0, 128, 128);
      g.fillStyle = "#10161e"; g.fillRect(18, 10, 92, 108);
      g.strokeStyle = "rgba(207,230,245,0.85)"; g.lineWidth = 4;
      for (let i = 0; i < 6; i++) { g.beginPath(); g.arc(64, 40 + i * 13, 20 + i * 3, 0.3, Math.PI - 0.3); g.stroke(); }
      g.beginPath(); g.moveTo(64, 16); g.lineTo(64, 112); g.stroke();
      g.beginPath(); g.arc(64, 22, 9, 0, 7); g.stroke();
    });
    const xb = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 1.25),
      new THREE.MeshBasicMaterial({ map: xrayTex, color: new THREE.Color(1.5, 1.6, 1.7) }));
    xb.position.set(xp.x + 0.92, 1.7, xp.z); xb.rotation.y = -Math.PI / 2;
    this.scene.add(xb);
    const cp = at(14, 2);
    this.propBox(cp.x, 1.0, cp.z - 0.4, 1.1, 2.0, 0.5, 0x54452e);
    const abc = this.canvasTex(128, 128, (g) => {
      g.fillStyle = "#2a2118"; g.fillRect(0, 0, 128, 128);
      g.fillStyle = "#d8cfb4"; g.font = "bold 17px monospace"; g.textAlign = "center";
      const letters = ["S E D A", "T I V E", "? ? ? ?", "WORD", "LOCK"];
      letters.forEach((l, i) => g.fillText(l, 64, 30 + i * 22));
    });
    const cabFace = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.8), new THREE.MeshBasicMaterial({ map: abc }));
    cabFace.position.set(cp.x, 1.3, cp.z - 0.14);
    this.scene.add(cabFace);
    const bp = at(12, 12);
    this.propBox(bp.x - 0.7, 1.7, bp.z, 0.18, 0.9, 0.65, 0x806030);
    this.propBox(bp.x - 0.58, 1.6, bp.z, 0.08, 0.4, 0.12, 0xc03028, 0.7);
    for (const gy of [11, 13]) {
      const gp = at(13, gy);
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 1.15, 4, 12),
        new THREE.MeshStandardMaterial({ color: 0xa4b2bc, roughness: 0.95 }));
      body.rotation.x = Math.PI / 2;
      body.position.set(gp.x, 1.08, gp.z);
      body.castShadow = true;
      this.scene.add(body);
      // head lump under the sheet
      const headLump = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 8),
        new THREE.MeshStandardMaterial({ color: 0xa4b2bc, roughness: 0.95 }));
      headLump.position.set(gp.x, 1.12, gp.z - 0.78);
      this.scene.add(headLump);
    }
    const paperMat = new THREE.MeshStandardMaterial({ color: 0xd8cfb4, emissive: 0xd8cfb4, emissiveIntensity: 0.14, roughness: 0.9 });
    const paperAt = (gx: number, gy: number, y: number) => {
      const w = at(gx, gy);
      const p = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 0.46), paperMat);
      p.position.set(w.x, y, w.z); p.rotation.x = -Math.PI / 2 + 0.25; p.rotation.z = rand(0, 3);
      this.scene.add(p);
    };
    paperAt(4, 10, 0.98);
    paperAt(25, 5, 0.06);
    paperAt(13, 4, 0.86);
    paperAt(25, 11, 0.9);
    paperAt(13, 13, 1.32);
    const op = at(25, 11);
    this.propBox(op.x - 0.7, 0.9, op.z + 0.2, 0.34, 0.14, 0.24, 0x14181e);
    this.propBox(op.x - 0.7, 0.99, op.z + 0.2, 0.3, 0.05, 0.09, 0x1d242e); // handset
  }

  // ------------------------------------------------- environmental detail
  private buildDetails() {
    const at = (gx: number, gy: number) => cellToWorld(gx, gy);
    const railMat = new THREE.MeshStandardMaterial({ color: 0x6d4a33, roughness: 0.6, metalness: 0.15 });
    const steelMat = new THREE.MeshStandardMaterial({ color: 0x707c8a, roughness: 0.35, metalness: 0.75, envMapIntensity: 0.9 });

    // corridor handrails (segments that avoid doorways)
    const rail = (x1: number, z1: number, x2: number, z2: number) => {
      const len = Math.hypot(x2 - x1, z2 - z1);
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, len, 8), railMat);
      m.position.set((x1 + x2) / 2, 0.92, (z1 + z2) / 2);
      m.rotation.z = Math.PI / 2;
      m.rotation.y = -Math.atan2(z2 - z1, x2 - x1);
      m.castShadow = true;
      this.scene.add(m);
      const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, len, 6), steelMat);
      bar.position.copy(m.position); bar.position.y = 0.72;
      bar.rotation.copy(m.rotation);
      this.scene.add(bar);
    };
    const nSouth = at(2, 8).z + 0.9, mNorth = at(2, 15).z - 0.9;
    rail(at(2, 8).x, nSouth, at(10, 8).x, nSouth);
    rail(at(14, 8).x, nSouth, at(22, 8).x, nSouth);
    rail(at(26, 8).x, nSouth, at(33, 8).x, nSouth);
    rail(at(2, 15).x, mNorth, at(12, 15).x, mNorth);
    rail(at(20, 15).x, mNorth, at(24, 15).x, mNorth);
    rail(at(27, 15).x, mNorth, at(31, 15).x, mNorth);

    // ceiling pipes along corridors + spine
    const pipe = (x1: number, z1: number, x2: number, z2: number, r: number, y: number) => {
      const len = Math.hypot(x2 - x1, z2 - z1);
      const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 10), steelMat);
      m.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);
      m.rotation.z = Math.PI / 2;
      m.rotation.y = -Math.atan2(z2 - z1, x2 - x1);
      this.scene.add(m);
    };
    pipe(at(1, 7).x, at(1, 7).z - 0.6, at(34, 7).x, at(34, 7).z - 0.6, 0.07, 2.95);
    pipe(at(1, 7).x, at(1, 7).z - 0.38, at(34, 7).x, at(34, 7).z - 0.38, 0.045, 2.82);
    pipe(at(17, 1).x + 0.7, at(17, 1).z, at(17, 24).x + 0.7, at(17, 24).z, 0.06, 2.92);
    pipe(at(1, 16).x, at(1, 16).z + 0.6, at(34, 16).x, at(34, 16).z + 0.6, 0.07, 2.95);

    // lobby windows with moonlight + animated rain
    const winTex = this.canvasTex(256, 320, (g) => {
      const grad = g.createLinearGradient(0, 0, 0, 320);
      grad.addColorStop(0, "#16263e"); grad.addColorStop(1, "#0a1424");
      g.fillStyle = grad; g.fillRect(0, 0, 256, 320);
      g.fillStyle = "#dfeaf6"; g.beginPath(); g.arc(178, 74, 30, 0, 7); g.fill();
      g.fillStyle = "rgba(190,210,235,0.25)"; g.beginPath(); g.arc(178, 74, 52, 0, 7); g.fill();
      g.fillStyle = "#0a1424"; g.beginPath(); g.arc(164, 62, 26, 0, 7); g.fill();
      for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(220,235,255,${rand(0.3, 0.9)})`; g.fillRect(rand(0, 256), rand(0, 320), 1.6, 1.6); }
      // window frame cross
      g.fillStyle = "#1c2733"; g.fillRect(120, 0, 16, 320); g.fillRect(0, 150, 256, 16);
      g.strokeStyle = "#232f3e"; g.lineWidth = 14; g.strokeRect(0, 0, 256, 320);
      // grime streaks
      for (let i = 0; i < 16; i++) { g.fillStyle = `rgba(10,14,18,${rand(0.1, 0.3)})`; g.fillRect(rand(0, 250), 0, rand(2, 6), rand(60, 320)); }
    });
    const rainTex = this.canvasTex(128, 128, (g) => {
      g.clearRect(0, 0, 128, 128);
      g.strokeStyle = "rgba(180,210,240,0.55)"; g.lineWidth = 1.4;
      for (let i = 0; i < 42; i++) {
        const x = rand(0, 128), y = rand(0, 128), l = rand(6, 18);
        g.beginPath(); g.moveTo(x, y); g.lineTo(x - 2, y + l); g.stroke();
      }
    });
    rainTex.repeat.set(2, 2);
    this.rainTexs.push(rainTex);
    for (const gx of [14, 22]) {
      const w = at(gx, 24);
      const win = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 2.3),
        new THREE.MeshBasicMaterial({ map: winTex, color: new THREE.Color(1.25, 1.35, 1.55) }));
      win.position.set(w.x, 1.85, w.z + CELL / 2 - 0.04);
      win.rotation.y = Math.PI;
      this.scene.add(win);
      const rain = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 2.3),
        new THREE.MeshBasicMaterial({ map: rainTex, transparent: true, opacity: 0.7, depthWrite: false }));
      rain.position.set(w.x, 1.85, w.z + CELL / 2 - 0.09);
      rain.rotation.y = Math.PI;
      this.scene.add(rain);
      // radiator under the window
      const rad = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.55, 0.16), steelMat);
      rad.position.set(w.x, 0.42, w.z + CELL / 2 - 0.16);
      rad.castShadow = true;
      this.scene.add(rad);
    }

    // wall clocks (security + lobby) — hands show the real shift time
    const mkClock = (gx: number, gy: number, rotY: number, oz: number) => {
      const w = at(gx, gy);
      const grp = new THREE.Group();
      grp.position.set(w.x, 2.45, w.z + oz);
      grp.rotation.y = rotY;
      const face = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.05, 24),
        new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.6 }));
      face.rotation.x = Math.PI / 2;
      grp.add(face);
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.03, 8, 24),
        new THREE.MeshStandardMaterial({ color: 0x222b36, metalness: 0.6, roughness: 0.4 }));
      grp.add(rim);
      const hour = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.16, 0.012),
        new THREE.MeshStandardMaterial({ color: 0x141a22 }));
      hour.geometry.translate(0, 0.06, 0);
      hour.position.z = 0.035;
      const min = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.24, 0.012),
        new THREE.MeshStandardMaterial({ color: 0x141a22 }));
      min.geometry.translate(0, 0.09, 0);
      min.position.z = 0.045;
      grp.add(hour); grp.add(min);
      this.clockHands.push({ hour, min });
      this.scene.add(grp);
    };
    mkClock(30, 18, 0, 0.95);
    mkClock(16, 18, 0, 0.95);

    // notice board in mid corridor
    const nbPos = at(21, 15);
    const board = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.15, 0.06),
      new THREE.MeshStandardMaterial({ color: 0x4a3b28, roughness: 0.9 }));
    board.position.set(nbPos.x, 1.75, nbPos.z - 0.92);
    this.scene.add(board);
    for (let i = 0; i < 9; i++) {
      const note = new THREE.Mesh(new THREE.PlaneGeometry(rand(0.2, 0.34), rand(0.24, 0.4)),
        new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(rand(0.08, 0.16), 0.4, rand(0.7, 0.86)).getHex(), roughness: 0.95 }));
      note.position.set(nbPos.x + rand(-0.75, 0.75), 1.75 + rand(-0.35, 0.35), nbPos.z - 0.88);
      note.rotation.z = rand(-0.18, 0.18);
      this.scene.add(note);
    }

    // scattered papers + blood decals
    const paperDecalMat = new THREE.MeshStandardMaterial({ color: 0xb9ae8f, roughness: 0.95 });
    const paperSpots: [number, number][] = [[17, 10], [9, 15], [24, 8], [5, 20], [30, 22], [13, 4], [21, 12], [33, 7], [3, 16], [18, 19], [28, 3], [11, 21]];
    for (const [gx, gy] of paperSpots) {
      const w = at(gx, gy);
      const p = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.42), paperDecalMat);
      p.rotation.x = -Math.PI / 2;
      p.rotation.z = rand(0, Math.PI * 2);
      p.position.set(w.x + rand(-0.5, 0.5), 0.015 + Math.random() * 0.01, w.z + rand(-0.5, 0.5));
      p.receiveShadow = true;
      this.scene.add(p);
    }
    const bloodTex = this.canvasTex(256, 256, (g) => {
      g.clearRect(0, 0, 256, 256);
      for (let i = 0; i < 26; i++) {
        const a = rand(0, Math.PI * 2), d = rand(0, 78);
        g.fillStyle = `rgba(74,12,10,${rand(0.35, 0.75)})`;
        g.beginPath();
        g.ellipse(128 + Math.cos(a) * d, 128 + Math.sin(a) * d, rand(6, 42) * (1 - d / 130), rand(5, 30) * (1 - d / 130), a, 0, 7);
        g.fill();
      }
      // drag trail
      g.fillStyle = "rgba(74,12,10,0.4)";
      g.beginPath(); g.ellipse(190, 128, 62, 13, 0, 0, 7); g.fill();
    });
    const bloodMat = new THREE.MeshStandardMaterial({ map: bloodTex, transparent: true, roughness: 0.35, metalness: 0.1, depthWrite: false });
    const bloodSpots: [number, number, number][] = [[5, 12, 2.2], [14, 12, 2.6], [20, 15, 1.7], [24, 4, 1.5], [8, 8, 1.3]];
    for (const [gx, gy, sz] of bloodSpots) {
      const w = at(gx, gy);
      const b = new THREE.Mesh(new THREE.PlaneGeometry(sz, sz), bloodMat);
      b.rotation.x = -Math.PI / 2;
      b.rotation.z = rand(0, Math.PI * 2);
      b.position.set(w.x, 0.012, w.z);
      b.receiveShadow = true;
      this.scene.add(b);
    }

    // cobwebs in high corners
    const webTex = this.canvasTex(128, 128, (g) => {
      g.clearRect(0, 0, 128, 128);
      g.strokeStyle = "rgba(210,222,235,0.5)"; g.lineWidth = 1;
      for (let i = 0; i <= 6; i++) { g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(i * Math.PI / 12) * 128, Math.sin(i * Math.PI / 12) * 128); g.stroke(); }
      for (let r = 16; r < 128; r += 16) { g.beginPath(); g.arc(0, 0, r, 0.08, Math.PI / 2 - 0.08); g.stroke(); }
    });
    const webMat = new THREE.MeshBasicMaterial({ map: webTex, transparent: true, opacity: 0.55, depthWrite: false, side: THREE.DoubleSide });
    const webSpots: [number, number, number][] = [[1, 1, 0], [34, 1, 1], [1, 13, 2], [34, 24, 3], [12, 10, 0]];
    for (const [gx, gy, rot] of webSpots) {
      const w = at(gx, gy);
      const web = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.5), webMat);
      web.position.set(w.x, 2.75, w.z);
      web.rotation.set(Math.PI / 2.6, rot * Math.PI / 2, 0);
      this.scene.add(web);
    }

    // IV stands in the ward
    for (const gx of [3, 7]) {
      const w = at(gx, 11);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.9, 8), steelMat);
      pole.position.set(w.x, 0.95, w.z);
      this.scene.add(pole);
      const bag = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.24, 0.05),
        new THREE.MeshStandardMaterial({ color: 0xc8b98a, roughness: 0.4, transparent: true, opacity: 0.85 }));
      bag.position.set(w.x + 0.1, 1.72, w.z);
      this.scene.add(bag);
      const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.8, 4),
        new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.5, transparent: true, opacity: 0.7 }));
      tube.position.set(w.x + 0.1, 1.2, w.z);
      this.scene.add(tube);
    }

    // the scripted wheelchair (mid corridor)
    this.wheelchair = new THREE.Group();
    const wcMetal = new THREE.MeshStandardMaterial({ color: 0x59636e, metalness: 0.7, roughness: 0.4 });
    const wcSeatMat = new THREE.MeshStandardMaterial({ color: 0x5c2e2e, roughness: 0.9 });
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.07, 0.48), wcSeatMat);
    seat.position.y = 0.52;
    this.wheelchair.add(seat);
    const backr = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.55, 0.07), wcSeatMat);
    backr.position.set(0, 0.86, -0.22);
    this.wheelchair.add(backr);
    for (const sd of [-1, 1]) {
      const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.028, 8, 22), wcMetal);
      wheel.position.set(sd * 0.3, 0.31, -0.06);
      wheel.rotation.y = Math.PI / 2;
      this.wheelchair.add(wheel);
      this.wcWheels.push(wheel);
      const small = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 8), wcMetal);
      small.position.set(sd * 0.24, 0.075, 0.26);
      small.scale.z = 0.6;
      this.wheelchair.add(small);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.04, 0.4), wcSeatMat);
      arm.position.set(sd * 0.29, 0.72, 0);
      this.wheelchair.add(arm);
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.55, 6), wcMetal);
      leg.position.set(sd * 0.24, 0.28, 0.2);
      this.wheelchair.add(leg);
    }
    const wcW = at(3, 15);
    this.wheelchair.position.set(wcW.x, 0, wcW.z - 0.4);
    this.wheelchair.rotation.y = -Math.PI / 2;
    this.wheelchair.traverse((o) => { o.castShadow = true; });
    this.scene.add(this.wheelchair);
    // a second, static wheelchair tipped over in the waiting room
    const wc2 = this.wheelchair.clone();
    const w2 = at(8, 23);
    wc2.position.set(w2.x, 0.3, w2.z);
    wc2.rotation.set(0.4, 1.1, Math.PI / 2.15);
    this.scene.add(wc2);

    // reflective puddles (envmap sheen) on the worn floor
    const puddleMat = new THREE.MeshStandardMaterial({
      color: 0x0d141d, roughness: 0.05, metalness: 0.9, envMapIntensity: 1.6, transparent: true, opacity: 0.85,
    });
    const puddles: [number, number, number][] = [[18, 12, 1.5], [7, 15, 1.1], [26, 8, 1.3], [13, 21, 1.8], [30, 4, 0.9], [4, 12, 1.0]];
    for (const [gx, gy, sz] of puddles) {
      const w = at(gx, gy);
      const p = new THREE.Mesh(new THREE.CircleGeometry(sz, 20), puddleMat);
      p.rotation.x = -Math.PI / 2;
      p.rotation.z = rand(0, 3);
      p.scale.set(1, rand(0.55, 0.8), 1);
      p.position.set(w.x + rand(-0.3, 0.3), 0.008, w.z + rand(-0.3, 0.3));
      p.receiveShadow = true;
      this.scene.add(p);
    }

    // moonlight shafts slanting in through the lobby windows
    const moonMat = new THREE.MeshBasicMaterial({
      color: 0x8fb8e8, transparent: true, opacity: 0.05, blending: THREE.AdditiveBlending,
      depthWrite: false, side: THREE.DoubleSide, fog: false,
    });
    for (const gx of [14, 22]) {
      const w = at(gx, 24);
      const shaft = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 5.2), moonMat);
      shaft.position.set(w.x, 1.35, w.z - 0.4);
      shaft.rotation.set(0.72, 0, 0.06);
      this.scene.add(shaft);
      const shaft2 = shaft.clone();
      shaft2.rotation.y = Math.PI / 2;
      shaft2.rotation.x = 0.72;
      shaft2.scale.set(0.9, 1, 1);
      this.scene.add(shaft2);
    }
  }

  private buildPosters() {
    const posters: { gx: number; gy: number; rotY: number; ox: number; oz: number; lines: string[]; color: string }[] = [
      { gx: 11, gy: 8, rotY: 0, ox: 0, oz: 0.94, lines: ["SILENCE PLEASE", "PATIENTS ARE SLEEPING", "DO NOT WAKE HER"], color: "#dcebf7" },
      { gx: 22, gy: 8, rotY: 0, ox: 0, oz: 0.94, lines: ["WASH YOUR HANDS", "COUNT THE BEDS", "FOUR IS SAFE"], color: "#f2e3b3" },
      { gx: 14, gy: 15, rotY: Math.PI, ox: 0, oz: -0.94, lines: ["EMERGENCY RULES", "1. DO NOT RUN", "2. DO NOT SLEEP", "3. DO NOT ANSWER HER"], color: "#f3c1bb" },
      { gx: 20, gy: 18, rotY: Math.PI, ox: 0, oz: -0.94, lines: ["ST. MERCY", "EST. 1974", "MERCY FOR THE SICK", "SILENCE FOR THE DEAD"], color: "#d8cfb4" },
      { gx: 32, gy: 15, rotY: Math.PI, ox: 0, oz: -0.94, lines: ["VISITING HOURS", "NONE. EVER.", "SHE VISITS YOU"], color: "#c4d8c9" },
      { gx: 4, gy: 8, rotY: 0, ox: 0, oz: 0.94, lines: ["NIGHT STAFF", "REPORT ALL VOICES", "TO THE DIRECTOR"], color: "#d8c9e0" },
    ];
    for (const p of posters) {
      const tex = this.canvasTex(256, 320, (g) => {
        g.fillStyle = "#232c38"; g.fillRect(0, 0, 256, 320);
        g.strokeStyle = p.color; g.lineWidth = 4; g.strokeRect(10, 10, 236, 300);
        g.fillStyle = p.color; g.textAlign = "center";
        p.lines.forEach((l, i) => {
          g.font = i === 0 ? "bold 30px monospace" : "bold 20px monospace";
          g.fillText(l, 128, 84 + i * 52);
        });
        for (let i = 0; i < 200; i++) { g.fillStyle = `rgba(0,0,0,${rand(0.05, 0.25)})`; g.fillRect(rand(0, 256), rand(0, 320), rand(1, 5), rand(1, 4)); }
        // torn corner
        g.fillStyle = "#0a0f16"; g.beginPath(); g.moveTo(256, 320); g.lineTo(196, 320); g.lineTo(256, 252); g.closePath(); g.fill();
      });
      const w = cellToWorld(p.gx, p.gy);
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1.05, 1.3), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9 }));
      m.position.set(w.x + p.ox, 1.75, w.z + p.oz);
      m.rotation.y = p.rotY;
      m.rotation.z = rand(-0.03, 0.03);
      this.scene.add(m);
    }
  }

  private buildLights() {
    this.scene.add(new THREE.AmbientLight(0x33445e, 0.5));
    const hemi = new THREE.HemisphereLight(0x2c3c55, 0x05070a, 0.35);
    this.scene.add(hemi);

    const fixture = (parent: THREE.Object3D, x: number, y: number, z: number, color: number) => {
      const housing = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.09, 0.42),
        new THREE.MeshStandardMaterial({ color: 0x39434f, roughness: 0.5, metalness: 0.5 }));
      housing.position.set(x, y, z);
      parent.add(housing);
      for (const off of [-0.11, 0.11]) {
        const tube = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 1.22, 8),
          new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(1.9) }));
        tube.rotation.z = Math.PI / 2;
        tube.position.set(x, y - 0.06, z + off);
        parent.add(tube);
      }
    };

    const addPractical = (gx: number, gy: number, color: number, base: number, dist: number, bad = false, swinging = false) => {
      const w = cellToWorld(gx, gy);
      const l = new THREE.PointLight(color, base, dist, 1.65);
      if (swinging) {
        const pivot = new THREE.Group();
        pivot.position.set(w.x, WALL_H, w.z);
        const rod = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.85, 6),
          new THREE.MeshStandardMaterial({ color: 0x2a323e, metalness: 0.6, roughness: 0.5 }));
        rod.position.y = -0.42;
        pivot.add(rod);
        fixture(pivot, 0, -0.88, 0, color);
        l.position.set(0, -1.0, 0);
        pivot.add(l);
        this.scene.add(pivot);
        this.swingPivot = pivot;
        this.practicalLights.push({ light: l, base, bad, deadT: 0, fixPos: new THREE.Vector3(w.x, WALL_H - 0.9, w.z) });
      } else {
        l.position.set(w.x, 2.85, w.z);
        this.scene.add(l);
        fixture(this.scene, w.x, 3.1, w.z, color);
        this.practicalLights.push({ light: l, base, bad, deadT: 0, fixPos: new THREE.Vector3(w.x, 3.05, w.z) });
      }
    };
    addPractical(30, 21, 0xdcecf8, 26, 17);
    addPractical(18, 21, 0xff4a3a, 13, 16);
    addPractical(17, 7, 0xbfd9ee, 18, 18, true);
    addPractical(6, 15, 0xbfd9ee, 15, 16);
    addPractical(28, 15, 0xbfd9ee, 15, 16, true);
    addPractical(5, 11, 0x9fb8cc, 9, 13);
    addPractical(13, 12, 0x8fb8d8, 8, 12, false, true); // morgue — swinging

    // fake volumetric shafts under the main corridor lights
    const shaftGeo = new THREE.ConeGeometry(1.7, 3.0, 18, 1, true);
    this.practicalLights.forEach((pl, idx) => {
      if (idx === 6) return; // swinging morgue light gets none
      const mat = new THREE.MeshBasicMaterial({
        color: pl.light.color.clone(), transparent: true, opacity: 0.05,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false,
      });
      const cone = new THREE.Mesh(shaftGeo, mat);
      cone.position.copy(pl.fixPos);
      cone.position.y = 1.55;
      this.scene.add(cone);
      this.lightShafts.push({ mat, idx });
    });

    // dead fixtures (visual only, no light) scattered around
    fixture(this.scene, cellToWorld(23, 3).x, 3.1, cellToWorld(23, 3).z, 0x2a3542);
    fixture(this.scene, cellToWorld(6, 3).x, 3.1, cellToWorld(6, 3).z, 0x2a3542);
    fixture(this.scene, cellToWorld(25, 11).x, 3.1, cellToWorld(25, 11).z, 0x2a3542);

    this.flashlight = new THREE.SpotLight(0xfff2d8, 85, 34, 0.52, 0.45, 1.35);
    this.flashlight.castShadow = true;
    this.flashlight.shadow.mapSize.set(2048, 2048);
    this.flashlight.shadow.bias = -0.002;
    this.flashlight.shadow.camera.near = 0.25;
    this.scene.add(this.flashlight);
    this.scene.add(this.flashlight.target);
    this.phoneGlow = new THREE.PointLight(0x8fa8c8, 2.6, 5.5, 1.8);
    this.scene.add(this.phoneGlow);
  }

  private buildPickups() {
    const glowTex = this.canvasTex(64, 64, (g) => {
      const grad = g.createRadialGradient(32, 32, 2, 32, 32, 30);
      grad.addColorStop(0, "rgba(255,255,255,0.9)");
      grad.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    });
    const make = (kind: PickupKind): THREE.Group => {
      const grp = new THREE.Group();
      const metal = new THREE.MeshStandardMaterial({ color: 0xb9c2cc, metalness: 0.85, roughness: 0.3 });
      if (kind === "battery") {
        // AA cell: green/black bands + terminal nub
        const bodyB = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.21, 14),
          new THREE.MeshStandardMaterial({ color: 0x1d7a48, emissive: 0x2fbf71, emissiveIntensity: 0.35, roughness: 0.45 }));
        grp.add(bodyB);
        const band = new THREE.Mesh(new THREE.CylinderGeometry(0.047, 0.047, 0.06, 14),
          new THREE.MeshStandardMaterial({ color: 0x14181e, roughness: 0.5 }));
        band.position.y = -0.05;
        grp.add(band);
        const nub = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.016, 0.025, 8), metal);
        nub.position.y = 0.115;
        grp.add(nub);
      } else if (kind === "coffee") {
        // paper cup + sleeve + lid
        const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.052, 0.2, 14),
          new THREE.MeshStandardMaterial({ color: 0xe8ddc8, roughness: 0.8 }));
        grp.add(cup);
        const sleeve = new THREE.Mesh(new THREE.CylinderGeometry(0.066, 0.06, 0.09, 14),
          new THREE.MeshStandardMaterial({ color: 0x8a6844, roughness: 0.95 }));
        grp.add(sleeve);
        const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.073, 0.073, 0.025, 14),
          new THREE.MeshStandardMaterial({ color: 0xd8d2c4, roughness: 0.6 }));
        lid.position.y = 0.11;
        grp.add(lid);
        const glowDot = new THREE.Mesh(new THREE.CircleGeometry(0.03, 10),
          new THREE.MeshStandardMaterial({ color: 0x3a2412, emissive: 0xc89a5a, emissiveIntensity: 0.5 }));
        glowDot.position.set(0, 0, 0.066);
        grp.add(glowDot);
      } else if (kind === "vial") {
        // glass vial with glowing liquid + metal cap
        const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.038, 0.17, 12),
          new THREE.MeshStandardMaterial({ color: 0xcfe8f5, roughness: 0.1, metalness: 0.1, transparent: true, opacity: 0.45 }));
        grp.add(glass);
        const liquid = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.11, 10),
          new THREE.MeshStandardMaterial({ color: 0x54c8ee, emissive: 0x54c8ee, emissiveIntensity: 1.5, roughness: 0.3 }));
        liquid.position.y = -0.02;
        grp.add(liquid);
        const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.026, 0.035, 10), metal);
        cap.position.y = 0.1;
        grp.add(cap);
      } else if (kind === "fuse") {
        // cartridge fuse: ceramic body, brass caps, glowing filament window
        const bodyF = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.16, 12),
          new THREE.MeshStandardMaterial({ color: 0xd8cfb4, roughness: 0.6 }));
        bodyF.rotation.z = Math.PI / 2;
        grp.add(bodyF);
        for (const sx of [-0.1, 0.1]) {
          const capE = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.048, 0.045, 12),
            new THREE.MeshStandardMaterial({ color: 0xc8a44a, metalness: 0.85, roughness: 0.3 }));
          capE.rotation.z = Math.PI / 2;
          capE.position.x = sx;
          grp.add(capE);
        }
        const fil = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.02),
          new THREE.MeshStandardMaterial({ color: 0xffa726, emissive: 0xff8f00, emissiveIntensity: 2.2 }));
        fil.position.y = 0.04;
        grp.add(fil);
      } else if (kind === "wristband") {
        const bandW = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.02, 8, 22),
          new THREE.MeshStandardMaterial({ color: 0xffd166, emissive: 0xe0a43a, emissiveIntensity: 0.7, roughness: 0.4, metalness: 0.2 }));
        bandW.rotation.x = Math.PI / 2.3;
        grp.add(bandW);
        const tag = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.055, 0.012),
          new THREE.MeshStandardMaterial({ color: 0xf2ead2, roughness: 0.85 }));
        tag.position.set(0, 0.055, 0.075);
        tag.rotation.x = -0.5;
        grp.add(tag);
      } else {
        // 9V radio battery: yellow block + twin terminals
        const block = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.17, 0.07),
          new THREE.MeshStandardMaterial({ color: 0xe8c51e, emissive: 0xd9b91e, emissiveIntensity: 0.35, roughness: 0.5 }));
        grp.add(block);
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.115, 0.05, 0.075),
          new THREE.MeshStandardMaterial({ color: 0x1c222b, roughness: 0.6 }));
        stripe.position.y = -0.03;
        grp.add(stripe);
        for (const sx of [-0.028, 0.028]) {
          const term = new THREE.Mesh(new THREE.CylinderGeometry(0.013, 0.013, 0.02, 8), metal);
          term.position.set(sx, 0.095, 0);
          grp.add(term);
        }
      }
      const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, color: kind === "wristband" ? 0xffd166 : 0xbfd9ff, transparent: true, opacity: 0.4, depthWrite: false }));
      spr.scale.set(0.7, 0.7, 1);
      grp.add(spr);
      return grp;
    };
    for (const p of PICKUPS) {
      const w = cellToWorld(p.gx, p.gy);
      const grp = make(p.kind);
      grp.position.set(w.x, 0.75, w.z);
      this.scene.add(grp);
      this.pickupMeshes.set(p.id, grp);
    }
  }

  private buildEnemy() {
    const gownMat = new THREE.MeshStandardMaterial({ color: 0x2b3644, roughness: 0.95 });
    const apronMat = new THREE.MeshStandardMaterial({ color: 0x8b9494, roughness: 0.95 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xc6cec6, roughness: 0.8 });
    const hairMat = new THREE.MeshStandardMaterial({ color: 0x0a0c10, roughness: 1, side: THREE.DoubleSide });

    // long skirt / gown
    const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.5, 1.55, 14, 1, true), gownMat);
    skirt.position.y = 0.78; skirt.castShadow = true;
    this.enemy.add(skirt);
    this.enemyParts.skirt = skirt;
    const hem = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.035, 6, 18), gownMat);
    hem.rotation.x = Math.PI / 2; hem.position.y = 0.04;
    this.enemy.add(hem);
    // torso + stained apron
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.2, 0.6, 12), gownMat);
    torso.position.y = 1.8; torso.castShadow = true;
    this.enemy.add(torso);
    this.enemyParts.torso = torso;
    const apron = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.85), apronMat);
    apron.position.set(0, 1.45, 0.19);
    apron.rotation.x = 0.1;
    this.enemy.add(apron);
    const stain = new THREE.Mesh(new THREE.CircleGeometry(0.09, 10),
      new THREE.MeshStandardMaterial({ color: 0x4a1712, roughness: 1, transparent: true, opacity: 0.7 }));
    stain.position.set(0.05, 1.5, 0.2);
    this.enemy.add(stain);
    // neck (too long)
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.055, 0.22, 8), skinMat);
    neck.position.y = 2.18;
    this.enemy.add(neck);

    // ---- head group (tracks the player)
    const headGroup = new THREE.Group();
    headGroup.position.y = 2.32;
    this.enemy.add(headGroup);
    this.enemyParts.headGroup = headGroup;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.155, 16, 14), skinMat);
    head.scale.set(0.92, 1.12, 0.98);
    head.castShadow = true;
    headGroup.add(head);
    // hair: back mass + hanging strands in front of the face
    const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat);
    hairTop.position.y = 0.03; hairTop.rotation.x = 0.45; hairTop.scale.set(1, 1.4, 1);
    headGroup.add(hairTop);
    for (let i = 0; i < 7; i++) {
      const strand = new THREE.Mesh(new THREE.PlaneGeometry(0.045, rand(0.3, 0.52)), hairMat);
      const a = -0.7 + i * 0.23;
      strand.position.set(Math.sin(a) * 0.13, -0.12, Math.cos(a) * 0.135);
      strand.rotation.y = a;
      strand.rotation.x = 0.12;
      headGroup.add(strand);
    }
    const backHair = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.75), hairMat);
    backHair.position.set(0, -0.28, -0.14);
    headGroup.add(backHair);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(0.21, 0.05, 0.15),
      new THREE.MeshStandardMaterial({ color: 0xd4dbd2, roughness: 0.9 }));
    cap.position.set(0.02, 0.17, -0.02); cap.rotation.z = 0.18;
    headGroup.add(cap);
    const eyes: THREE.Mesh[] = [];
    for (const sx of [-0.055, 0.055]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.017, 8, 8),
        new THREE.MeshBasicMaterial({ color: new THREE.Color(1.5, 1.7, 1.9) }));
      eye.position.set(sx, 0.015, 0.135);
      headGroup.add(eye);
      eyes.push(eye);
      // dark socket behind each eye
      const socket = new THREE.Mesh(new THREE.CircleGeometry(0.034, 10),
        new THREE.MeshBasicMaterial({ color: 0x05070a }));
      socket.position.set(sx, 0.015, 0.128);
      headGroup.add(socket);
    }
    this.enemyParts.eyes = eyes;
    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.1, 0.06), skinMat);
    jaw.position.set(0, -0.13, 0.06);
    headGroup.add(jaw);
    this.enemyParts.jaw = jaw;
    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.085, 0.02),
      new THREE.MeshBasicMaterial({ color: 0x03040a }));
    mouth.position.set(0, -0.1, 0.135);
    headGroup.add(mouth);

    // ---- arms: shoulder groups → upper arm, forearm, long fingers
    const mkArm = (side: number) => {
      const grp = new THREE.Group();
      grp.position.set(side * 0.23, 2.02, 0.01);
      const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.03, 0.52, 8), gownMat);
      upper.geometry.translate(0, -0.26, 0);
      upper.castShadow = true;
      grp.add(upper);
      const fore = new THREE.Group();
      fore.position.y = -0.52;
      const foreMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.02, 0.5, 8), skinMat);
      foreMesh.geometry.translate(0, -0.25, 0);
      foreMesh.castShadow = true;
      fore.add(foreMesh);
      for (let f = 0; f < 4; f++) {
        const finger = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.003, 0.17, 5), skinMat);
        finger.geometry.translate(0, -0.085, 0);
        finger.position.set(-0.03 + f * 0.02, -0.5, 0.01);
        finger.rotation.x = 0.35 + f * 0.06;
        fore.add(finger);
      }
      fore.rotation.x = 0.3;
      grp.add(fore);
      grp.rotation.z = side * 0.2;
      this.enemy.add(grp);
      return grp;
    };
    this.enemyParts.armL = mkArm(-1);
    this.enemyParts.armR = mkArm(1);
    const glow = new THREE.PointLight(0x6f9fd8, 2.0, 5.2, 1.8);
    glow.position.y = 1.9;
    this.enemy.add(glow);
    this.scene.add(this.enemy);
  }

  // ------------------------------------------------------- player avatar
  private buildAvatar() {
    const uniform = new THREE.MeshStandardMaterial({ color: 0x24344d, roughness: 0.85 });
    const pants = new THREE.MeshStandardMaterial({ color: 0x1a2230, roughness: 0.9 });
    const skin = new THREE.MeshStandardMaterial({ color: 0xc9a486, roughness: 0.75 });
    const accent = new THREE.MeshStandardMaterial({ color: 0xe8b34b, roughness: 0.5, metalness: 0.3 });
    this.avatarMats = { uniform, pants, skin, accent };

    const hips = new THREE.Group();
    hips.position.y = 0.96;
    this.avatar.add(hips);
    this.avatarParts.hips = hips;

    const mkLeg = (side: number) => {
      const g = new THREE.Group();
      g.position.set(side * 0.11, 0, 0);
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.92, 0.15), pants);
      leg.geometry.translate(0, -0.46, 0);
      leg.castShadow = true;
      g.add(leg);
      const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.07, 0.24),
        new THREE.MeshStandardMaterial({ color: 0x14181e, roughness: 0.7 }));
      shoe.position.set(0, -0.9, 0.04);
      g.add(shoe);
      hips.add(g);
      return g;
    };
    this.avatarParts.legL = mkLeg(-1);
    this.avatarParts.legR = mkLeg(1);

    const torso = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.62, 0.24), uniform);
    torso.position.y = 0.34;
    torso.castShadow = true;
    hips.add(torso);
    this.avatarParts.torso = torso;
    // belt with buckle (accent)
    const belt = new THREE.Mesh(new THREE.BoxGeometry(0.44, 0.08, 0.26), accent);
    belt.position.y = 0.05;
    hips.add(belt);

    const mkArm = (side: number) => {
      const g = new THREE.Group();
      g.position.set(side * 0.27, 0.62, 0);
      const arm = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.62, 0.11), uniform);
      arm.geometry.translate(0, -0.31, 0);
      arm.castShadow = true;
      g.add(arm);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), skin);
      hand.position.y = -0.64;
      g.add(hand);
      hips.add(g);
      return g;
    };
    this.avatarParts.armL = mkArm(-1);
    this.avatarParts.armR = mkArm(1);
    // held flashlight in right hand
    const heldBody = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.023, 0.15, 10),
      new THREE.MeshStandardMaterial({ color: 0x22282f, metalness: 0.6, roughness: 0.4 }));
    heldBody.rotation.x = Math.PI / 2;
    heldBody.position.set(0, -0.64, 0.08);
    this.avatarParts.armR.add(heldBody);
    const heldLens = new THREE.Mesh(new THREE.CircleGeometry(0.018, 10),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(2.2, 2.0, 1.5) }));
    heldLens.position.set(0, -0.64, 0.16);
    this.avatarParts.armR.add(heldLens);

    const headG = new THREE.Group();
    headG.position.y = 0.78;
    hips.add(headG);
    this.avatarParts.headG = headG;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.115, 14, 12), skin);
    head.scale.set(0.92, 1.08, 0.98);
    head.castShadow = true;
    headG.add(head);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 10, 0, Math.PI * 2, 0, Math.PI * 0.5),
      new THREE.MeshStandardMaterial({ color: 0x241a14, roughness: 1 }));
    hair.position.y = 0.02;
    headG.add(hair);
    // variant extras
    const guardCap = new THREE.Group();
    const capTop = new THREE.Mesh(new THREE.CylinderGeometry(0.125, 0.13, 0.07, 12), uniform);
    capTop.position.y = 0.1;
    guardCap.add(capTop);
    const brim = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.015, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x141a24, roughness: 0.6 }));
    brim.position.set(0, 0.07, 0.13);
    guardCap.add(brim);
    const badge = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.01), accent);
    badge.position.set(0, 0.1, 0.13);
    guardCap.add(badge);
    headG.add(guardCap);
    const nurseCap = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.035, 0.1),
      new THREE.MeshStandardMaterial({ color: 0xdde4da, roughness: 0.9 }));
    nurseCap.position.set(0, 0.125, 0);
    headG.add(nurseCap);
    const coat = new THREE.Mesh(new THREE.BoxGeometry(0.47, 0.85, 0.28),
      new THREE.MeshStandardMaterial({ color: 0xd8dde2, roughness: 0.9 }));
    coat.position.y = 0.22;
    coat.castShadow = true;
    hips.add(coat);
    const stetho = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.012, 6, 16, Math.PI * 1.4),
      new THREE.MeshStandardMaterial({ color: 0x2a323e, metalness: 0.5, roughness: 0.4 }));
    stetho.position.set(0, 0.6, 0.1);
    stetho.rotation.set(0.4, 0, Math.PI * 0.8);
    hips.add(stetho);
    const gown = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.34, 0.95, 12, 1, true),
      new THREE.MeshStandardMaterial({ color: 0x9fb2c1, roughness: 0.95, side: THREE.DoubleSide }));
    gown.position.y = -0.28;
    hips.add(gown);
    const wristGold = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.014, 6, 14),
      new THREE.MeshStandardMaterial({ color: 0xffd166, emissive: 0xe0a43a, emissiveIntensity: 0.7, metalness: 0.4, roughness: 0.3 }));
    wristGold.position.y = -0.55;
    wristGold.rotation.x = Math.PI / 2;
    this.avatarParts.armL.add(wristGold);

    this.avatarExtras = { guardCap, nurseCap, coat, stetho, gown, wristGold };
    // soft contact shadow blob so the character feels grounded
    const blob = new THREE.Mesh(new THREE.CircleGeometry(0.42, 18),
      new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.42, depthWrite: false }));
    blob.rotation.x = -Math.PI / 2;
    blob.position.y = 0.02;
    this.avatar.add(blob);
    this.avatar.traverse((o) => o.layers.set(2)); // only TP/orbit/preview cameras see it
    this.scene.add(this.avatar);
    this.setAvatar("guard");
  }

  private setAvatar(id: AvatarId) {
    const def = avatarById(id);
    if (this.avatarMats.uniform) this.avatarMats.uniform.color.setHex(def.uniform);
    if (this.avatarMats.pants) this.avatarMats.pants.color.setHex(def.pants);
    if (this.avatarMats.skin) this.avatarMats.skin.color.setHex(def.skin);
    if (this.avatarMats.accent) this.avatarMats.accent.color.setHex(def.accent);
    const ex = this.avatarExtras;
    if (ex.guardCap) ex.guardCap.visible = def.id === "guard";
    if (ex.nurseCap) ex.nurseCap.visible = def.id === "nurse";
    if (ex.coat) ex.coat.visible = def.id === "doctor";
    if (ex.stetho) ex.stetho.visible = def.id === "doctor";
    if (ex.gown) ex.gown.visible = def.id === "patient";
    if (ex.wristGold) ex.wristGold.visible = def.id === "patient";
    this.perkStamina = def.perk.staminaMul;
    this.perkRegen = def.perk.regenMul;
    this.perkNoise = def.perk.noiseMul;
    this.perkCrouch = def.perk.crouchMul;
    this.perkCoffee = def.perk.coffee;
  }

  private cycleView() {
    this.viewMode = this.viewMode === "fp" ? "tp" : this.viewMode === "tp" ? "orbit" : "fp";
    this.tpInit = false;
    const name = this.viewMode === "fp" ? "Camera: FIRST PERSON" : this.viewMode === "tp" ? "Camera: THIRD PERSON" : "Camera: ORBIT (cinematic)";
    this.emit({ type: "toast", text: name, kind: "info" });
    this.audio.ui();
  }

  private syncAvatar(dt: number, t: number) {
    const speed = Math.hypot(this.vel.x, this.vel.z);
    this.avatar.position.set(this.pPos.x, 0, this.pPos.z);
    // face movement; when idle face where the camera faces
    const target = speed > 0.5 ? Math.atan2(this.vel.x, this.vel.z) : this.yaw + Math.PI;
    let diff = target - this.avatarFacing;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.avatarFacing += diff * Math.min(1, dt * 8);
    this.avatar.rotation.y = this.avatarFacing;
    if (speed > 0.3) this.avWalkPhase += dt * (2.2 + speed * 1.7);
    const ph = this.avWalkPhase;
    const amp = clamp(speed / 3.2, 0, 1.15);
    const parts = this.avatarParts;
    if (parts.legL) parts.legL.rotation.x = Math.sin(ph) * 0.62 * amp + (this.crouch ? -0.55 : 0);
    if (parts.legR) parts.legR.rotation.x = -Math.sin(ph) * 0.62 * amp + (this.crouch ? 0.35 : 0);
    if (parts.armL) parts.armL.rotation.x = -Math.sin(ph) * 0.5 * amp + Math.sin(t * 1.4) * 0.04;
    if (parts.armR) {
      const raise = this.flashlightOn && this.battery > 0 ? -1.22 : -0.15;
      parts.armR.rotation.x = lerp(parts.armR.rotation.x, raise + Math.sin(ph) * 0.07 * amp, Math.min(1, dt * 7));
    }
    if (parts.hips) {
      const targetY = this.crouch ? 0.64 : 0.96;
      parts.hips.position.y = lerp(parts.hips.position.y, targetY + (speed > 0.3 ? Math.abs(Math.sin(ph)) * 0.035 : 0), Math.min(1, dt * 10));
      parts.hips.rotation.x = this.crouch ? 0.32 : speed > 4 ? 0.14 : 0.03;
    }
    if (parts.torso) parts.torso.scale.set(1 + Math.sin(t * 1.5) * 0.015, 1, 1 + Math.sin(t * 1.5) * 0.02);
    if (parts.headG) parts.headG.rotation.x = -this.pitch * 0.55;
    this.avatar.visible = !this.hiddenLocker;
  }

  private buildViewmodel() {
    this.viewmodel = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x22282f, roughness: 0.45, metalness: 0.6 });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.025, 0.17, 12), bodyMat);
    body.rotation.x = Math.PI / 2;
    this.viewmodel.add(body);
    const headM = new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.028, 0.05, 12), bodyMat);
    headM.rotation.x = Math.PI / 2;
    headM.position.z = -0.1;
    this.viewmodel.add(headM);
    this.vmLensMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(2.4, 2.2, 1.7) });
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.027, 12), this.vmLensMat);
    lens.position.z = -0.127;
    lens.rotation.y = Math.PI;
    this.viewmodel.add(lens);
    // fake volumetric cone
    this.vmConeMat = new THREE.MeshBasicMaterial({
      color: 0xffe9bb, transparent: true, opacity: 0.045, blending: THREE.AdditiveBlending,
      depthWrite: false, side: THREE.DoubleSide, fog: false,
    });
    const cone = new THREE.Mesh(new THREE.ConeGeometry(1.5, 6.5, 20, 1, true), this.vmConeMat);
    cone.rotation.x = -Math.PI / 2;
    cone.position.z = -3.35;
    this.viewmodel.add(cone);
    // a hint of fingers gripping it
    const gripMat = new THREE.MeshStandardMaterial({ color: 0x2e2622, roughness: 0.85 });
    for (let i = 0; i < 3; i++) {
      const f = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.045, 0.03), gripMat);
      f.position.set(-0.018 + i * 0.018, -0.028, 0.03 - i * 0.008);
      f.rotation.x = 0.5;
      this.viewmodel.add(f);
    }
    this.viewmodel.position.set(0.27, -0.25, -0.5);
    this.viewmodel.rotation.set(0.06, -0.05, 0);
    this.viewmodel.traverse((o) => o.layers.set(1));
    this.cam.add(this.viewmodel);
  }

  private buildDust() {
    const N = 550;
    const pos = new Float32Array(N * 3);
    const floorCells: [number, number][] = [];
    for (let gy = 0; gy < GH; gy++) for (let gx = 0; gx < GW; gx++)
      if (this.grid[gy * GW + gx] === 1) floorCells.push([gx, gy]);
    for (let i = 0; i < N; i++) {
      const [gx, gy] = floorCells[(Math.random() * floorCells.length) | 0];
      const w = cellToWorld(gx, gy);
      pos[i * 3] = w.x + rand(-1, 1); pos[i * 3 + 1] = rand(0.2, 2.9); pos[i * 3 + 2] = w.z + rand(-1, 1);
    }
    this.dustBase = pos.slice();
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    this.dust = new THREE.Points(geo, new THREE.PointsMaterial({
      color: 0x9db8d4, size: 0.03, transparent: true, opacity: 0.5, depthWrite: false, sizeAttenuation: true,
    }));
    this.scene.add(this.dust);
  }

  // ============================================================ input
  private onResize = () => {
    const w = this.container.clientWidth, h = this.container.clientHeight;
    if (w === 0 || h === 0) return;
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
    this.cam.aspect = w / h; this.cam.updateProjectionMatrix();
    this.cctv.aspect = w / h; this.cctv.updateProjectionMatrix();
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) { if (["Tab", "Space"].includes(e.code)) e.preventDefault(); return; }
    this.keys.add(e.code);
    this.intro = 0;
    if (!this.running || this.paused || this.over) return;
    if (this.cameraMode) {
      if (e.code === "KeyA" || e.code === "ArrowLeft") this.switchCam(-1);
      if (e.code === "KeyD" || e.code === "ArrowRight") this.switchCam(1);
      if (e.code === "KeyE" || e.code === "Escape") this.exitCameraMode();
      return;
    }
    switch (e.code) {
      case "KeyE": this.doInteract(); break;
      case "KeyF": this.toggleFlashlight(); break;
      case "KeyQ": this.throwVial(); break;
      case "KeyB": this.swapBattery(); break;
      case "KeyG": this.drinkCoffee(); break;
      case "KeyC": case "ControlLeft": this.crouch = !this.crouch; break;
      case "KeyV": this.cycleView(); break;
      case "KeyN": case "Tab": e.preventDefault(); this.emit({ type: "openNotebook" }); break;
      case "KeyP": this.emit({ type: "requestPause" }); break;
    }
  };
  private onKeyUp = (e: KeyboardEvent) => { this.keys.delete(e.code); };
  private dragging = false;
  private onMouseDown = (e: MouseEvent) => { if (e.button === 0) { this.dragging = true; this.intro = 0; } };
  private onMouseUp = () => { this.dragging = false; };
  private onMouseMove = (e: MouseEvent) => {
    if ((!document.pointerLockElement && !this.dragging) || this.paused || !this.running) return;
    const s = 0.0021 * (this.settings?.sensitivity ?? 1);
    this.yaw -= e.movementX * s;
    this.pitch = clamp(this.pitch - e.movementY * s, -1.35, 1.35);
  };
  private onLockChange = () => {
    if (!document.pointerLockElement && this.running && !this.paused && !this.cameraMode && !this.touchMode && !this.over)
      this.emit({ type: "requestPause" });
  };
  private onCanvasClick = () => {
    this.audio.init();
    this.intro = 0;
    if (this.running && !this.paused && !this.cameraMode && !this.touchMode && !document.pointerLockElement && !this.over)
      this.lockPointer();
  };

  private bindInput() {
    window.addEventListener("resize", this.onResize);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("mousemove", this.onMouseMove);
    window.addEventListener("mousedown", this.onMouseDown);
    window.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("pointerlockchange", this.onLockChange);
    this.renderer.domElement.addEventListener("click", this.onCanvasClick);
  }

  // ============================================================ helpers
  private code(gx: number, gy: number): number {
    if (gx < 0 || gy < 0 || gx >= GW || gy >= GH) return 0;
    return this.grid[gy * GW + gx];
  }

  private doorBlocked(d: DoorState) { return d.open01 < 0.65; }

  private cellBlockedForPlayer(gx: number, gy: number): boolean {
    const c = this.code(gx, gy);
    if (c === 0 || c === 3) return true;
    if (c === 2) { const d = this.doorByCell.get(`${gx},${gy}`); if (d && this.doorBlocked(d)) return true; if (d?.def.lock === "exit") return true; }
    return false;
  }

  private losBlocked(a: THREE.Vector3, b: THREE.Vector3): boolean {
    const dist = a.distanceTo(b);
    const steps = Math.max(2, Math.floor(dist / 0.4));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      const x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t;
      const { gx, gy } = worldToCell(x, z);
      const c = this.code(gx, gy);
      if (c === 0) return true;
      if (c === 2) { const d = this.doorByCell.get(`${gx},${gy}`); if (d && this.doorBlocked(d)) return true; }
      if (c === 3 && this.heightGrid[gy * GW + gx] > 1.45) return true;
    }
    return false;
  }

  private findPath(sx: number, sy: number, tx: number, ty: number, forEnemy: boolean): THREE.Vector3[] {
    if (sx === tx && sy === ty) return [];
    const passable = (gx: number, gy: number) => {
      const c = this.code(gx, gy);
      if (c === 1) return true;
      if (c === 2) {
        const d = this.doorByCell.get(`${gx},${gy}`);
        if (!d) return true;
        if (d.def.lock === "exit") return false;
        if (forEnemy) {
          if (this.eState === "watcher") return !d.locked && d.open01 > 0.65;
          return !d.locked;
        }
        return d.open01 > 0.65;
      }
      return false;
    };
    const prev = new Int32Array(GW * GH).fill(-2);
    const queue: number[] = [sy * GW + sx];
    prev[sy * GW + sx] = -1;
    const goal = ty * GW + tx;
    let head = 0;
    while (head < queue.length) {
      const cur = queue[head++];
      if (cur === goal) break;
      const cx = cur % GW, cy = (cur / GW) | 0;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = cx + dx, ny = cy + dy;
        if (nx < 0 || ny < 0 || nx >= GW || ny >= GH) continue;
        const ni = ny * GW + nx;
        if (prev[ni] !== -2) continue;
        if (!passable(nx, ny) && ni !== goal) continue;
        prev[ni] = cur;
        queue.push(ni);
      }
    }
    if (prev[goal] === -2) return [];
    const cells: number[] = [];
    let cur = goal;
    while (cur !== -1 && cur !== sy * GW + sx) { cells.push(cur); cur = prev[cur]; }
    cells.reverse();
    return cells.map((ci) => {
      const w = cellToWorld(ci % GW, (ci / GW) | 0);
      return new THREE.Vector3(w.x, 0, w.z);
    });
  }

  private forwardVec(): THREE.Vector3 {
    return new THREE.Vector3(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch), -Math.cos(this.yaw) * Math.cos(this.pitch)).normalize();
  }

  private isSprinting(): boolean {
    return (this.keys.has("ShiftLeft") || this.keys.has("ShiftRight") || this.touchSprint) && this.stamina > 2 && !this.crouch;
  }

  // ============================================================ main loop
  private tick(dt: number, t: number) {
    this.frameCount++;
    if (!this.running) {
      const w = cellToWorld(18, 22);
      this.cam.position.set(w.x + Math.sin(t * 0.05) * 2, 1.7, w.z);
      this.cam.lookAt(w.x, 1.5, w.z - 12);
      this.enemy.position.copy(this.ePos);
      this.updateLights(dt, t);
      this.renderFrame(t);
      return;
    }
    if (!this.paused && !this.over) {
      this.updateGame(dt, t);
    }
    this.updateVisuals(dt, t);
    this.renderFrame(t);
  }

  private renderFrame(t: number) {
    // live security-monitor preview (low-res, every 4th frame)
    if (this.flags.camsOnline && !this.cameraMode && this.frameCount % 4 === 0 && this.running) {
      this.previewT += 1;
      if (this.previewT > 60) { this.previewT = 0; this.previewIdx = (this.previewIdx + 1) % CAMERAS.length; }
      const def = CAMERAS[this.previewIdx];
      const cw = cellToWorld(def.gx, def.gy);
      const tw = cellToWorld(def.tx, def.ty);
      this.previewCam.position.set(cw.x, 2.85, cw.z);
      this.previewCam.lookAt(tw.x, 1.1, tw.z);
      this.renderer.setRenderTarget(this.previewRT);
      this.renderer.render(this.scene, this.previewCam);
      this.renderer.setRenderTarget(null);
      if (this.monitorLiveMat && this.monitorLiveMat.map !== this.previewRT.texture) {
        this.monitorLiveMat.map = this.previewRT.texture;
        this.monitorLiveMat.color.setRGB(1.1, 1.25, 1.1);
        this.monitorLiveMat.needsUpdate = true;
      }
    }
    // film-grade uniforms react to sanity
    const u = this.gradePass.uniforms as Record<string, THREE.IUniform>;
    u.uTime.value = t;
    const sanityFx = this.running ? clamp((42 - this.sanity) / 42, 0, 1) : 0;
    u.uChroma.value = 0.0011 + sanityFx * 0.0045 + (this.eState === "chase" ? 0.0016 + Math.sin(t * 26) * 0.0007 : 0);
    u.uGrain.value = 0.045 + sanityFx * 0.05;
    u.uVig.value = 0.42 + sanityFx * 0.22;
    this.renderPass.camera = this.cameraMode ? this.cctv : this.cam;
    this.composer.render();
  }

  private updateGame(dt: number, t: number) {
    for (let i = this.introTimers.length - 1; i >= 0; i--) {
      this.introTimers[i].t -= dt;
      if (this.introTimers[i].t <= 0) { this.introTimers[i].fn(); this.introTimers.splice(i, 1); }
    }
    for (let i = this.vialTimers.length - 1; i >= 0; i--) {
      this.vialTimers[i].t -= dt;
      if (this.vialTimers[i].t <= 0) {
        const pos = this.vialTimers[i].pos;
        this.audio.throwBreak();
        this.emitNoise(pos, 14);
        this.spawnBurst(pos, 0x9fe8ff, 20, 2.2);
        this.spawnFlash(pos, 0x9fe8ff);
        this.vialTimers.splice(i, 1);
      }
    }
    if (this.intro > 0) this.intro -= dt;

    // clock: 1 game hour = 55 real seconds
    this.timeMin += dt * (60 / 55);
    const hour = Math.floor(this.timeMin / 60);
    if (hour > this.lastHour) {
      this.lastHour = hour;
      if (hour >= 1 && hour <= 5) {
        this.addScore(50);
        this.subtitle(this.lang === "mn" ? HOUR_LINES_MN[hour] : HOUR_LINES[hour]);
        this.audio.clang();
        this.flickerBurst = 0.8;
        this.checkpoint();
        if (hour === 1 && this.eState === "dormant") this.wakeEnemy();
      }
      if (hour >= 6 && !this.flags.sixAM) {
        this.flags.sixAM = true;
        this.audio.success();
        this.subtitle("6:00 AM. The exit lock clicks open. RUN.");
        this.emit({ type: "toast", text: "6:00 AM — the Lobby exit is unlocked!", kind: "item" });
      }
    }

    if (this.catchLock > 0) this.catchLock -= dt;
    if (this.graceTimer > 0) this.graceTimer -= dt;

    if (!this.cameraMode && this.catchLock <= 0 && this.intro <= 0) this.updatePlayer(dt);
    if (this.catchLock <= 1.4) this.updateEnemy(dt, t);
    else this.syncEnemyMesh(t);
    this.updateSurvival(dt);
    this.updateDoors(dt);
    this.computePrompt();
    this.syncMission();
    this.updateWheelchair(dt);

    // ambient dread events
    this.eventTimer -= dt;
    if (this.eventTimer <= 0) {
      this.eventTimer = rand(13, 28) - Math.min(8, hour * 1.2);
      const r = Math.random();
      if (r < 0.3) this.audio.clang();
      else if (r < 0.5) { this.audio.whisper(); this.sanity = Math.max(1, this.sanity - 1.5); }
      else if (r < 0.64) this.flickerBurst = rand(0.4, 1.0);
      else if (r < 0.76) this.audio.distantMoan();
      else if (r < 0.88) this.popRandomLight();
      else {
        this.audio.door();
        const wp = WAYPOINTS[(Math.random() * WAYPOINTS.length) | 0];
        const w = cellToWorld(wp[0], wp[1]);
        this.emitNoise(new THREE.Vector3(w.x, 0, w.z), 15);
      }
    }

    this.checkpointT -= dt;
    if (this.checkpointT <= 0) {
      this.checkpointT = 20;
      const c = worldToCell(this.pPos.x, this.pPos.z);
      if (roomAt(c.gx, c.gy)?.id === "security") this.checkpoint();
    }

    if (this.cameraMode && this.missionIdx === 2 && !this.flags.camEventDone && this.camIndex === 2) {
      this.camEventT += dt;
      if (this.camEventT > 0.4 && !this.flags.camFigure) {
        this.flags.camFigure = true;
        this.teleportEnemy(6, 11);
        this.eFacing = Math.PI / 2;
        this.enemy.visible = true;
        this.eState = "dormant";
        this.subtitle("CAM 3 — Ward A. Something is standing between the beds.");
      }
      if (this.camEventT > 3.6) {
        this.flags.camEventDone = true;
        this.emit({ type: "staticBurst" });
        this.audio.staticBurst(0.8);
        this.audio.stinger();
        this.enemy.visible = false;
        this.teleportEnemy(ENEMY_SPAWN.gx, ENEMY_SPAWN.gy);
        this.subtitle("Gone. …Ward A. Now. Before she counts YOU.");
        this.advanceMission();
        this.checkpoint();
      }
    } else if (this.camIndex !== 2) {
      this.camEventT = 0;
    }

    if (!this.flags.whisperDone && !this.flags.whisperAsked && this.missionIdx >= 3) {
      const c = worldToCell(this.pPos.x, this.pPos.z);
      if (roomAt(c.gx, c.gy)?.id === "records") {
        this.flags.whisperAsked = true;
        this.audio.whisper();
        this.emit({ type: "choice", id: "whisper" });
      }
    }

    this.audio.update(dt);
    this.audio.setBreath(this.stamina < 30 ? (30 - this.stamina) / 30 * 0.9 : this.eState === "chase" ? 0.5 : 0);
  }

  private popRandomLight() {
    const candidates = this.practicalLights.filter((pl, i) => i !== 0 && pl.deadT <= 0);
    if (!candidates.length) return;
    const pl = candidates[(Math.random() * candidates.length) | 0];
    pl.deadT = 22;
    this.audio.sparkPop();
    this.spawnBurst(pl.fixPos.clone(), 0xffcf7a, 26, 2.4);
    this.flickerBurst = Math.max(this.flickerBurst, 0.35);
  }

  private updateWheelchair(dt: number) {
    if (!this.wheelchair) return;
    if (this.wcRoll < 0 && !this.flags.wcDone && this.timeMin >= 55) {
      const c = worldToCell(this.pPos.x, this.pPos.z);
      if (c.gy >= 15 && c.gy <= 16 && c.gx >= 9 && c.gx <= 26) {
        this.wcRoll = 0;
        this.audio.squeak();
        this.wcSqueakT = 1.4;
      }
    }
    if (this.wcRoll >= 0) {
      this.wcRoll += dt / 3.4;
      const k = Math.min(1, this.wcRoll);
      const ease = 1 - Math.pow(1 - k, 2.2);
      const a = cellToWorld(3, 15), b = cellToWorld(14, 15);
      this.wheelchair.position.set(lerp(a.x, b.x, ease), 0, a.z - 0.4 + Math.sin(k * 9) * 0.05 * (1 - k));
      this.wheelchair.rotation.z = Math.sin(k * 22) * 0.02 * (1 - k);
      for (const wh of this.wcWheels) wh.rotation.x += dt * 7 * (1 - k * 0.6);
      this.wcSqueakT -= dt;
      if (this.wcSqueakT <= 0 && k < 0.9) { this.audio.squeak(); this.wcSqueakT = 1.3; }
      if (k >= 1) { this.wcRoll = -1; this.flags.wcDone = true; this.audio.clang(); }
    }
  }

  private updatePlayer(dt: number) {
    if (this.touchLook.x !== 0 || this.touchLook.y !== 0) {
      const s = 0.0042 * (this.settings?.sensitivity ?? 1);
      this.yaw -= this.touchLook.x * s;
      this.pitch = clamp(this.pitch - this.touchLook.y * s, -1.35, 1.35);
      this.touchLook.x = 0; this.touchLook.y = 0;
    }
    if (this.hiddenLocker) {
      this.vel.multiplyScalar(0.8);
      this.stamina = Math.min(100, this.stamina + dt * 16); // catch your breath while hiding
      return;
    }

    let ix = 0, iz = 0;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) iz -= 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) iz += 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) ix -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) ix += 1;
    ix += this.touchMove.x; iz += this.touchMove.y;
    const len = Math.hypot(ix, iz);
    if (len > 1) { ix /= len; iz /= len; }
    const moving = len > 0.08;
    const sprint = this.isSprinting() && moving && iz < 0.15;
    if (sprint) this.stamina = Math.max(0, this.stamina - dt * 21 * this.perkStamina);
    else this.stamina = Math.min(100, this.stamina + dt * 13);
    const speed = this.crouch ? 1.75 * this.perkCrouch : sprint ? 5.35 : 3.15;

    const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
    const fx = -sin, fz = -cos;
    const rx = cos, rz = -sin;
    const wishX = (rx * ix + fx * -iz) * speed;
    const wishZ = (rz * ix + fz * -iz) * speed;
    // smooth acceleration / deceleration
    const accel = moving ? 11 : 14;
    this.vel.x = lerp(this.vel.x, wishX, Math.min(1, dt * accel));
    this.vel.z = lerp(this.vel.z, wishZ, Math.min(1, dt * accel));
    const moveX = this.vel.x * dt;
    const moveZ = this.vel.z * dt;

    const r = 0.34;
    const curCell = worldToCell(this.pPos.x, this.pPos.z);
    const tryMove = (dx: number, dz: number) => {
      const nx = this.pPos.x + dx, nz = this.pPos.z + dz;
      const cells = [
        worldToCell(nx - r, nz - r), worldToCell(nx + r, nz - r),
        worldToCell(nx - r, nz + r), worldToCell(nx + r, nz + r),
      ];
      for (const c of cells) {
        // never let a closing door soft-lock the player inside its own cell
        if (c.gx === curCell.gx && c.gy === curCell.gy) continue;
        if (this.cellBlockedForPlayer(c.gx, c.gy)) return false;
      }
      this.pPos.x = nx; this.pPos.z = nz;
      return true;
    };
    if (moveX !== 0 && !tryMove(moveX, 0)) this.vel.x = 0;
    if (moveZ !== 0 && !tryMove(0, moveZ)) this.vel.z = 0;

    // eye height (crouch)
    const targetEye = this.crouch ? 1.12 : 1.62;
    this.eyeH = lerp(this.eyeH, targetEye, Math.min(1, dt * 9));
    this.pPos.y = this.eyeH;

    if (moving) {
      this.bobT += dt * (sprint ? 11 : this.crouch ? 5.5 : 7.5);
      this.stepTimer -= dt;
      if (this.stepTimer <= 0) {
        this.stepTimer = sprint ? 0.3 : this.crouch ? 0.55 : 0.44;
        this.audio.footstep(sprint);
      }
      if (sprint) this.emitNoise(this.pPos, 9.5 * this.perkNoise);
    }
  }

  private updateSurvival(dt: number) {
    if (this.flashlightOn && this.battery > 0) {
      this.battery = Math.max(0, this.battery - dt * 0.62);
      if (this.battery <= 0) {
        if (this.batteries > 0) { this.swapBattery(); }
        else {
          this.audio.fail();
          this.subtitle("Your flashlight dies. The dark leans closer. Find batteries.");
          this.emit({ type: "toast", text: "Flashlight dead — find a battery!", kind: "warn" });
        }
      }
    }
    const c = worldToCell(this.pPos.x, this.pPos.z);
    const inSecurity = roomAt(c.gx, c.gy)?.id === "security";
    const eDist = this.ePos.distanceTo(this.pPos);
    if (inSecurity && this.flags.camsOnline) this.sanity = Math.min(100, this.sanity + dt * 1.7 * this.perkRegen);
    else if (inSecurity) this.sanity = Math.min(100, this.sanity + dt * 0.7 * this.perkRegen);
    const sheActive = this.enemy.visible && this.eState !== "dormant" && this.eState !== "banished";
    if (this.eState === "chase") this.sanity -= dt * 2.4;
    else if (sheActive && (this.detection > 0.1 || eDist < 5.5)) this.sanity -= dt * 1.0;
    if (!this.flashlightOn || this.battery <= 0) {
      if (!inSecurity) this.sanity -= dt * 0.5;
    }
    this.sanity = clamp(this.sanity, 0, 100);
    if (this.sanity <= 0) { this.finishGame("bad"); return; }

    const danger = this.eState === "chase" ? 1 : this.detection * 0.6 + clamp(1 - eDist / 16, 0, 0.6) * (sheActive ? 1 : 0);
    this.audio.setHeartbeat(clamp(danger + (this.sanity < 30 ? 0.25 : 0), 0, 1));
  }

  private updateDoors(dt: number) {
    for (const d of this.doors) {
      const target = d.open ? 1 : 0;
      if (Math.abs(d.open01 - target) > 0.001) {
        d.open01 = clamp(d.open01 + Math.sign(target - d.open01) * dt * 1.7, 0, 1);
        const eased = d.open01 * d.open01 * (3 - 2 * d.open01); // smoothstep
        const off = eased * (CELL * 0.92) * d.slideDir;
        if (d.horiz) d.mesh.position.set(d.basePos.x + off, d.basePos.y, d.basePos.z);
        else d.mesh.position.set(d.basePos.x, d.basePos.y, d.basePos.z + off);
      }
    }
  }

  // ============================================================ enemy
  private wakeEnemy() {
    this.enemy.visible = true;
    const c = worldToCell(this.ePos.x, this.ePos.z);
    if (this.code(c.gx, c.gy) !== 1) this.teleportEnemy(9, 12);
    this.eState = "patrol";
    this.audio.stinger();
    this.subtitle("Somewhere in the dark, something stops pretending to be furniture. She is awake.");
    this.pickPatrolTarget();
  }

  private startWatcher() {
    this.enemy.visible = true;
    this.teleportEnemy(17, 20);
    this.eState = "watcher";
    this.detection = 0;
    this.subtitle("She is coming down the spine. Remember RULE 3: she cannot move while you are watching her.");
  }

  private enemySpeed(): number {
    const hour = Math.floor(this.timeMin / 60);
    const diffMul = this.difficulty === "beginner" ? 0.9 : this.difficulty === "advanced" ? 1.07 : 1;
    const burnedCalm = this.flags.burned ? 0.92 : 1;
    switch (this.eState) {
      case "chase": return (4.25 + hour * 0.13) * diffMul * burnedCalm;
      case "watcher": return 3.55;
      case "investigate": return (2.1 + hour * 0.08) * diffMul;
      case "search": return 1.9 * diffMul;
      default: return (1.55 + hour * 0.09) * diffMul;
    }
  }

  private canSeePlayer(): boolean {
    if (this.hiddenLocker || this.graceTimer > 0 || !this.enemy.visible) return false;
    const d = this.ePos.distanceTo(this.pPos);
    const moving = this.vel.length() > 0.4;
    let maxD = 11.5 * (this.flashlightOn && this.battery > 0 ? 1.4 : 1) * (moving ? 1 : 0.75) * (this.crouch ? 0.72 : 1);
    if (this.cameraMode) maxD *= 0.85;
    if (d > maxD) return false;
    if (d > 2.3) {
      const fwd = new THREE.Vector3(Math.sin(this.eFacing), 0, Math.cos(this.eFacing));
      const to = new THREE.Vector3().subVectors(this.pPos, this.ePos).setY(0).normalize();
      if (fwd.dot(to) < 0.18) return false;
    }
    const eye = new THREE.Vector3(this.ePos.x, 2.1, this.ePos.z);
    return !this.losBlocked(eye, this.pPos);
  }

  private playerLookingAtEnemy(): boolean {
    const to = new THREE.Vector3().subVectors(new THREE.Vector3(this.ePos.x, 1.6, this.ePos.z), this.pPos);
    const dist = to.length();
    if (dist > 26) return false;
    to.normalize();
    if (this.forwardVec().dot(to) < 0.55) return false;
    return !this.losBlocked(this.pPos, new THREE.Vector3(this.ePos.x, 1.6, this.ePos.z));
  }

  private pickPatrolTarget() {
    const wp = WAYPOINTS[(Math.random() * WAYPOINTS.length) | 0];
    const ec = worldToCell(this.ePos.x, this.ePos.z);
    this.ePath = this.findPath(ec.gx, ec.gy, wp[0], wp[1], true);
    this.ePathIdx = 0;
    const w = cellToWorld(wp[0], wp[1]);
    this.eTarget.set(w.x, 0, w.z);
  }

  private pathTo(pos: THREE.Vector3) {
    const ec = worldToCell(this.ePos.x, this.ePos.z);
    const tc = worldToCell(pos.x, pos.z);
    this.ePath = this.findPath(ec.gx, ec.gy, clamp(tc.gx, 0, GW - 1), clamp(tc.gy, 0, GH - 1), true);
    this.ePathIdx = 0;
    this.eTarget.copy(pos);
  }

  private emitNoise(pos: THREE.Vector3, radius: number) {
    if (!this.enemy.visible) return;
    if (this.eState === "patrol" || this.eState === "search" || this.eState === "investigate") {
      if (this.ePos.distanceTo(pos) < radius) {
        this.eState = "investigate";
        this.eWait = 0;
        this.pathTo(pos.clone());
      }
    }
  }

  private moveEnemyAlongPath(dt: number) {
    this.eMoving = false;
    if (this.ePathIdx >= this.ePath.length) return false;
    const target = this.ePath[this.ePathIdx];
    const nc = worldToCell(target.x, target.z);
    if (this.code(nc.gx, nc.gy) === 2) {
      const d = this.doorByCell.get(`${nc.gx},${nc.gy}`);
      if (d && this.doorBlocked(d)) {
        if (d.locked || this.eState === "watcher") { this.ePath = []; return false; }
        this.eDoorTimer += dt;
        if (this.eDoorTimer > 0.85) {
          d.open = true; this.audio.door(); this.eDoorTimer = 0;
        }
        return true;
      }
    }
    const to = new THREE.Vector3().subVectors(target, this.ePos).setY(0);
    const dist = to.length();
    if (dist < 0.25) { this.ePathIdx++; return true; }
    to.normalize();
    const speed = this.enemySpeed();
    this.ePos.addScaledVector(to, Math.min(dist, speed * dt));
    this.eMoving = true;
    this.eWalkPhase += dt * speed * 2.1;
    const desired = Math.atan2(to.x, to.z);
    let diff = desired - this.eFacing;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.eFacing += diff * Math.min(1, dt * 5);
    this.eStepTimer -= dt;
    if (this.eStepTimer <= 0) {
      this.eStepTimer = this.eState === "chase" ? 0.32 : 0.55;
      const pd = this.ePos.distanceTo(this.pPos);
      this.audio.enemyStep(clamp(1 - pd / 20, 0, 1));
    }
    return true;
  }

  private syncEnemyMesh(t: number) {
    this.enemy.position.copy(this.ePos);
    this.enemy.rotation.y = this.eFacing;
    const parts = this.enemyParts;
    const chase = this.eState === "chase";
    const phase = this.eWalkPhase;
    // body sway & breathing
    this.enemy.position.y = this.eMoving ? Math.abs(Math.sin(phase)) * 0.045 : Math.sin(t * 1.6) * 0.015;
    if (parts.skirt) parts.skirt.rotation.z = this.eMoving ? Math.sin(phase) * 0.045 : Math.sin(t * 0.8) * 0.012;
    if (parts.torso) parts.torso.scale.setScalar(1 + Math.sin(t * 1.6) * 0.02);
    // arms: swing when walking, reach when chasing, hang when still
    const reach = chase ? -1.15 : 0.25;
    const swing = this.eMoving ? Math.sin(phase) * (chase ? 0.25 : 0.5) : Math.sin(t * 1.3) * 0.05;
    if (parts.armL) parts.armL.rotation.x = lerp(parts.armL.rotation.x, reach + swing, 0.12);
    if (parts.armR) parts.armR.rotation.x = lerp(parts.armR.rotation.x, reach - swing, 0.12);
    // head: tracks the player when alert, otherwise slow uncanny tilts
    if (parts.headGroup) {
      const alert = this.detection > 0.15 || chase || this.eState === "watcher";
      if (alert && this.enemy.visible) {
        const to = new THREE.Vector3().subVectors(this.pPos, new THREE.Vector3(this.ePos.x, 2.32, this.ePos.z));
        const worldYawTo = Math.atan2(to.x, to.z);
        let rel = worldYawTo - this.eFacing;
        while (rel > Math.PI) rel -= Math.PI * 2;
        while (rel < -Math.PI) rel += Math.PI * 2;
        parts.headGroup.rotation.y = lerp(parts.headGroup.rotation.y, clamp(rel, -1.1, 1.1), 0.1);
        const pitchTo = clamp(Math.atan2(2.32 - this.pPos.y, Math.max(0.5, to.setY(0).length())) - 0.1, -0.3, 0.5);
        parts.headGroup.rotation.x = lerp(parts.headGroup.rotation.x, pitchTo, 0.1);
      } else {
        parts.headGroup.rotation.y = lerp(parts.headGroup.rotation.y, Math.sin(t * 0.35) * 0.3, 0.03);
        parts.headGroup.rotation.x = lerp(parts.headGroup.rotation.x, 0.14 + Math.sin(t * 0.5) * 0.05, 0.03);
      }
      parts.headGroup.rotation.z = Math.sin(t * 0.7) * 0.13 + (chase ? Math.sin(t * 13) * 0.05 : 0);
    }
    if (parts.jaw) parts.jaw.position.y = chase ? -0.17 + Math.sin(t * 9) * 0.012 : -0.13;
    if (parts.eyes) {
      const c = chase ? new THREE.Color(2.6, 0.45, 0.35) : new THREE.Color(1.5, 1.7, 1.9);
      parts.eyes.forEach((e) => (e.material as THREE.MeshBasicMaterial).color.copy(c));
    }
  }

  private updateEnemy(dt: number, t: number) {
    this.syncEnemyMesh(t);
    if (!this.enemy.visible && this.eState !== "dormant" && this.eState !== "banished") return;

    const distToPlayer = this.ePos.distanceTo(this.pPos);

    switch (this.eState) {
      case "dormant": {
        if (this.timeMin >= 60) { this.wakeEnemy(); break; }
        if (this.enemy.visible && distToPlayer < 1.7 && this.missionIdx < 2) {
          this.audio.whisper();
          this.enemy.visible = false;
          this.subtitle("She was never there. She was never there. She was never—");
        }
        return;
      }
      case "banished": {
        this.banishTimer -= dt;
        if (this.banishTimer <= 0) {
          this.enemy.visible = true;
          this.teleportEnemy(31, 8);
          this.eState = "patrol";
          this.pickPatrolTarget();
        }
        return;
      }
      case "watcher": {
        const watched = this.playerLookingAtEnemy() && !this.cameraMode;
        if (!watched) {
          this.eRepath -= dt;
          if (this.eRepath <= 0) {
            this.eRepath = 0.5;
            // if you hid, she only knows where you vanished
            this.pathTo((this.hiddenLocker ? this.lastKnown : this.pPos).clone());
          }
          const moved = this.moveEnemyAlongPath(dt);
          if (!moved && this.ePath.length === 0) {
            if (Math.random() < dt * 0.4) this.audio.locked();
          }
        } else {
          const to = new THREE.Vector3().subVectors(this.pPos, this.ePos);
          this.eFacing = Math.atan2(to.x, to.z);
        }
        if (distToPlayer < 1.25 && !this.hiddenLocker) this.catchPlayer();
        return;
      }
      default: break;
    }

    const sees = this.canSeePlayer();
    if (sees) {
      const rate = 2.3 - (distToPlayer / 16) * 1.5;
      this.detection = clamp(this.detection + dt * rate, 0, 1);
      this.lastKnown.copy(this.pPos);
      this.loseTimer = 0;
    } else {
      this.detection = clamp(this.detection - dt * 0.4, 0, 1);
      this.loseTimer += dt;
    }
    if (distToPlayer < 1.5 && !this.hiddenLocker && this.graceTimer <= 0) this.detection = 1;

    if (this.detection >= 1 && this.eState !== "chase") {
      this.eState = "chase";
      if (!this.chaseAnnounced) {
        this.chaseAnnounced = true;
        this.audio.stinger();
        this.shake = Math.max(this.shake, 0.35);
        this.emit({ type: "toast", text: "SHE SEES YOU — RUN, BREAK LINE OF SIGHT, HIDE!", kind: "warn" });
      }
    }

    switch (this.eState) {
      case "patrol": {
        if (!this.moveEnemyAlongPath(dt)) this.pickPatrolTarget();
        if (this.ePath.length === 0) {
          this.eWait += dt;
          if (this.eWait > 2.5) {
            this.eWait = 0;
            const far = WAYPOINTS.filter(([gx, gy]) => {
              const w = cellToWorld(gx, gy);
              return new THREE.Vector3(w.x, 0, w.z).distanceTo(this.pPos) > 14;
            });
            const pick = far.length ? far[(Math.random() * far.length) | 0] : ([17, 12] as [number, number]);
            this.teleportEnemy(pick[0], pick[1]);
            this.pickPatrolTarget();
          }
        } else this.eWait = 0;
        if (this.detection > 0.4) { this.eState = "investigate"; this.pathTo(this.lastKnown.clone()); }
        break;
      }
      case "investigate": {
        const moving = this.moveEnemyAlongPath(dt);
        if (!moving) {
          this.eWait += dt;
          this.eFacing += dt * 1.4 * Math.sin(t * 0.9);
          if (this.eWait > 2.6) { this.eWait = 0; this.eState = "patrol"; this.pickPatrolTarget(); }
        }
        break;
      }
      case "search": {
        const moving = this.moveEnemyAlongPath(dt);
        if (!moving) {
          this.eWait += dt;
          if (this.eWait > 1.2) {
            this.eWait = 0;
            if (Math.random() < 0.45) { this.eState = "patrol"; this.pickPatrolTarget(); }
            else {
              const c = worldToCell(this.lastKnown.x, this.lastKnown.z);
              // only wander to genuine floor cells (never into furniture)
              for (let tries = 0; tries < 6; tries++) {
                const gx = clamp(c.gx + ((Math.random() * 7) | 0) - 3, 1, GW - 2);
                const gy = clamp(c.gy + ((Math.random() * 5) | 0) - 2, 1, GH - 2);
                if (this.code(gx, gy) !== 1) continue;
                const w = cellToWorld(gx, gy);
                this.pathTo(new THREE.Vector3(w.x, 0, w.z));
                break;
              }
            }
          }
        }
        break;
      }
      case "chase": {
        this.eRepath -= dt;
        if (this.eRepath <= 0) { this.eRepath = 0.35; this.pathTo(this.pPos.clone()); }
        this.moveEnemyAlongPath(dt);
        if (distToPlayer < 1.15 && !this.hiddenLocker) { this.catchPlayer(); return; }
        if (this.loseTimer > 4.5) {
          this.eState = "search";
          this.chaseAnnounced = false;
          this.eWait = 0;
          this.pathTo(this.lastKnown.clone());
        }
        break;
      }
      default: break;
    }

    if (this.hiddenLocker && this.eState === "chase" && distToPlayer < 1.4 && this.flags.seenHiding) {
      this.catchPlayer();
    }
  }

  private catchPlayer() {
    if (this.over || this.catchLock > 0) return;
    this.catches++;
    this.catchLock = 2.5;
    this.audio.scream();
    this.shake = 1.2;
    this.addScore(-100);
    this.sanity -= 32;
    // she lunges: place her right in front of your face
    const fwd = this.forwardVec().setY(0).normalize();
    this.ePos.copy(this.pPos).addScaledVector(fwd, 0.72);
    this.ePos.y = 0;
    this.eFacing = Math.atan2(-fwd.x, -fwd.z);
    this.enemy.position.copy(this.ePos);
    this.enemy.rotation.y = this.eFacing;
    this.emit({ type: "caught", catches: this.catches });
    if (this.cameraMode) this.exitCameraMode(true);
    if (this.catches >= 3 || this.sanity <= 0) {
      setTimeout(() => this.finishGame("bad"), 900);
      return;
    }
    setTimeout(() => {
      if (this.over) return;
      if (this.hiddenLocker) this.exitLocker(true);
      const w = cellToWorld(CHECKPOINT.gx, CHECKPOINT.gy);
      this.pPos.set(w.x, 1.62, w.z);
      this.eyeH = 1.62; this.crouch = false;
      this.yaw = Math.PI * 0.75; this.pitch = 0;
      this.vel.set(0, 0, 0);
      this.teleportEnemy(31, 8);
      this.eState = this.flags.powerCut && !this.flags.breakerDone ? "watcher" : "patrol";
      if (this.eState === "watcher") this.teleportEnemy(17, 20);
      else this.pickPatrolTarget();
      this.detection = 0; this.chaseAnnounced = false;
      this.graceTimer = 5;
      this.subtitle(`You wake on the Security Room floor. Again. (${3 - this.catches} ${3 - this.catches === 1 ? "chance" : "chances"} left)`);
      this.checkpoint();
    }, 1300);
  }

  // ============================================================ interaction
  private computePrompt() {
    if (this.cameraMode) { this.promptTarget = null; return; }
    const fwd = this.forwardVec();
    let best: { kind: string; id: string; label: string; d: number } | null = null;
    const consider = (kind: string, id: string, label: string, pos: THREE.Vector3, maxD = 2.4) => {
      const to = new THREE.Vector3().subVectors(pos, this.pPos);
      const d = to.length();
      if (d > maxD) return;
      if (d > 0.9 && to.normalize().dot(fwd) < 0.15) return;
      if (!best || d < best.d) best = { kind, id, label, d };
    };

    if (this.hiddenLocker) {
      this.promptTarget = { kind: "lockerExit", id: "locker", label: "Leave the locker" };
      return;
    }
    for (const d of this.doors) {
      const w = cellToWorld(d.def.gx, d.def.gy);
      let label: string;
      if (d.def.lock === "exit") label = "Exit — end the shift";
      else if (d.locked) {
        label =
          d.def.lock === "keycard" ? (this.items.has("wardkey") ? "Unlock with keycard" : "Locked — needs a keycard") :
          d.def.lock === "morguekey" ? (this.items.has("morguekey") ? "Unlock with Morgue Key" : "Locked — heavy key required") :
          "Use keypad";
      } else label = d.open ? "Close door" : "Open door";
      consider("door", d.def.id, `${label} · ${d.def.sign}`, new THREE.Vector3(w.x, 1.4, w.z));
    }
    for (const p of PICKUPS) {
      if (this.takenPickups.has(p.id)) continue;
      const w = cellToWorld(p.gx, p.gy);
      const names: Record<PickupKind, string> = {
        battery: "Take battery", coffee: "Take coffee", vial: "Take glass vial",
        fuse: "Take the fuse", radiobattery: "Take radio battery",
        wristband: "Take patient wristband",
      };
      consider("pickup", p.id, names[p.kind], new THREE.Vector3(w.x, 0.9, w.z));
    }
    for (const l of this.lockerMeshes) {
      const w = cellToWorld(l.gx, l.gy);
      consider("locker", `${l.gx},${l.gy}`, "Hide in locker", new THREE.Vector3(w.x, 1.2, w.z));
    }
    for (const it of INTERACTABLES) {
      const w = cellToWorld(it.gx, it.gy);
      consider("interact", it.id, it.label, new THREE.Vector3(w.x, 1.2, w.z), 2.5);
    }
    this.promptTarget = best ? { kind: (best as { kind: string }).kind, id: (best as { id: string }).id, label: (best as { label: string }).label } : null;
  }

  private doInteract() {
    if (this.paused || this.over) return;
    if (this.cameraMode) { this.exitCameraMode(); return; }
    const t = this.promptTarget;
    if (!t) return;
    if (t.kind === "door") this.interactDoor(t.id);
    else if (t.kind === "pickup") this.interactPickup(t.id);
    else if (t.kind === "locker") this.enterLocker(t.id);
    else if (t.kind === "lockerExit") this.exitLocker();
    else if (t.kind === "interact") this.interactObject(t.id);
  }

  private interactDoor(id: string) {
    const d = this.doors.find((x) => x.def.id === id);
    if (!d) return;
    if (d.def.lock === "exit") { this.tryExit(); return; }
    if (d.locked) {
      if (d.def.lock === "keycard" && this.items.has("wardkey")) {
        d.locked = false; d.open = true; this.audio.unlock(); this.audio.door();
        this.emitNoise(this.pPos, 5);
        this.checkpoint();
      } else if (d.def.lock === "morguekey" && this.items.has("morguekey")) {
        d.locked = false; d.open = true; this.audio.unlock(); this.audio.door();
        this.checkpoint();
      } else if (d.def.lock === "keypadPharmacy" || d.def.lock === "keypadOffice") {
        this.audio.keypadBeep(true);
        this.emit({ type: "openPuzzle", id: `keypad:${id}` });
      } else {
        this.audio.locked();
        this.subtitle(d.def.lock === "keycard" ? "Locked. A keycard reader blinks red." : "Locked. Something heavy holds this door.");
      }
      return;
    }
    d.open = !d.open;
    this.audio.door();
    if (d.open) this.emitNoise(this.pPos, 5);
  }

  private interactPickup(id: string) {
    const def = PICKUPS.find((p) => p.id === id);
    if (!def || this.takenPickups.has(id)) return;
    this.takenPickups.add(id);
    const m = this.pickupMeshes.get(id);
    if (m) { this.spawnBurst(m.position.clone(), 0xffe9a8, 10, 1.2); m.visible = false; }
    this.audio.pickup();
    this.addScore(10);
    switch (def.kind) {
      case "battery": this.batteries++; this.emit({ type: "toast", text: `Battery +1 (have ${this.batteries}) — B to swap`, kind: "item" }); break;
      case "coffee": this.coffees++; this.emit({ type: "toast", text: `Coffee +1 (have ${this.coffees}) — G to drink`, kind: "item" }); break;
      case "vial": this.vials++; this.emit({ type: "toast", text: `Glass vial +1 (have ${this.vials}) — Q to throw`, kind: "item" }); break;
      case "fuse":
        this.items.add("fuse");
        this.emit({ type: "toast", text: "Fuse acquired — take it to the Security Room", kind: "item" });
        break;
      case "radiobattery":
        this.items.add("radiobattery");
        this.emit({ type: "toast", text: "Radio battery acquired", kind: "item" });
        if (this.missionIdx === 4) this.subtitle("Now the radio in Radiology has a voice. Take this there.");
        break;
      case "wristband": {
        this.addScore(30);
        const n = this.wristbandCount();
        if (n >= 6) {
          this.addScore(250);
          this.emit({ type: "toast", text: "ALL 6 wristbands +250 — every patient accounted for. Almost.", kind: "item" });
        } else {
          this.emit({ type: "toast", text: `Patient wristband ${n}/6 +40 — someone small wore this.`, kind: "item" });
        }
        break;
      }
    }
  }

  private enterLocker(id: string) {
    const [gx, gy] = id.split(",").map(Number);
    const lm = this.lockerMeshes.find((l) => l.gx === gx && l.gy === gy);
    if (!lm) return;
    const w = cellToWorld(gx, gy);
    this.flags.seenHiding = this.detection > 0.55;
    this.lastKnown.copy(this.pPos); // where she last saw you before the door closed
    this.hiddenLocker = lm;
    lm.door.visible = false;
    this.pPos.set(w.x, 1.55, w.z);
    this.audio.door();
    this.emitNoise(this.pPos, 4);
    if (this.eState === "chase" && !this.flags.seenHiding) {
      this.loseTimer = 3.2;
    }
  }

  private exitLocker(silent = false) {
    if (!this.hiddenLocker) return;
    this.hiddenLocker.door.visible = true;
    const fwdC = worldToCell(this.pPos.x - Math.sin(this.yaw) * CELL, this.pPos.z - Math.cos(this.yaw) * CELL);
    const candidates = [fwdC,
      { gx: this.hiddenLocker.gx, gy: this.hiddenLocker.gy + 1 },
      { gx: this.hiddenLocker.gx, gy: this.hiddenLocker.gy - 1 },
      { gx: this.hiddenLocker.gx + 1, gy: this.hiddenLocker.gy },
      { gx: this.hiddenLocker.gx - 1, gy: this.hiddenLocker.gy }];
    for (const c of candidates) {
      if (this.code(c.gx, c.gy) === 1) {
        const w = cellToWorld(c.gx, c.gy);
        this.pPos.set(w.x, this.eyeH, w.z);
        break;
      }
    }
    this.hiddenLocker = null;
    if (!silent) this.audio.door();
  }

  private interactObject(id: string) {
    switch (id) {
      case "terminal": {
        if (!this.flags.signedIn) {
          this.flags.signedIn = true;
          this.items.add("wardkey");
          this.batteries++;
          this.addScore(50);
          this.emit({ type: "toast", text: "Signed in. Ward Keycard + battery acquired", kind: "item" });
          if (this.missionIdx === 0) this.advanceMission();
          this.checkpoint();
        }
        this.openDocument("shiftlog");
        break;
      }
      case "monitor": {
        if (!this.flags.camsOnline) {
          this.audio.staticBurst(0.4);
          this.subtitle("NO SIGNAL. The fuse box on the wall is dead.");
        } else this.enterCameraMode();
        break;
      }
      case "fusebox": {
        if (this.flags.camsOnline) { this.subtitle("The cameras hum. All five eyes are open."); break; }
        if (this.items.has("fuse")) {
          this.items.delete("fuse");
          this.flags.camsOnline = true;
          this.audio.breaker(); this.audio.success();
          this.shake = Math.max(this.shake, 0.2);
          this.spawnBurst(this.pPos.clone().add(new THREE.Vector3(0, 0.4, 0)), 0xffcf7a, 16, 1.8);
          this.emit({ type: "toast", text: "Surveillance online — use the monitor", kind: "item" });
          if (this.missionIdx === 1) this.advanceMission();
          this.checkpoint();
        } else {
          this.audio.locked();
          this.subtitle("Empty. This box needs a fuse. Storage keeps spares.");
        }
        break;
      }
      case "plaque": this.openDocument("plaque"); break;
      case "chart": {
        if (!this.flags.chartSolved) this.emit({ type: "openPuzzle", id: "chart" });
        else this.openDocument("anna");
        break;
      }
      case "incidentlog": {
        this.openDocument("incidentlog");
        if (this.missionIdx === 4 && !this.items.has("radiobattery"))
          setTimeout(() => this.subtitle("Take the radio battery from the counter before you leave."), 400);
        break;
      }
      case "radio": {
        if (!this.items.has("radiobattery")) {
          this.audio.staticBurst(0.25);
          this.subtitle("Dead. The battery slot is empty. The Pharmacy keeps spares.");
        } else if (!this.flags.radioSolved) {
          this.emit({ type: "openPuzzle", id: "radio" });
        } else {
          this.audio.staticBurst(0.7);
          this.subtitle("Only static now. It said what it came to say.");
        }
        break;
      }
      case "xray": this.openDocument("xray"); break;
      case "cabinet": {
        if (!this.flags.cabinetSolved) this.emit({ type: "openPuzzle", id: "cabinet" });
        else this.subtitle("The word-lock hangs open. Empty but the smell of dust.");
        break;
      }
      case "recordsfile": this.openDocument("recordsfile"); break;
      case "folder": this.openDocument("folder"); break;
      case "drawer": {
        if (!this.flags.keysTaken) {
          this.flags.keysTaken = true;
          this.items.add("morguekey");
          this.items.add("exitkey");
          this.audio.pickup();
          this.addScore(25);
          this.emit({ type: "toast", text: "Morgue Key + Exit Key acquired", kind: "item" });
          this.checkpoint();
        } else this.subtitle("Empty drawers. Only dust and one old coin you decide not to touch.");
        break;
      }
      case "breaker": {
        if (this.flags.powerCut && !this.flags.breakerDone) {
          this.flags.breakerDone = true;
          this.audio.breaker(); this.audio.success();
          this.shake = 0.4;
          this.spawnBurst(this.pPos.clone(), 0xffd9a0, 34, 3);
          this.spawnFlash(this.pPos.clone(), 0xffd9a0);
          this.subtitle("THUNK. The lights remember their job. Behind the door — silence. She withdraws… for now.");
          this.eState = "banished"; this.banishTimer = 26; this.enemy.visible = false;
          this.detection = 0;
          if (this.missionIdx === 7) this.advanceMission();
          this.checkpoint();
        } else if (!this.flags.powerCut) this.subtitle("The main breaker hums. Power is fine — for now.");
        else this.subtitle("Already humming. Good machine.");
        break;
      }
      case "body9": {
        if (this.items.has("tape0") && this.evidence.size >= 5) {
          this.emit({ type: "choice", id: "confront" });
        } else if (this.items.has("tape0")) {
          this.subtitle(`Tape 0 says: NAME her — but only with ALL the evidence in hand (${this.evidence.size}/5).`);
        } else {
          this.audio.whisper();
          this.subtitle("Under the sheet, something breathes. Once. Slowly. You do not lift it.");
        }
        break;
      }
      case "toetag": this.openDocument("toetag"); break;
      default: break;
    }
  }

  private tryExit() {
    const hasKey = this.items.has("exitkey");
    if (!hasKey && this.timeMin < 360) {
      this.audio.locked();
      this.subtitle("Locked. You need the Exit Key (Director's Office) — or survive until 6:00 AM.");
      return;
    }
    const ending: EndingId = !this.flags.burned && this.evidence.size >= 3 ? "truth" : "escape";
    this.finishGame(ending);
  }

  private finishGame(id: EndingId) {
    if (this.over) return;
    this.over = true;
    if (id === "escape") this.addScore(300);
    if (id === "truth") this.addScore(600);
    if (id === "secret") this.addScore(1000);
    if (id !== "bad" && this.timeMin < 360) this.addScore(Math.floor((360 - this.timeMin) * 2));
    this.audio.setHeartbeat(0);
    this.audio.setBreath(0);
    if (id === "bad") this.audio.scream(); else this.audio.success();
    if (document.pointerLockElement) document.exitPointerLock();
    this.emit({ type: "ending", id });
  }

  // ---- items ---------------------------------------------------------------
  private toggleFlashlight() {
    if (this.battery <= 0 && !this.flashlightOn) {
      this.audio.locked();
      this.emit({ type: "toast", text: "No charge. Press B if you carry a battery.", kind: "warn" });
      return;
    }
    this.flashlightOn = !this.flashlightOn;
    this.audio.ui();
  }

  private swapBattery() {
    if (this.batteries <= 0) {
      this.audio.locked();
      this.emit({ type: "toast", text: "No spare batteries.", kind: "warn" });
      return;
    }
    if (this.battery > 85) {
      this.emit({ type: "toast", text: "Battery is nearly full already.", kind: "info" });
      return;
    }
    this.batteries--;
    this.battery = 100;
    this.flashlightOn = true;
    this.audio.batterySwap();
    this.emit({ type: "toast", text: "Fresh battery — 100%", kind: "item" });
  }

  private drinkCoffee() {
    if (this.coffees <= 0) {
      this.emit({ type: "toast", text: "No coffee. The Waiting Room machine still works… sometimes.", kind: "warn" });
      return;
    }
    if (this.sanity > 92) { this.emit({ type: "toast", text: "You feel fine. Save it.", kind: "info" }); return; }
    this.coffees--;
    this.sanity = Math.min(100, this.sanity + this.perkCoffee);
    this.audio.drink();
    this.emit({ type: "toast", text: "Coffee. Bitter. Human. Sanity restored.", kind: "item" });
  }

  private throwVial() {
    if (this.vials <= 0) {
      this.emit({ type: "toast", text: "No vials to throw. The Pharmacy has glass.", kind: "warn" });
      return;
    }
    this.vials--;
    const fwd = this.forwardVec().setY(0).normalize();
    const land = this.pPos.clone();
    for (let step = 0.5; step <= 6.5; step += 0.5) {
      const probe = this.pPos.clone().addScaledVector(fwd, step);
      const c = worldToCell(probe.x, probe.z);
      if (this.cellBlockedForPlayer(c.gx, c.gy)) break;
      land.copy(probe);
    }
    land.y = 0.4;
    this.audio.ui();
    this.vialTimers.push({ t: 0.45, pos: land });
  }

  private spawnFlash(pos: THREE.Vector3, color: number) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.3, 10, 8),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 }));
    m.position.copy(pos);
    this.scene.add(m);
    this.effects.push({ mesh: m, ttl: 0.35 });
  }

  private spawnBurst(pos: THREE.Vector3, color: number, count = 22, speed = 2.4) {
    const positions = new Float32Array(count * 3);
    const vel = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = pos.x; positions[i * 3 + 1] = pos.y; positions[i * 3 + 2] = pos.z;
      const th = rand(0, Math.PI * 2), ph = rand(-0.4, 1.1), sp = speed * rand(0.3, 1);
      vel[i * 3] = Math.cos(th) * Math.cos(ph) * sp;
      vel[i * 3 + 1] = Math.sin(ph) * sp + 0.6;
      vel[i * 3 + 2] = Math.sin(th) * Math.cos(ph) * sp;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const points = new THREE.Points(geo, new THREE.PointsMaterial({
      color, size: 0.045, transparent: true, opacity: 1, depthWrite: false,
      blending: THREE.AdditiveBlending, sizeAttenuation: true,
    }));
    this.scene.add(points);
    this.bursts.push({ points, vel, ttl: 0.6, life: 0.6 });
  }

  // ---- CCTV ------------------------------------------------------------------
  private enterCameraMode() {
    this.cameraMode = true;
    this.camIndex = 0;
    this.camEventT = 0;
    this.audio.staticBurst(0.5);
    if (document.pointerLockElement) document.exitPointerLock();
    this.emit({ type: "cameraMode", on: true });
    this.emit({ type: "staticBurst" });
  }

  private exitCameraMode(silent = false) {
    this.cameraMode = false;
    this.flags.camFigure = false;
    if (!silent) this.audio.ui();
    this.emit({ type: "cameraMode", on: false });
    if (!this.touchMode && !this.paused && !this.over) this.lockPointer();
  }

  private switchCam(dir: number) {
    this.camIndex = (this.camIndex + dir + CAMERAS.length) % CAMERAS.length;
    this.camEventT = 0;
    this.flags.camFigure = false;
    this.audio.staticBurst(0.3);
    this.emit({ type: "staticBurst" });
  }

  private camSeesEnemy(): boolean {
    if (!this.enemy.visible) return false;
    const def = CAMERAS[this.camIndex];
    const cw = cellToWorld(def.gx, def.gy);
    const camPos = new THREE.Vector3(cw.x, 2.85, cw.z);
    if (camPos.distanceTo(new THREE.Vector3(this.ePos.x, 1.5, this.ePos.z)) > 18) return false;
    return !this.losBlocked(camPos, new THREE.Vector3(this.ePos.x, 1.5, this.ePos.z));
  }

  // ============================================================ visuals
  private powerLevel(): number {
    if (this.flags.powerCut && !this.flags.breakerDone) return 0.1;
    if (!this.flags.camsOnline) return 0.42;
    return 1;
  }

  private updateLights(dt: number, t: number) {
    const p = this.powerLevel();
    let burst = 1;
    if (this.flickerBurst > 0) {
      this.flickerBurst -= dt;
      burst = Math.random() < 0.45 ? rand(0.05, 0.4) : rand(0.7, 1.05);
    }
    for (const pl of this.practicalLights) {
      if (pl.deadT > 0) {
        pl.deadT -= dt;
        pl.light.intensity = pl.deadT > 21.6 ? pl.base * rand(0, 0.6) : 0;
        continue;
      }
      let f = 1;
      if (pl.bad) {
        const n = Math.sin(t * 31) * Math.sin(t * 7.3) * Math.sin(t * 2.1);
        f = n > 0.72 ? 0.12 : n > 0.55 ? 0.45 : 1;
        if (Math.random() < 0.01) f = 0.05;
      }
      pl.light.intensity = pl.base * p * f * burst;
    }
    for (const s of this.lightShafts) {
      const pl = this.practicalLights[s.idx];
      s.mat.opacity = pl ? clamp(pl.light.intensity / Math.max(1, pl.base), 0, 1) * 0.055 : 0;
    }
    if (this.swingPivot) {
      this.swingPivot.rotation.x = Math.sin(t * 1.25) * 0.42;
      this.swingPivot.rotation.z = Math.sin(t * 0.9) * 0.18;
    }
    for (const m of this.monitorMats) {
      if (m === this.monitorLiveMat && this.flags.camsOnline) continue;
      const on = this.flags.camsOnline ? 1 : 0.25;
      const fl = 0.85 + Math.sin(t * 40) * 0.05 + (Math.random() < 0.02 ? -0.3 : 0);
      m.color.setScalar(0.55 * on * fl + 0.12);
    }
  }

  private updateVisuals(dt: number, t: number) {
    this.updateLights(dt, t);
    let i = 0;
    for (const [, m] of this.pickupMeshes) {
      if (!m.visible) continue;
      m.position.y = 0.75 + Math.sin(t * 2 + i) * 0.07;
      m.rotation.y = t * 1.4 + i;
      i++;
    }
    const attr = this.dust.geometry.getAttribute("position") as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    for (let k = 0; k < arr.length; k += 3) {
      arr[k + 1] = this.dustBase[k + 1] + Math.sin(t * 0.25 + k) * 0.18;
      arr[k] = this.dustBase[k] + Math.sin(t * 0.12 + k * 0.7) * 0.12;
    }
    attr.needsUpdate = true;
    for (let k = this.effects.length - 1; k >= 0; k--) {
      const e = this.effects[k];
      e.ttl -= dt;
      e.mesh.scale.multiplyScalar(1 + dt * 9);
      (e.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, e.ttl / 0.35) * 0.9;
      if (e.ttl <= 0) { this.scene.remove(e.mesh); this.effects.splice(k, 1); }
    }
    for (let k = this.bursts.length - 1; k >= 0; k--) {
      const b = this.bursts[k];
      b.ttl -= dt;
      const posAttr = b.points.geometry.getAttribute("position") as THREE.BufferAttribute;
      const pa = posAttr.array as Float32Array;
      for (let j = 0; j < pa.length; j += 3) {
        pa[j] += b.vel[j] * dt;
        pa[j + 1] += b.vel[j + 1] * dt;
        pa[j + 2] += b.vel[j + 2] * dt;
        b.vel[j + 1] -= 5.5 * dt;
        if (pa[j + 1] < 0.03) { pa[j + 1] = 0.03; b.vel[j + 1] *= -0.4; }
      }
      posAttr.needsUpdate = true;
      (b.points.material as THREE.PointsMaterial).opacity = Math.max(0, b.ttl / b.life);
      if (b.ttl <= 0) {
        this.scene.remove(b.points);
        b.points.geometry.dispose();
        (b.points.material as THREE.Material).dispose();
        this.bursts.splice(k, 1);
      }
    }
    // rain scroll + clock hands
    for (const rt of this.rainTexs) rt.offset.y -= dt * 0.55;
    for (const ch of this.clockHands) {
      ch.min.rotation.z = -((this.timeMin % 60) / 60) * Math.PI * 2;
      ch.hour.rotation.z = -((this.timeMin / 720) % 1) * Math.PI * 2;
    }
    if (this.paused) this.updateDoors(dt);

    // ---------------- camera placement (FP / TP / ORBIT)
    if (this.shake > 0) this.shake = Math.max(0, this.shake - dt * 1.8);
    const shX = (Math.random() - 0.5) * this.shake * 0.14;
    const shY = (Math.random() - 0.5) * this.shake * 0.14;
    const effectiveView = this.hiddenLocker || this.cameraMode ? "fp" : this.viewMode;
    this.syncAvatar(dt, t);

    // pull a third-person camera in when a wall is in the way
    const camPullIn = (from: THREE.Vector3, to: THREE.Vector3): THREE.Vector3 => {
      let last = from.clone();
      for (let i = 1; i <= 14; i++) {
        const p = from.clone().lerp(to, i / 14);
        const c = worldToCell(p.x, p.z);
        const code = this.code(c.gx, c.gy);
        let blocked = code === 0 || p.y > WALL_H - 0.12 || p.y < 0.25;
        if (code === 2) { const d = this.doorByCell.get(`${c.gx},${c.gy}`); if (d && this.doorBlocked(d)) blocked = true; }
        if (code === 3 && this.heightGrid[c.gy * GW + c.gx] > p.y - 0.15) blocked = true;
        if (blocked) return last;
        last = p;
      }
      return to.clone();
    };

    if (this.intro > 0 && this.running) {
      // opening dolly: from the entrance into the lobby (you can see your guard)
      const k = clamp(1 - this.intro / 3.4, 0, 1);
      const e = 1 - Math.pow(1 - k, 3);
      const a = cellToWorld(18, 24);
      const b = cellToWorld(18, 23);
      this.cam.position.set(lerp(a.x, b.x, e), lerp(1.85, 1.62, e), lerp(a.z + 1.15, b.z, e));
      const look = cellToWorld(18, 17);
      this.cam.lookAt(look.x, lerp(1.2, 1.55, e), look.z);
      this.viewmodel.visible = false;
      this.cam.layers.enable(2);
    } else if (this.catchLock > 1.55) {
      const headPos = new THREE.Vector3(this.ePos.x, 2.25, this.ePos.z);
      this.cam.position.set(this.pPos.x + shX, this.pPos.y + shY, this.pPos.z);
      this.cam.lookAt(headPos);
      this.viewmodel.visible = false;
      this.cam.layers.disable(2);
    } else if (effectiveView === "fp") {
      this.viewmodel.visible = true;
      this.cam.layers.disable(2);
      const bobAmp = this.headbobOn ? 1 : 0;
      const bob = Math.sin(this.bobT) * 0.035 * bobAmp;
      this.cam.position.set(this.pPos.x + shX, this.pPos.y + bob + shY, this.pPos.z);
      const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
      const lat = this.vel.dot(right);
      const roll = clamp(-lat * 0.016, -0.035, 0.035) + Math.sin(this.bobT * 0.5) * 0.003 * bobAmp + (Math.random() - 0.5) * this.shake * 0.05;
      this.cam.rotation.set(this.pitch, this.yaw, roll);
    } else {
      // third-person & orbit: see your guard
      this.viewmodel.visible = false;
      this.cam.layers.enable(2);
      const headPos = new THREE.Vector3(this.pPos.x, this.pPos.y + 0.12, this.pPos.z);
      const fwd = this.forwardVec();
      let desired: THREE.Vector3;
      let lookAt: THREE.Vector3;
      if (effectiveView === "tp") {
        const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
        desired = headPos.clone().addScaledVector(fwd, -2.75).addScaledVector(right, 0.55);
        desired.y += 0.32;
        lookAt = headPos.clone().addScaledVector(fwd, 4.5);
      } else {
        if (this.vel.length() < 0.4) this.orbitAngle += dt * 0.24;
        const r = 3.5;
        desired = new THREE.Vector3(
          this.pPos.x + Math.sin(this.orbitAngle) * r,
          1.95 + Math.sin(t * 0.3) * 0.12,
          this.pPos.z + Math.cos(this.orbitAngle) * r,
        );
        lookAt = new THREE.Vector3(this.pPos.x, 1.25, this.pPos.z);
      }
      desired = camPullIn(headPos, desired);
      desired.y = clamp(desired.y, 0.35, WALL_H - 0.15);
      if (!this.tpInit) { this.tpCamPos.copy(desired); this.tpInit = true; }
      this.tpCamPos.lerp(desired, Math.min(1, dt * 11));
      this.cam.position.set(this.tpCamPos.x + shX, this.tpCamPos.y + shY, this.tpCamPos.z);
      this.cam.lookAt(lookAt);
    }

    // FOV: base + sprint kick
    const sprinting = this.isSprinting() && this.vel.length() > 3.4;
    const targetFov = this.baseFov + (sprinting ? 6 : 0) + (this.eState === "chase" ? 2 : 0);
    if (Math.abs(this.cam.fov - targetFov) > 0.05) {
      this.cam.fov = lerp(this.cam.fov, targetFov, Math.min(1, dt * 5));
      this.cam.updateProjectionMatrix();
    }

    // viewmodel sway from look velocity + bob
    const yawDelta = this.yaw - this.lastYaw;
    const pitchDelta = this.pitch - this.lastPitch;
    this.lastYaw = this.yaw; this.lastPitch = this.pitch;
    this.vmSway.x = lerp(this.vmSway.x, clamp(yawDelta * 1.4, -0.06, 0.06), Math.min(1, dt * 10));
    this.vmSway.y = lerp(this.vmSway.y, clamp(pitchDelta * 1.4, -0.05, 0.05), Math.min(1, dt * 10));
    const vmBob = this.headbobOn ? Math.sin(this.bobT * 1.0) * 0.008 * clamp(this.vel.length() / 3, 0, 1.4) : 0;
    const vmLowered = this.flashlightOn && this.battery > 0 ? 0 : 0.16;
    this.viewmodel.position.set(0.27 - this.vmSway.x, -0.25 - this.vmSway.y + vmBob - vmLowered, -0.5);
    this.viewmodel.rotation.set(0.06 + this.vmSway.y * 2 + vmLowered * 1.6, -0.05 + this.vmSway.x * 2, 0);

    // flashlight: from the eye in FP, from the avatar's hand in TP/orbit
    const on = this.flashlightOn && this.battery > 0;
    let intensity = on ? 85 : 0;
    if (on && this.battery < 18) intensity *= Math.random() < 0.25 ? rand(0.2, 0.6) : rand(0.8, 1);
    if (this.flickerBurst > 0) intensity *= Math.random() < 0.3 ? 0.4 : 1;
    if (on && this.enemy.visible && this.ePos.distanceTo(this.pPos) < 4.5 && this.eState !== "dormant" && this.eState !== "banished")
      intensity *= Math.random() < 0.3 ? rand(0.15, 0.5) : 1;
    this.flashlight.intensity = intensity;
    if (effectiveView === "fp" || this.intro > 0) {
      this.flashlight.position.copy(this.cam.position);
      const fwdV = this.intro > 0 ? new THREE.Vector3(0, 0, -1) : this.forwardVec();
      this.flashlight.target.position.copy(this.cam.position.clone().addScaledVector(fwdV, 8));
    } else {
      const rightA = new THREE.Vector3(Math.cos(this.avatarFacing), 0, -Math.sin(this.avatarFacing));
      const fwdA = new THREE.Vector3(Math.sin(this.avatarFacing), 0, Math.cos(this.avatarFacing));
      const hand = new THREE.Vector3(this.pPos.x, 1.35, this.pPos.z).addScaledVector(rightA, 0.3).addScaledVector(fwdA, 0.35);
      this.flashlight.position.copy(hand);
      const camDir = new THREE.Vector3();
      this.cam.getWorldDirection(camDir);
      this.flashlight.target.position.copy(this.cam.position.clone().addScaledVector(camDir, 11));
    }
    this.phoneGlow.position.copy(this.cam.position);
    this.phoneGlow.intensity = on ? 1.2 : 2.6;
    this.vmLensMat.color.setRGB(on ? 2.4 : 0.25, on ? 2.2 : 0.25, on ? 1.7 : 0.28);
    this.vmConeMat.opacity = on && effectiveView === "fp" ? 0.04 * (intensity / 85) + 0.008 : 0;

    if (this.cameraMode) {
      const def = CAMERAS[this.camIndex];
      const cw = cellToWorld(def.gx, def.gy);
      const tw = cellToWorld(def.tx, def.ty);
      this.cctv.position.set(cw.x, 2.85, cw.z);
      const baseAng = Math.atan2(tw.x - cw.x, tw.z - cw.z);
      const pan = Math.sin(t * 0.16) * 0.38;
      const lookDist = 14;
      this.cctv.lookAt(cw.x + Math.sin(baseAng + pan) * lookDist, 1.1, cw.z + Math.cos(baseAng + pan) * lookDist);
      this.cctv.rotation.z += (Math.random() - 0.5) * 0.004;
    }
  }
}
