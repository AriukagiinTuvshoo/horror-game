// ---------------------------------------------------------------------------
// Procedural audio engine — everything is synthesized with WebAudio.
// ---------------------------------------------------------------------------

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private heartRate = 0; // 0..1 intensity
  private heartTimer = 0;
  private volume = 0.8;
  voiceEnabled = true;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(this.ctx.destination);

    // shared noise buffer (2s white noise)
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;

    this.startAmbience();
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
  }

  private noise(dur: number, filterType: BiquadFilterType, freq: number, gainVal: number, when = 0, q = 0.8) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const t = this.ctx.currentTime + when;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = filterType; f.frequency.value = freq; f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gainVal, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t); src.stop(t + dur + 0.1);
  }

  private tone(freq: number, dur: number, type: OscillatorType, gainVal: number, when = 0, slideTo?: number) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + when;
    const o = this.ctx.createOscillator();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gainVal, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t); o.stop(t + dur + 0.1);
  }

  private startAmbience() {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    // ventilation rumble
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf; src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass"; f.frequency.value = 220;
    const g = this.ctx.createGain(); g.gain.value = 0.05;
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = 0.07;
    const lfoG = this.ctx.createGain(); lfoG.gain.value = 0.02;
    lfo.connect(lfoG).connect(g.gain);
    src.connect(f).connect(g).connect(this.master);
    src.start(); lfo.start();
    // mains hum
    const hum = this.ctx.createOscillator(); hum.type = "sine"; hum.frequency.value = 55;
    const humG = this.ctx.createGain(); humG.gain.value = 0.012;
    hum.connect(humG).connect(this.master);
    hum.start();
    // deep dread drone
    const drone = this.ctx.createOscillator(); drone.type = "triangle"; drone.frequency.value = 36;
    const droneG = this.ctx.createGain(); droneG.gain.value = 0.02;
    drone.connect(droneG).connect(this.master);
    drone.start();
  }

  // called every frame by the engine for the heartbeat
  update(dt: number) {
    if (!this.ctx) return;
    if (this.heartRate > 0.03) {
      this.heartTimer -= dt;
      if (this.heartTimer <= 0) {
        const interval = 1.05 - this.heartRate * 0.55; // 1.05s .. 0.5s
        this.heartTimer = interval;
        const g = 0.1 + this.heartRate * 0.3;
        this.tone(58, 0.16, "sine", g, 0, 40);
        this.tone(52, 0.13, "sine", g * 0.7, 0.16, 38);
      }
    }
  }

  setHeartbeat(v: number) { this.heartRate = Math.max(0, Math.min(1, v)); }

  // ------------------------------------------------------------ one shots
  ui() { this.tone(660, 0.06, "square", 0.05); }
  pickup() { this.tone(880, 0.1, "sine", 0.12); this.tone(1320, 0.16, "sine", 0.1, 0.07); }
  success() { [523, 659, 784].forEach((f, i) => this.tone(f, 0.22, "triangle", 0.12, i * 0.09)); }
  fail() { this.tone(160, 0.35, "sawtooth", 0.12, 0, 90); this.tone(118, 0.4, "sawtooth", 0.1, 0.05, 70); }
  unlock() { this.noise(0.08, "highpass", 2000, 0.15); this.tone(1046, 0.12, "square", 0.08, 0.06); }
  locked() { this.noise(0.12, "bandpass", 300, 0.25, 0, 2); this.tone(90, 0.15, "square", 0.12); }
  door() {
    this.noise(0.5, "bandpass", 500, 0.10, 0, 4);
    this.tone(140, 0.45, "sawtooth", 0.03, 0, 95);
  }
  keypadBeep(ok: boolean) { this.tone(ok ? 1175 : 220, ok ? 0.15 : 0.3, "square", 0.09); }
  footstep(run: boolean) { this.noise(run ? 0.14 : 0.1, "lowpass", run ? 500 : 380, run ? 0.16 : 0.08); }
  enemyStep(intensity: number) {
    this.noise(0.16, "lowpass", 260, 0.05 + intensity * 0.22);
    this.tone(48, 0.14, "sine", intensity * 0.12, 0, 34);
  }
  throwBreak() {
    this.noise(0.06, "highpass", 3000, 0.2);
    this.noise(0.3, "bandpass", 2400, 0.22, 0.03, 3);
    this.tone(2100, 0.18, "triangle", 0.08, 0.02, 1400);
  }
  clang() { // distant metal hit
    const base = 180 + Math.random() * 120;
    [1, 2.7, 4.3].forEach((m, i) => this.tone(base * m, 1.4 - i * 0.3, "sine", 0.07 / (i + 1)));
    this.noise(0.2, "bandpass", 900, 0.05, 0, 2);
  }
  whisper() {
    for (let i = 0; i < 5; i++) {
      this.noise(0.16 + Math.random() * 0.12, "bandpass", 1400 + Math.random() * 900, 0.07, i * 0.17, 6);
    }
  }
  staticBurst(dur = 0.6) { this.noise(dur, "highpass", 1200, 0.16); }
  stinger() {
    [110, 116.5, 220, 233, 440].forEach((f) => this.tone(f, 1.1, "sawtooth", 0.09, 0, f * 0.94));
    this.noise(0.5, "bandpass", 700, 0.14, 0, 1.2);
  }
  scream() {
    this.tone(1400, 0.9, "sawtooth", 0.16, 0, 500);
    this.tone(1870, 0.8, "square", 0.08, 0.05, 620);
    this.noise(0.9, "bandpass", 1800, 0.16, 0, 2);
    [110, 116.5, 55].forEach((f) => this.tone(f, 1.4, "sawtooth", 0.12, 0, f * 0.9));
  }
  drink() { this.noise(0.4, "lowpass", 800, 0.1); this.tone(520, 0.2, "sine", 0.06, 0.1, 700); }
  batterySwap() { this.noise(0.07, "highpass", 2500, 0.14); this.noise(0.07, "highpass", 2500, 0.14, 0.12); }
  breaker() {
    this.noise(0.15, "lowpass", 400, 0.3);
    this.tone(55, 0.8, "sine", 0.22, 0.1, 58);
    this.tone(110, 0.5, "triangle", 0.1, 0.15);
  }
  phoneRing() {
    for (let r = 0; r < 2; r++)
      for (let i = 0; i < 3; i++) this.tone(1050, 0.09, "square", 0.06, r * 0.9 + i * 0.13);
  }

  // ------------------------------------------------------- breathing layer
  private breathGain: GainNode | null = null;
  private breathLevel = 0;
  private ensureBreath() {
    if (!this.ctx || !this.master || !this.noiseBuf || this.breathGain) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf; src.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type = "bandpass"; f.frequency.value = 620; f.Q.value = 0.7;
    this.breathGain = this.ctx.createGain(); this.breathGain.gain.value = 0;
    // inhale/exhale LFO
    const lfo = this.ctx.createOscillator(); lfo.frequency.value = 0.32;
    const lfoG = this.ctx.createGain(); lfoG.gain.value = 0.5;
    const shaper = this.ctx.createWaveShaper();
    shaper.curve = new Float32Array([-0.2, 0, 0.4, 1]);
    lfo.connect(shaper).connect(lfoG).connect(this.breathGain.gain);
    src.connect(f).connect(this.breathGain).connect(this.master);
    src.start(); lfo.start();
  }
  setBreath(v: number) {
    this.breathLevel = Math.max(0, Math.min(1, v));
    if (this.ctx) this.ensureBreath();
    if (this.breathGain && this.ctx)
      this.breathGain.gain.setTargetAtTime(this.breathLevel * 0.05, this.ctx.currentTime, 0.4);
  }
  sparkPop() {
    this.noise(0.08, "highpass", 4000, 0.3);
    this.noise(0.35, "bandpass", 3200, 0.16, 0.03, 2);
    this.tone(180, 0.12, "square", 0.1, 0, 60);
  }
  distantMoan() {
    const base = 130 + Math.random() * 60;
    this.tone(base, 1.8, "sine", 0.05, 0, base * 0.82);
    this.tone(base * 1.5, 1.6, "sine", 0.025, 0.15, base * 1.2);
    this.noise(1.4, "bandpass", 500, 0.02, 0.1, 3);
  }
  squeak() { // wheelchair / swinging metal
    this.tone(1150, 0.28, "sine", 0.045, 0, 900);
    this.tone(1250, 0.24, "sine", 0.035, 0.32, 980);
    this.noise(0.5, "bandpass", 1000, 0.025, 0, 6);
  }

  // ------------------------------------------------------------- radio TTS
  speak(text: string, onEnd?: () => void) {
    if (!this.voiceEnabled || !("speechSynthesis" in window)) { onEnd?.(); return; }
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 0.82; u.pitch = 0.55; u.volume = Math.min(1, this.volume + 0.2);
      const voices = window.speechSynthesis.getVoices().filter((v) => v.lang.startsWith("en"));
      if (voices.length) u.voice = voices.find((v) => /male|david|daniel|george/i.test(v.name)) ?? voices[0];
      u.onend = () => onEnd?.();
      u.onerror = () => onEnd?.();
      window.speechSynthesis.speak(u);
    } catch { onEnd?.(); }
  }

  stopSpeak() {
    try { if ("speechSynthesis" in window) window.speechSynthesis.cancel(); } catch { /* noop */ }
  }
}
