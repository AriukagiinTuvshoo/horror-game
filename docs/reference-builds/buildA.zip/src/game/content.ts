// ---------------------------------------------------------------------------
// THE LAST NIGHT SHIFT — story content, missions, vocabulary, documents.
// Bilingual: English (learning content) + Mongolian (full localization).
// ---------------------------------------------------------------------------

export type Diff = "beginner" | "intermediate" | "advanced";
export type Lang = "en" | "mn";
export type AvatarId = "guard" | "doctor" | "nurse" | "patient";

export interface Settings {
  volume: number;
  brightness: number;
  sensitivity: number;
  subtitles: boolean;
  voice: boolean;
  difficulty: Diff;
  fov: number;
  graphics: "high" | "low";
  headbob: boolean;
  objectiveMarker: boolean;
  language: Lang;
  avatar: AvatarId;
}

export const DEFAULT_SETTINGS: Settings = {
  volume: 0.8,
  brightness: 1.1,
  sensitivity: 1,
  subtitles: true,
  voice: true,
  difficulty: "intermediate",
  fov: 74,
  graphics: "high",
  headbob: true,
  objectiveMarker: true,
  language: "en",
  avatar: "guard",
};

export const PHARMACY_CODE = "4339";
export const OFFICE_CODE = "1999";

// ------------------------------------------------------------------- avatars
export interface AvatarDef {
  id: AvatarId;
  name: string;
  role: Record<Lang, string>;
  desc: Record<Lang, string>;
  uniform: number; pants: number; skin: number; accent: number;
  perk: { staminaMul: number; regenMul: number; noiseMul: number; crouchMul: number; coffee: number };
}

export const AVATARS: AvatarDef[] = [
  {
    id: "guard", name: "D. BAYAR",
    role: { en: "Security Guard", mn: "Харуул" },
    desc: { en: "Trained for long nights. Sprinting drains 22% less stamina.", mn: "Урт шөнөд бэлтгэгдсэн. Гүйхэд тэсвэр 22%-иар бага зарцуулна." },
    uniform: 0x24344d, pants: 0x1a2230, skin: 0xc9a486, accent: 0xe8b34b,
    perk: { staminaMul: 0.78, regenMul: 1, noiseMul: 1, crouchMul: 1, coffee: 32 },
  },
  {
    id: "doctor", name: "DR. SARN",
    role: { en: "Doctor", mn: "Эмч" },
    desc: { en: "Knows this hospital's sins. Sanity recovers 60% faster in Security; coffee helps more.", mn: "Энэ эмнэлгийн нүглийг мэднэ. Аюулгүй өрөөнд ухаан санаа 60% хурдан сэргэнэ; кофе илүү үйлчилнэ." },
    uniform: 0xd8dde2, pants: 0x3a4656, skin: 0xd9b08c, accent: 0x7fb2e5,
    perk: { staminaMul: 1, regenMul: 1.6, noiseMul: 1, crouchMul: 1, coffee: 44 },
  },
  {
    id: "nurse", name: "NURSE ANU",
    role: { en: "Nurse", mn: "Сувилагч" },
    desc: { en: "Soft steps, soft hands. Sprinting makes 32% less noise.", mn: "Зөөлөн алхаа, зөөлөн гар. Гүйхэд 32%-иар бага чимээ гаргана." },
    uniform: 0x2e6b66, pants: 0x274f4b, skin: 0xe0b896, accent: 0xdde4da,
    perk: { staminaMul: 1, regenMul: 1, noiseMul: 0.68, crouchMul: 1, coffee: 32 },
  },
  {
    id: "patient", name: "PATIENT No.9",
    role: { en: "Patient No.9", mn: "9-р өвчтөн" },
    desc: { en: "You never really left. Crouch-walking is 20% faster — the floors remember you.", mn: "Чи үнэндээ хэзээ ч яваагүй. Сууж явах нь 20% хурдан — шал чамайг санаж байна." },
    uniform: 0x9fb2c1, pants: 0x8fa3b5, skin: 0xd8c8b4, accent: 0xffd166,
    perk: { staminaMul: 1, regenMul: 1, noiseMul: 1, crouchMul: 1.2, coffee: 32 },
  },
];

export const avatarById = (id: AvatarId): AvatarDef => AVATARS.find((a) => a.id === id) ?? AVATARS[0];

// ---------------------------------------------------------------- vocabulary
export interface VocabWord {
  word: string;
  pos: string;
  def: string;
  example: string;
  defMn: string;
  exampleMn: string;
}

export const VOCAB: VocabWord[] = [
  { word: "ward", pos: "noun", def: "A room in a hospital where patients stay in beds.", example: "Ward A has four beds — and one of them is still warm.", defMn: "Өвчтөнүүд орон дээрээ хэвтдэг эмнэлгийн тасаг/өрөө.", exampleMn: "А тасагт дөрвөн ор бий — нэг нь одоо ч дулаахан." },
  { word: "patient", pos: "noun", def: "A sick person who is being treated in a hospital.", example: "The last patient left in 1999. Something stayed.", defMn: "Эмнэлэгт эмчлүүлж буй өвчтэй хүн.", exampleMn: "Сүүлчийн өвчтөн 1999 онд явсан. Харин ямар нэгэн зүйл үлдсэн." },
  { word: "chart", pos: "noun", def: "A written record of a patient's illness and treatment.", example: "Anna's chart ends in the middle of a sentence.", defMn: "Өвчтөний өвчин, эмчилгээний бичмэл тэмдэглэл (өвчний түүх).", exampleMn: "Аннагийн өвчний түүх өгүүлбэрийн дунд тасардаг." },
  { word: "admitted", pos: "verb", def: "Accepted into a hospital for treatment.", example: "She was admitted on March 3rd and never discharged.", defMn: "Эмнэлэгт эмчлүүлэхээр хүлээн авагдсан.", exampleMn: "Тэр 3-р сарын 3-нд хэвтсэн бөгөөд хэзээ ч гарч байгаагүй." },
  { word: "shift", pos: "noun", def: "A period of work, for example from midnight to 6 AM.", example: "Nobody else wanted the night shift. Now I understand why.", defMn: "Ажлын ээлж, жишээ нь шөнө дундаас өглөөний 6 хүртэл.", exampleMn: "Шөнийн ээлжинд хэн ч гарахыг хүсээгүй. Одоо би яагаад гэдгийг ойлгож байна." },
  { word: "surveillance", pos: "noun", def: "Watching a place with cameras to keep it safe.", example: "The surveillance cameras still work. Watch camera three.", defMn: "Аюулгүй байдлын төлөө камераар хянах үйл ажиллагаа.", exampleMn: "Хяналтын камерууд одоо ч ажиллаж байна. Гуравдугаар камерыг хар." },
  { word: "corridor", pos: "noun", def: "A long passage in a building with rooms on each side.", example: "I heard footsteps in the corridor, but it was empty.", defMn: "Хоёр талд нь өрөө бүхий барилгын урт хонгил.", exampleMn: "Хонгилд хөлийн чимээ сонсогдсон ч тэнд хэн ч байгаагүй." },
  { word: "pharmacy", pos: "noun", def: "The room where medicines are kept and prepared.", example: "The pharmacy door needs a four-digit code.", defMn: "Эм хадгалж, бэлтгэдэг өрөө (эмийн сан).", exampleMn: "Эмийн сангийн хаалга дөрвөн оронтой код шаарддаг." },
  { word: "sedative", pos: "noun", def: "A drug that makes a person calm or sleepy.", example: "They gave Anna a sedative, but she refused to sleep.", defMn: "Хүнийг тайвшруулж, нойрмог болгодог эм.", exampleMn: "Тэд Анна-д тайвшруулах эм өгсөн ч тэр унтахаас татгалзсан." },
  { word: "dose", pos: "noun", def: "The amount of medicine you take at one time.", example: "Someone doubled every dose on the last night.", defMn: "Нэг удаа уух эмийн хэмжээ (тунг).", exampleMn: "Сүүлчийн шөнө хэн нэгэн бүх тунг хоёр дахин нэмэгдүүлсэн." },
  { word: "morgue", pos: "noun", def: "A cold room where dead bodies are kept.", example: "The morgue door was locked from the inside.", defMn: "Нас барагчдын цогцсыг хадгалдаг хүйтэн өрөө (морг).", exampleMn: "Моргийн хаалга дотроосоо түгжигдсэн байсан." },
  { word: "autopsy", pos: "noun", def: "A medical examination of a dead body to learn why the person died.", example: "The autopsy report was never finished.", defMn: "Үхлийн шалтгааныг тогтоох цогцсын шинжилгээ.", exampleMn: "Шинжилгээний дүгнэлт хэзээ ч дуусаагүй." },
  { word: "quarantine", pos: "noun", def: "Keeping sick people alone so a disease cannot spread.", example: "The director ordered a quarantine that nobody understood.", defMn: "Өвчин тараахгүйн тулд өвчтэй хүмүүсийг тусгаарлах (хорио цээр).", exampleMn: "Захирал хэний ч ойлгоогүй хорио цээр зарласан." },
  { word: "vanish", pos: "verb", def: "To disappear suddenly and completely.", example: "The tall nurse vanished when the lights came back.", defMn: "Гэнэт, бүрмөсөн алга болох.", exampleMn: "Гэрэл асахад өндөр сувилагч алга болсон." },
  { word: "witness", pos: "noun", def: "A person who saw something happen.", example: "Every witness told a different story.", defMn: "Ямар нэгэн зүйлийг нүдээр харсан хүн (гэрч).", exampleMn: "Гэрч бүр өөр өөр түүх ярьсан." },
  { word: "evidence", pos: "noun", def: "Facts or objects that show what really happened.", example: "If I carry the evidence out, the truth survives.", defMn: "Юу болсныг харуулдаг баримт, зүйл (нотлох баримт).", exampleMn: "Хэрэв би нотлох баримтыг авч гарвал үнэн амьд үлдэнэ." },
  { word: "fuse", pos: "noun", def: "A small part that stops electricity when there is a problem.", example: "No fuse, no cameras. Simple as that.", defMn: "Асуудал гарахад цахилгааныг тасалдаг жижиг эд анги (гал хамгаалагч).", exampleMn: "Гал хамгаалагчгүй бол камергүй. Ийм л энгийн." },
  { word: "breaker", pos: "noun", def: "A switch that controls the main electricity of a building.", example: "The main breaker waits in the darkest room of all.", defMn: "Барилгын гол цахилгааныг удирддаг унтраалга.", exampleMn: "Гол унтраалга хамгийн харанхуй өрөөнд хүлээж байна." },
  { word: "locker", pos: "noun", def: "A tall metal cupboard where people keep clothes.", example: "Hide in a locker. Hold your breath. Wait.", defMn: "Хүмүүсийн хувцас хийдэг өндөр металл шүүгээ.", exampleMn: "Шүүгээнд нуугд. Амьсгалаа түгж. Хүлээ." },
  { word: "whisper", pos: "verb", def: "To speak very quietly, close to someone's ear.", example: "A child whispered my name from the records room.", defMn: "Хэн нэгний чихэнд маш чимээгүй ярих (шивнэх).", exampleMn: "Архивын өрөөнөөс хүүхэд миний нэрийг шивнэсэн." },
  { word: "prescription", pos: "noun", def: "A doctor's written order for medicine.", example: "The prescription was signed by a doctor who never existed.", defMn: "Эмчийн бичсэн эмийн жор.", exampleMn: "Жорыг хэзээ ч байгаагүй эмч гарын үсэг зурсан байсан." },
  { word: "discharged", pos: "verb", def: "Allowed to leave the hospital.", example: "The chart says 'discharged'. The handwriting says 'taken'.", defMn: "Эмнэлгээс гарахыг зөвшөөрөгдсөн.", exampleMn: "Түүхэн дээр 'гарсан' гэсэн байна. Харин гар бичмэл нь 'авагдсан' гэнэ." },
  { word: "incident", pos: "noun", def: "An event, often something bad or unusual.", example: "After the incident, they closed the hospital forever.", defMn: "Тохиолдсон явдал, ихэвчлэн муу эсвэл хачин зүйл.", exampleMn: "Тэр явдлын дараа эмнэлгийг үүрд хаасан." },
  { word: "restricted", pos: "adjective", def: "Not allowed for most people; limited entry.", example: "Restricted area. Staff only. God forgive us.", defMn: "Ихэнх хүнд хориотой; нэвтрэх эрх хязгаарлагдмал.", exampleMn: "Хориотой бүс. Зөвхөн ажилтнууд. Бурхан биднийг өршөөг." },
];

export const vocabByWord = (w: string) => VOCAB.find((v) => v.word === w.toLowerCase());

// ----------------------------------------------------------------- missions
export interface Mission {
  title: string; objective: string; hint: string;
  titleMn: string; objectiveMn: string; hintMn: string;
}

export const MISSIONS: Mission[] = [
  {
    title: "1 · CLOCK IN",
    objective: "Find the SECURITY ROOM (south-east). Sign in at the terminal.",
    hint: "Follow the mid corridor east, then south. Watch the signs above the doors.",
    titleMn: "1 · ЭЭЛЖИНД ГАР",
    objectiveMn: "АЮУЛГҮЙ БАЙДЛЫН ӨРӨӨГ (зүүн өмнөд) ол. Терминал дээр бүртгүүл.",
    hintMn: "Дунд хонгилоор зүүн тийш, дараа нь урагш яв. Хаалган дээрх тэмдэглэгээг хар.",
  },
  {
    title: "2 · DEAD AIR",
    objective: "Cameras are offline. Find a FUSE in STORAGE and install it in the Security Room fuse box.",
    hint: "Storage is in the north-west. The fuse sits on a shelf. The fuse box is on the Security Room wall.",
    titleMn: "2 · ҮХСЭН ДОХИО",
    objectiveMn: "Камерууд ажиллахгүй байна. АГУУЛАХААС ГАЛ ХАМГААЛАГЧ олж, Аюулгүй байдлын өрөөний хайрцагт суулга.",
    hintMn: "Агуулах баруун хойд талд. Гал хамгаалагч тавиур дээр байгаа. Хайрцаг нь Аюулгүй байдлын өрөөний хананд.",
  },
  {
    title: "3 · CAMERA THREE",
    objective: "Use the surveillance monitor in the Security Room. Check every camera.",
    hint: "Press E at the monitor desk. Switch cameras with A/D or the on-screen arrows.",
    titleMn: "3 · ГУРАВДУГААР КАМЕР",
    objectiveMn: "Аюулгүй байдлын өрөөний хяналтын мониторыг ашигла. Бүх камерыг шалга.",
    hintMn: "Мониторын ширээн дээр E дар. Камерыг A/D эсвэл дэлгэцэн дээрх сумаар соль.",
  },
  {
    title: "4 · ANNA",
    objective: "Enter WARD A with your keycard. Find Anna's chart. Read it carefully — it hides the Pharmacy code.",
    hint: "Anna's bed is in Ward A, west side. Her 'safe number', the month, the day, her age.",
    titleMn: "4 · АННА",
    objectiveMn: "Түлхүүр картаараа А ТАСАГТ ор. Аннагийн өвчний түүхийг ол. Анхааралтай унш — эмийн сангийн код тэнд нуугдаж байгаа.",
    hintMn: "Аннагийн ор А тасгийн баруун талд. Түүний 'аюулгүй тоо', сар, өдөр, нас.",
  },
  {
    title: "5 · BITTER MEDICINE",
    objective: "Open the PHARMACY with the code. Take supplies — and the radio battery.",
    hint: "The pharmacy is on the north corridor. Type the code on the keypad. Grab glass vials: throw them with Q to distract her.",
    titleMn: "5 · ГАШУУН ЭМ",
    objectiveMn: "ЭМИЙН САНГ кодоор онгойлго. Хангамж ав — мөн радионы батерейг.",
    hintMn: "Эмийн сан хойд хонгилд. Кодыг товчлуур дээр оруул. Шилэн савнуудыг ав: Q дарж шидэн түүнийг сатааруул.",
  },
  {
    title: "6 · FREQUENCY 66.6",
    objective: "Take the radio battery to RADIOLOGY. Switch on the radio. Listen carefully.",
    hint: "Radiology is in the north-east. The voice talks about two years. Only one of them opens the Office.",
    titleMn: "6 · 66.6 ДАВТАМЖ",
    objectiveMn: "Радионы батерейг РЕНТГЕН өрөөнд авч оч. Радиог асаа. Анхааралтай сонс.",
    hintMn: "Рентген өрөө зүүн хойд талд. Дуу хоолой хоёр оны тухай ярина. Тэдгээрийн зөвхөн нэг нь Захирлын өрөөг онгойлгоно.",
  },
  {
    title: "7 · THE DIRECTOR'S OFFICE",
    objective: "Open the OFFICE with the year code. Read the folder. Take the keys. Decide what the truth is worth.",
    hint: "The office is off the mid corridor, east side. The desk drawer holds the Morgue Key and the Exit Key.",
    titleMn: "7 · ЗАХИРЛЫН ӨРӨӨ",
    objectiveMn: "ЗАХИРЛЫН ӨРӨӨГ оны кодоор онгойлго. Хавтасыг унш. Түлхүүрүүдийг ав. Үнэн юу үнэтэйг шийд.",
    hintMn: "Өрөө нь дунд хонгилын зүүн талд. Ширээний шургуулганд Моргийн түлхүүр болон Гарах хаалганы түлхүүр бий.",
  },
  {
    title: "8 · DON'T LOOK AWAY",
    objective: "The power is dying. Reach the MORGUE breaker. Remember: she cannot move while you are watching her.",
    hint: "The morgue opens from the central spine. Walk backwards. Look at her. Do NOT turn your back for long.",
    titleMn: "8 · НҮДЭЭ БҮҮ САЛГА",
    objectiveMn: "Цахилгаан тасарч байна. МОРГЫН гол унтраалгад хүр. Сана: чи түүнийг харж байх үед тэр хөдөлж чадахгүй.",
    hintMn: "Морг төвийн хонгилоос онгойдог. Ухарч яв. Түүнийг хар. Нуруугаа удаан бүү харуул.",
  },
  {
    title: "9 · 6:00 AM",
    objective: "Survive. Leave through the LOBBY exit — or finish what Anna started.",
    hint: "The exit is in the south lobby. With the Exit Key you can leave early. At 6:00 AM it unlocks by itself.",
    titleMn: "9 · ӨГЛӨӨНИЙ 6 ЦАГ",
    objectiveMn: "Амьд үлд. ЛОББИГИЙН гарцаар гар — эсвэл Аннагийн эхлүүлснийг дуусга.",
    hintMn: "Гарц урд лоббид бий. Гарах хаалганы түлхүүрээр эрт гарч болно. Өглөөний 6 цагт өөрөө онгойдог.",
  },
];

export const missionText = (m: Mission, lang: Lang) =>
  lang === "mn"
    ? { title: m.titleMn, objective: m.objectiveMn, hint: m.hintMn }
    : { title: m.title, objective: m.objective, hint: m.hint };

// ---------------------------------------------------------------- documents
export interface GameDoc {
  id: string;
  title: string;
  titleMn: string;
  evidence?: boolean;
  text: Partial<Record<Diff, string>> & { intermediate: string };
  textMn: string;
}

export const DOCS: GameDoc[] = [
  {
    id: "shiftlog",
    title: "SHIFT LOG — NIGHT SECURITY",
    titleMn: "ЭЭЛЖИЙН БҮРТГЭЛ — ШӨНИЙН ХАРУУЛ",
    text: {
      intermediate: `Welcome to St. Mercy Hospital. You are the only guard on this [[shift]]: 12:00 AM to 6:00 AM.

RULES — READ TWICE:
1. Keep your flashlight alive. Batteries are life.
2. The [[surveillance]] cameras see more than you do.
3. If you see a tall nurse: DO NOT RUN. She cannot move while you are watching her.
4. Running is loud. Loud is dead.
5. A [[locker]] can hide you — unless she watches you climb in.

The last guard wrote one extra line: "She counts the beds. Four is safe."

Sign here. — Management`,
    },
    textMn: `Гэгээн Нинж (St. Mercy) эмнэлэгт тавтай морил. Чи энэ [[shift]] (ээлж)-ийн цорын ганц харуул: шөнө дундаас өглөөний 6 хүртэл.

ДҮРМҮҮД — ХОЁР УДАА УНШ:
1. Гар чийдэнгээ амьд байлга. Батерей бол амьдрал.
2. [[surveillance]] (хяналтын) камер чинийхээс илүүг хардаг.
3. Өндөр сувилагч харвал: ГҮЙЖ БОЛОХГҮЙ. Чи түүнийг харж байх үед тэр хөдөлж чадахгүй.
4. Гүйх нь чимээтэй. Чимээтэй бол үхсэн гэсэн үг.
5. [[locker]] (шүүгээ) чамайг нууж чадна — тэр чамайг орж байхыг хараагүй л бол.

Сүүлчийн харуул нэг мөр нэмж бичжээ: "Тэр орнуудыг тоолдог. Дөрөв бол аюулгүй."

Энд гарын үсэг зур. — Удирдлага`,
  },
  {
    id: "plaque",
    title: "LOBBY PLAQUE",
    titleMn: "ЛОББИНЫ САМБАР",
    text: {
      intermediate: `ST. MERCY HOSPITAL

"Mercy for the sick. Silence for the dead."

Opened: 1974
Closed: 1999 — after the [[incident]].

Below, somebody scratched a sentence into the brass:
"Mercy was a [[patient]] here. She never left."`,
    },
    textMn: `ГЭГЭЭН НИНЖ ЭМНЭЛЭГ

"Өвчтэйд нинж. Нас барагчдад чимээгүй байдал."

Нээгдсэн: 1974
Хаагдсан: 1999 — тэр [[incident]] (явдал)-ын дараа.

Доор нь хэн нэгэн хүрэл самбарт өгүүлбэр сийлжээ:
"Mercy энд [[patient]] (өвчтөн) байсан. Тэр хэзээ ч яваагүй."`,
  },
  {
    id: "anna",
    title: "PATIENT CHART — ANNA REYES",
    titleMn: "ӨВЧНИЙ ТҮҮХ — АННА РЕЙЕС",
    evidence: true,
    text: {
      beginner: `PATIENT CHART

Name: Anna Reyes
Age: 9 years old
Room: [[Ward]] A

Anna came to the hospital on March 3. She does not sleep. She says a tall nurse visits her at night. But no tall nurse works here.

Anna counts the beds to feel calm: "One, two, three, four. Four beds. Four is safe."

Doctor's note for the night staff:
"The [[pharmacy]] code is Anna's safe number, then the month she came, then the day she came, then her age. She told everyone. Nobody listened."`,
      intermediate: `PATIENT CHART

Patient: Anna Reyes, 9 years old
[[Admitted]]: March 3, 1999 — [[Ward]] A

Anna refuses to sleep. She insists a tall nurse stands beside her bed after lights-out — yet no such nurse appears on any staff list. A mild [[sedative]] was prescribed. It changed nothing.

To calm herself, Anna counts the beds in the ward, over and over: "Four beds. Four is safe."

Note for night staff, in the doctor's handwriting:
"The [[pharmacy]] code is her safe number, the month she was admitted, the day, and her age. She repeats it like a prayer."`,
      advanced: `ADMISSION & PROGRESS CHART

Pt: REYES, A. — female, 9 y/o. [[Admitted]] 03/03/1999, [[Ward]] A.
Presenting complaint: persistent insomnia; hypnagogic figure ("tall nurse") observed nightly at bedside. No corresponding staff member exists on roster. [[Sedative]] administered ×3 — no therapeutic effect. Pt. remains adamant the figure "counts her breathing".

Behavioural note: pt. self-soothes by enumerating the ward's beds ("four — four is safe"), a ritual she insists protects her.

Attending's margin note, night staff only:
"[[Pharmacy]] combination remains: her safe number, month of admission, day, age. She told three nurses. All three requested transfer."`,
    },
    textMn: `ӨВЧНИЙ ТҮҮХ

Өвчтөн: Анна Рейес, 9 настай
Хэвтсэн ([[admitted]]): 1999 оны 3-р сарын 3 — [[ward]] А тасаг

Анна унтахаас татгалздаг. Гэрэл унтарсны дараа өндөр сувилагч орных нь дэргэд зогсдог гэж зүтгэдэг — гэвч ажилтнуудын жагсаалтад тийм сувилагч байхгүй. Хөнгөн [[sedative]] (тайвшруулах эм) бичсэн. Юу ч өөрчлөгдөөгүй.

Тайвшрахын тулд Анна тасгийн орнуудыг дахин дахин тоолдог: "Дөрвөн ор. Дөрөв бол аюулгүй."

Эмчийн гараар шөнийн ажилтнуудад бичсэн тэмдэглэл:
"[[pharmacy]] (эмийн сан)-гийн код нь түүний аюулгүй тоо, хэвтсэн сар, өдөр, тэгээд нас. Тэр үүнийг залбирал мэт давтдаг."`,
  },
  {
    id: "incidentlog",
    title: "PHARMACY INCIDENT LOG",
    titleMn: "ЭМИЙН САНГИЙН ЯВДЛЫН БҮРТГЭЛ",
    evidence: true,
    text: {
      intermediate: `INCIDENT LOG — PHARMACY — LAST ENTRY

October 30, 1999, 2:14 AM.
Every [[dose]] on Ward A was doubled tonight. The [[prescription]] forms are signed "M. Mercy" — head nurse, 1974. She has been dead for twenty years.

I reported it. The director smiled and said one word: "[[Quarantine]]." Then he locked the ward from the outside — with the patients still inside.

If you are reading this, count the beds before you count the bodies.

— J. Okafor, pharmacist`,
    },
    textMn: `ЯВДЛЫН БҮРТГЭЛ — ЭМИЙН САН — СҮҮЛЧИЙН БИЧЛЭГ

1999 оны 10-р сарын 30, шөнийн 2:14.
Өнөө шөнө А тасгийн бүх [[dose]] (тунг)-ийг хоёр дахин нэмэгдүүлжээ. [[prescription]] (жор)-уудад "M. Mercy" гэж гарын үсэг зурсан байна — 1974 оны ахлах сувилагч. Тэр хориод жилийн өмнө нас барсан.

Би үүнийг мэдэгдсэн. Захирал инээмсэглээд нэг үг хэлсэн: "[[Quarantine]] (Хорио цээр)." Тэгээд тэр тасгийг гаднаас нь түгжсэн — өвчтөнүүд дотор нь байхад шүү.

Хэрэв чи үүнийг уншиж байгаа бол цогцсыг тоолохоосоо өмнө орнуудыг тоол.

— Ж. Окафор, эм зүйч`,
  },
  {
    id: "xray",
    title: "RADIOLOGY REPORT — UNSENT",
    titleMn: "РЕНТГЕНИЙ ДҮГНЭЛТ — ИЛГЭЭГДЭЭГҮЙ",
    evidence: true,
    text: {
      intermediate: `RADIOLOGY — REPORT #441 — NEVER FILED

We X-rayed the tall nurse's uniform when they found it standing in the [[corridor]]. Standing. Empty. Straight as a soldier.

The film shows a skeleton inside the cloth. Standing. Watching the camera.

There was no body. There was never a body. The [[autopsy]] in 1974 had no body either — only a uniform, folded on the table, still warm.

Destroy this report. I couldn't. Forgive me.

— Dr. E. Vance, the only honest [[witness]]`,
    },
    textMn: `РЕНТГЕН — ДҮГНЭЛТ №441 — ХЭЗЭЭ Ч БҮРТГЭГДЭЭГҮЙ

Өндөр сувилагчийн дүрэмт хувцсыг [[corridor]] (хонгил)-д зогсож байхыг нь олсон үед бид рентгенээр харсан. Зогсож байсан. Хоосон. Цэрэг мэт цэх.

Зураг дээр хувцасны дотор араг яс харагдаж байна. Зогсоод. Камер руу хараад.

Цогцос байгаагүй. Хэзээ ч байгаагүй. 1974 оны [[autopsy]] (шинжилгээ)-д ч цогцос байгаагүй — зөвхөн ширээн дээр эвхсэн, одоо ч дулаахан дүрэмт хувцас л байсан.

Энэ дүгнэлтийг устга. Би чадаагүй. Намайг уучлаарай.

— Др. Э. Ванс, цорын ганц үнэнч [[witness]] (гэрч)`,
  },
  {
    id: "recordsfile",
    title: "STAFF FILE — M. MERCY",
    titleMn: "АЖИЛТНЫ ХУВИЙН ХЭРЭГ — М. MERCY",
    text: {
      intermediate: `STAFF RECORDS — RESTRICTED

MERCY, Marigold — Head Nurse. Height: 6 ft 7 in. Employed 1974.
Died: 1974. Cause: "the sickness" ([[quarantine]] ward).
Last words recorded by a [[witness]]: "Count the beds. If the number is wrong, do not sleep."

Every year since, one [[chart]] is signed in her handwriting.
Every year since, one [[patient]] is marked [[discharged]] — and is never seen again.

The cabinet beside this file is locked with words, not keys. She always loved words.`,
    },
    textMn: `АЖИЛТНЫ БҮРТГЭЛ — [[restricted]] (ХЯЗГААРТАЙ)

MERCY, Мариголд — Ахлах сувилагч. Өндөр: 2 метр. Ажилд орсон: 1974.
Нас барсан: 1974. Шалтгаан: "өвчин" ([[quarantine]] тасаг).
[[witness]] (гэрч)-ийн тэмдэглэсэн сүүлчийн үгс: "Орнуудыг тоол. Тоо нь буруу байвал бүү унт."

Түүнээс хойш жил бүр нэг [[chart]] (өвчний түүх) түүний гар бичмэлээр гарын үсэг зурагддаг.
Жил бүр нэг [[patient]] (өвчтөн) "[[discharged]] (гарсан)" гэж тэмдэглэгддэг — бөгөөд дахин хэзээ ч харагддаггүй.

Энэ хэргийн дэргэдэх шүүгээ түлхүүрээр бус, үгээр түгжигддэг. Тэр үгэнд үргэлж дуртай байсан.`,
  },
  {
    id: "folder",
    title: "DIRECTOR'S FOLDER — PROJECT MERCY",
    titleMn: "ЗАХИРЛЫН ХАВТАС — MERCY ТӨСӨЛ",
    evidence: true,
    text: {
      intermediate: `PROJECT MERCY — THE TRUTH

In 1974 the hospital treated "the sickness" in secret. Head Nurse Mercy refused an untested drug for her patients. So they tested it on her.

She died screaming numbers. Four. Three. Three. Nine — the ages and beds of her ward.

In 1999 the drug's owners needed the last living witness gone: a girl on Ward A who had seen Mercy standing by her bed. They ordered every [[dose]] doubled. They called it an [[incident]]. They closed St. Mercy and buried this folder.

This is the [[evidence]]. Outside these walls, it is worth a fortune — or a funeral.

— kept by a coward who finally ran out of silence`,
    },
    textMn: `MERCY ТӨСӨЛ — ҮНЭН

1974 онд эмнэлэг "өвчин"-ийг нууцаар эмчилж байв. Ахлах сувилагч Mercy туршигдаагүй эмийг өвчтөнүүддээ өгөхөөс татгалзсан. Тиймээс тэд түүн дээр туршсан.

Тэр тоо хашхирсаар нас барсан. Дөрөв. Гурав. Гурав. Ес — түүний тасгийн нас, орнууд.

1999 онд эмийн эзэд сүүлчийн амьд гэрчийг үгүй хийх хэрэгтэй болсон: А тасгийн, Mercy-г орныхоо дэргэд харсан охин. Тэд бүх [[dose]] (тунг)-ийг хоёр дахин нэмэхийг тушаасан. Үүнийг [[incident]] (явдал) гэж нэрлэсэн. St. Mercy-г хааж, энэ хавтасыг булсан.

Энэ бол [[evidence]] (нотлох баримт). Энэ хананы гадна энэ нь асар их мөнгө — эсвэл оршуулга үнэтэй.

— эцэст нь чимээгүй байдлаас залхсан аймхай хүний хадгалсан тэмдэглэл`,
  },
  {
    id: "toetag",
    title: "MORGUE TOE TAG — BODY 9",
    titleMn: "МОРГЫН ШОШГО — 9-Р ЦОГЦОС",
    evidence: true,
    text: {
      intermediate: `MORGUE — TOE TAG

Name: REYES, Anna
Age: 9
[[Admitted]]: March 3, 1999
[[Discharged]]: —

Under "cause of death", in tall, elegant handwriting:
"She counted to four. Four was NOT safe. I only wanted her to sleep. Now she counts with me — forever."

The drawer is cold. The tag is warm.`,
    },
    textMn: `МОРГ — ХӨЛИЙН ШОШГО

Нэр: РЕЙЕС, Анна
Нас: 9
Хэвтсэн ([[admitted]]): 1999.03.03
Гарсан ([[discharged]]): —

"Үхлийн шалтгаан" гэсэн дор өндөр, дэгжин гар бичмэлээр:
"Тэр дөрөв хүртэл тоолсон. Дөрөв АЮУЛГҮЙ байгаагүй. Би зөвхөн түүнийг унтуулахыг хүссэн. Одоо тэр надтай хамт тоолдог — үүрд."

Шургуулга хүйтэн. Шошго дулаахан.`,
  },
  {
    id: "tape0",
    title: "TAPE 0 — TRANSCRIPT",
    titleMn: "0-Р Соронзон Хальс — БИЧВЭР",
    text: {
      intermediate: `TAPE 0 — RECORDED IN WARD A, 1999 — TRANSCRIPT

[sound of a [[ward]] at night; a small girl counting]
ANNA: One… two… three… four. Four is safe. Four is safe.
[a woman's voice, far away and much too tall]
MERCY: Child, counting will not save you. WORDS will. Learn the words. Say what things ARE, and they cannot pretend.
ANNA: Are you a nurse?
MERCY: Say it correctly, little one. I WAS a nurse.
[tape ends; the counting continues for nine more seconds]

Pinned note: "She fears being NAMED. In the [[morgue]], say who she was — out loud — and the night shift ends forever."`,
    },
    textMn: `0-Р ХАЛЬС — А ТАСАГТ БИЧИГДСЭН, 1999 — БИЧВЭР

[шөнийн [[ward]] (тасаг)-ийн чимээ; жижиг охин тоолж байна]
АННА: Нэг… хоёр… гурав… дөрөв. Дөрөв бол аюулгүй. Дөрөв бол аюулгүй.
[эмэгтэй хүний дуу — алсаас, хэтэрхий өндрөөс]
MERCY: Хүүхэд минь, тоолох нь чамайг аврахгүй. ҮГС аварна. Үгсийг сур. Юмс ЮУ болохыг нь хэл — тэгвэл тэд дүр эсгэж чадахгүй.
АННА: Та сувилагч уу?
MERCY: Зөв хэл, жаахан минь. Би сувилагч БАЙСАН.
[хальс дуусна; тоолох чимээ есөн секунд үргэлжилнэ]

Хавсаргасан тэмдэглэл: "Тэр НЭРЛЭГДЭХЭЭС айдаг. [[morgue]] (морг)-т тэр хэн байсныг — чангаар — хэлбэл шөнийн ээлж үүрд дуусна."`,
  },
];

export const docById = (id: string) => DOCS.find((d) => d.id === id)!;

// ------------------------------------------------------------------ puzzles
export const ANNA_QUESTION: Record<Diff, { q: string; options: string[]; answer: number; hint: string }> = {
  beginner: {
    q: "What is the pharmacy code?",
    options: ["4339", "9343", "3439", "1999"],
    answer: 0,
    hint: "'Safe number' = the beds she counts (4). Month she came: March = 3. Day = 3. Age = 9.",
  },
  intermediate: {
    q: "Using the doctor's note, what is the four-digit pharmacy code?",
    options: ["4339", "9343", "4439", "3339"],
    answer: 0,
    hint: "Order: safe number (beds) → month admitted → day → her age.",
  },
  advanced: {
    q: "Decode the attending's margin note. What is the pharmacy combination?",
    options: ["4339", "3039", "93304", "4933"],
    answer: 0,
    hint: "'Enumerating the ward's beds' gives the first digit. Then month (03 → 3), day, age.",
  },
};

export const ANNA_QUESTION_MN = {
  q: "Эмчийн тэмдэглэлийн дагуу эмийн сангийн дөрвөн оронтой код юу вэ?",
  options: ["4339", "9343", "4439", "3339"],
  answer: 0,
  hint: "Дараалла: аюулгүй тоо (орны тоо) → хэвтсэн сар → өдөр → нас.",
};

export const RADIO_PUZZLE = {
  spoken:
    "Security, security... if anyone still breathes in there, listen. The director locked his office with a year. Not the year we opened, keeper. The year we closed. The year Mercy won.",
  question: "What did the voice say about the office code?",
  options: [
    "Use the year the hospital CLOSED",
    "Use the year the hospital OPENED",
    "Use the director's room number",
    "Use Anna's safe number four times",
  ],
  answer: 0,
  hint: "Listen for 'not... opened'. The lobby plaque shows both years: opened 1974, closed — the other one.",
};

export const RADIO_PUZZLE_MN = {
  question: "Дуу хоолой захирлын өрөөний кодын талаар юу гэж хэлсэн бэ? (Англиар сонс!)",
  options: [
    "Эмнэлэг ХААГДСАН оныг ашигла",
    "Эмнэлэг НЭЭГДСЭН оныг ашигла",
    "Захирлын өрөөний дугаарыг ашигла",
    "Аннагийн аюулгүй тоог дөрвөн удаа",
  ],
  answer: 0,
  hint: "'Not the year we opened' гэхийг сонс. Лоббины самбарт хоёр он бий: нээгдсэн 1974, хаагдсан — нөгөө нь.",
};

export const VOCAB_MATCH_WORDS = ["sedative", "quarantine", "autopsy", "vanish"];

// -------------------------------------------------------------------- radio
export const HOUR_LINES: string[] = [
  "12:00 AM — \"Night shift logged. Remember: the corridor is long, but she is longer.\"",
  "1:00 AM — \"Ward A report: four beds. All empty. All... occupied.\"",
  "2:00 AM — \"Pharmacy reminder: a sedative calms the living. It does nothing for her.\"",
  "3:00 AM — \"This is the quiet hour. Even the morgue holds its breath at 3 AM.\"",
  "4:00 AM — \"Witness statement number nine: 'She only walks when nobody is watching.'\"",
  "5:00 AM — \"Final hour approaching. Count the beds, keeper. Count them and live.\"",
];

export const HOUR_LINES_MN: string[] = [
  "12:00 — \"Шөнийн ээлж бүртгэгдлээ. Сана: хонгил урт, харин тэр түүнээс урт.\"",
  "1:00 — \"А тасгийн мэдээ: дөрвөн ор. Бүгд хоосон. Бүгд... эзэнтэй.\"",
  "2:00 — \"Эмийн сангийн сануулга: тайвшруулах эм амьд хүнийг тайвшруулдаг. Түүнд үйлчлэхгүй.\"",
  "3:00 — \"Энэ бол чимээгүй цаг. 3 цагт морг хүртэл амьсгалаа түгждэг.\"",
  "4:00 — \"Ес дэх гэрчийн мэдүүлэг: 'Тэр зөвхөн хэн ч харахгүй үед л явдаг.'\"",
  "5:00 — \"Сүүлчийн цаг дөхөж байна. Орнуудыг тоол, харуул аа. Тоолоод амьд үлд.\"",
];

// ------------------------------------------------------------------ endings
export type EndingId = "escape" | "truth" | "bad" | "secret";

export const ENDINGS: Record<EndingId, { title: string; sub: string; text: string; titleMn: string; subMn: string; textMn: string }> = {
  escape: {
    title: "ENDING — ESCAPE",
    sub: "You survived the night shift.",
    text: "You run into the gray morning and do not look back. Behind you, behind glass, a tall shape counts the windows one by one. You are alive. But St. Mercy keeps its secrets — and somewhere inside, a little girl is still counting to four.",
    titleMn: "ТӨГСГӨЛ — ЗУГТСАН",
    subMn: "Чи шөнийн ээлжээс амьд гарлаа.",
    textMn: "Чи саарал өглөө рүү эргэж харалгүй гүйнэ. Ар талд чинь, шилний цаана өндөр дүрс цонхнуудыг нэг нэгээр нь тоолж байна. Чи амьд. Гэвч St. Mercy нууцаа хадгалсаар — дотор нь хаа нэгтээ жижиг охин одоо ч дөрөв хүртэл тоолж байна.",
  },
  truth: {
    title: "ENDING — TRUTH REVEALED",
    sub: "The evidence made it out with you.",
    text: "The folder. The log. The report. The tag. By noon, the story of St. Mercy is on every front page: Project Mercy, the doubled doses, the locked ward. That night, for the first time in twenty-five years, no chart is signed in tall, elegant handwriting. Anna sleeps. So does she.",
    titleMn: "ТӨГСГӨЛ — ҮНЭН ИЛ БОЛЛОО",
    subMn: "Нотлох баримт чамтай хамт гарсан.",
    textMn: "Хавтас. Бүртгэл. Дүгнэлт. Шошго. Үд гэхэд St. Mercy-гийн түүх бүх сонины нүүрэнд: Mercy төсөл, хоёр дахин тун, түгжигдсэн тасаг. Тэр шөнө хорин таван жилд анх удаа ямар ч өвчний түүх өндөр, дэгжин гар бичмэлээр зурагдаагүй. Анна унтдаг. Тэр ч бас.",
  },
  bad: {
    title: "ENDING — ADMITTED",
    sub: "You belong to St. Mercy now.",
    text: "The corridor folds in. The lights sigh and die. Gentle, enormous hands tuck you into a fifth bed that was never there before. 'Count with us,' whispers a little girl. On the door of Ward A, the number changes. Five beds. Five is safe. Five is forever.",
    titleMn: "ТӨГСГӨЛ — ХЭВТҮҮЛСЭН",
    subMn: "Чи одоо St. Mercy-гийнх.",
    textMn: "Хонгил эвхэгдэнэ. Гэрлүүд санаа алдаад унтарна. Зөөлөн, аварга гар чиний өмнө хэзээ ч байгаагүй тав дахь орон дээр хэвтүүлнэ. 'Бидэнтэй хамт тоол,' гэж жижиг охин шивнэнэ. А тасгийн хаалган дээрх тоо өөрчлөгдөнө. Таван ор. Тав бол аюулгүй. Тав бол үүрд.",
  },
  secret: {
    title: "SECRET ENDING — DISCHARGED",
    sub: "You said her name. You said who she WAS.",
    text: "'You were Marigold Mercy, head nurse. You refused the drug. You protected them.' The tall figure stops. Something in her face — almost a face again — breaks like ice in spring. 'Correct,' she says, with a nurse's tired smile. 'Past tense. At last.' By dawn, every drawer in the morgue stands open and empty, and Ward A smells of rain. Her shift is over. So is yours.",
    titleMn: "НУУЦ ТӨГСГӨЛ — ЭМНЭЛГЭЭС ГАРСАН",
    subMn: "Чи түүний нэрийг хэлсэн. Тэр хэн БАЙСНЫГ хэлсэн.",
    textMn: "'Та Мариголд Mercy байсан. Ахлах сувилагч. Та эмээс татгалзсан. Та тэднийг хамгаалсан.' Өндөр дүрс зогсоно. Түүний нүүрэнд ямар нэг зүйл — бараг дахин нүүр болсон зүйл — хаврын мөс мэт хагарна. 'Зөв,' гэж тэр сувилагчийн ядарсан инээмсэглэлээр хэлнэ. 'Өнгөрсөн цаг. Эцэст нь.' Үүр цайх үед моргийн бүх шургуулга нээлттэй, хоосон байх ба А тасагт борооны үнэр үнэртэнэ. Түүний ээлж дууссан. Чинийх ч бас.",
  },
};

export const CONTROLS_LIST: [string, string][] = [
  ["W A S D", "Move"],
  ["Mouse", "Look (click the screen to capture)"],
  ["SHIFT", "Sprint — fast, but LOUD"],
  ["C / CTRL", "Crouch — slow, quiet, harder to see"],
  ["E", "Interact / open / hide / read"],
  ["F", "Flashlight on/off"],
  ["V", "Camera view: 1st person / 3rd person / orbit"],
  ["Q", "Throw a glass vial (distraction)"],
  ["B", "Swap flashlight battery"],
  ["G", "Drink coffee (restore sanity)"],
  ["N", "Notebook: objectives, vocabulary, floor plan"],
  ["P / ESC", "Pause"],
  ["Touch", "Left stick to move, drag right side to look"],
];

export const CONTROLS_LIST_MN: [string, string][] = [
  ["W A S D", "Хөдлөх"],
  ["Хулгана", "Хараа (дэлгэц дээр дарж идэвхжүүл)"],
  ["SHIFT", "Гүйх — хурдан ч ЧАНГА"],
  ["C / CTRL", "Суух — удаан, чимээгүй, харагдахгүй"],
  ["E", "Харилцах / нээх / нуугдах / унших"],
  ["F", "Гар чийдэн асаах/унтраах"],
  ["V", "Камер: 1-р бие / 3-р бие / тойрог"],
  ["Q", "Шилэн сав шидэх (сатааруулах)"],
  ["B", "Чийдэнгийн батерей солих"],
  ["G", "Кофе уух (ухаан санаа сэргээх)"],
  ["N", "Дэвтэр: даалгавар, үгс, давхрын зураг"],
  ["P / ESC", "Түр зогсоох"],
  ["Мэдрэгч", "Зүүн жойстикоор хөдөлж, баруун талаар чирж харна"],
];
