// ---------------------------------------------------------------------------
// St. Mercy Hospital — grid layout. 36 x 26 cells, 2m per cell.
// Floor = union of room/corridor rectangles; everything else is wall.
// ---------------------------------------------------------------------------

export const GW = 36;
export const GH = 26;
export const CELL = 2;
export const WALL_H = 3.2;

export const cellToWorld = (gx: number, gy: number) => ({
  x: (gx - GW / 2 + 0.5) * CELL,
  z: (gy - GH / 2 + 0.5) * CELL,
});

export const worldToCell = (x: number, z: number) => ({
  gx: Math.floor(x / CELL + GW / 2),
  gy: Math.floor(z / CELL + GH / 2),
});

export interface RoomDef {
  id: string;
  name: string;
  x1: number; y1: number; x2: number; y2: number;
}

export const ROOMS: RoomDef[] = [
  { id: "ncorr", name: "North Corridor", x1: 1, y1: 7, x2: 34, y2: 8 },
  { id: "mcorr", name: "Mid Corridor", x1: 1, y1: 15, x2: 34, y2: 16 },
  { id: "spine", name: "Central Spine", x1: 17, y1: 1, x2: 18, y2: 24 },
  { id: "storage", name: "Storage", x1: 1, y1: 1, x2: 10, y2: 5 },
  { id: "records", name: "Records", x1: 12, y1: 1, x2: 15, y2: 5 },
  { id: "pharmacy", name: "Pharmacy", x1: 20, y1: 1, x2: 26, y2: 5 },
  { id: "radiology", name: "Radiology", x1: 28, y1: 1, x2: 34, y2: 5 },
  { id: "ward", name: "Ward A", x1: 1, y1: 10, x2: 10, y2: 13 },
  { id: "morgue", name: "Morgue", x1: 12, y1: 10, x2: 15, y2: 13 },
  { id: "office", name: "Director's Office", x1: 20, y1: 10, x2: 30, y2: 13 },
  { id: "janitor", name: "Janitor Closet", x1: 32, y1: 10, x2: 34, y2: 13 },
  { id: "waiting", name: "Waiting Room", x1: 1, y1: 18, x2: 10, y2: 24 },
  { id: "lobby", name: "Lobby", x1: 12, y1: 18, x2: 24, y2: 24 },
  { id: "security", name: "Security Room", x1: 27, y1: 18, x2: 34, y2: 24 },
];

export function roomAt(gx: number, gy: number): RoomDef | null {
  // prefer real rooms over corridors
  const sorted = [...ROOMS].sort((a, b) => {
    const ac = a.id.includes("corr") || a.id === "spine" ? 1 : 0;
    const bc = b.id.includes("corr") || b.id === "spine" ? 1 : 0;
    return ac - bc;
  });
  return sorted.find((r) => gx >= r.x1 && gx <= r.x2 && gy >= r.y1 && gy <= r.y2) ?? null;
}

// --------------------------------------------------------------------- doors
export type LockType = "none" | "keycard" | "keypadPharmacy" | "keypadOffice" | "morguekey" | "exit";

export interface DoorDef {
  id: string;
  gx: number; gy: number;
  lock: LockType;
  sign: string;
}

export const DOORS: DoorDef[] = [
  { id: "d_storage", gx: 6, gy: 6, lock: "none", sign: "STORAGE" },
  { id: "d_records", gx: 13, gy: 6, lock: "none", sign: "RECORDS" },
  { id: "d_pharmacy", gx: 23, gy: 6, lock: "keypadPharmacy", sign: "PHARMACY" },
  { id: "d_radiology", gx: 31, gy: 6, lock: "none", sign: "RADIOLOGY" },
  { id: "d_ward_n", gx: 5, gy: 9, lock: "keycard", sign: "WARD A" },
  { id: "d_ward_s", gx: 8, gy: 14, lock: "keycard", sign: "WARD A" },
  { id: "d_morgue", gx: 16, gy: 11, lock: "morguekey", sign: "MORGUE" },
  { id: "d_office", gx: 25, gy: 14, lock: "keypadOffice", sign: "DIRECTOR" },
  { id: "d_janitor", gx: 33, gy: 14, lock: "none", sign: "JANITOR" },
  { id: "d_waiting", gx: 5, gy: 17, lock: "none", sign: "WAITING" },
  { id: "d_security", gx: 30, gy: 17, lock: "none", sign: "SECURITY" },
  { id: "d_lobby_a", gx: 17, gy: 17, lock: "none", sign: "LOBBY" },
  { id: "d_lobby_b", gx: 18, gy: 17, lock: "none", sign: "LOBBY" },
  { id: "d_exit", gx: 18, gy: 25, lock: "exit", sign: "EXIT" },
];

// ----------------------------------------------------------------- furniture
export interface FurnDef {
  gx: number; gy: number;
  w: number; d: number; h: number; // world units
  color: number;
  kind: "bed" | "desk" | "shelf" | "table" | "crate" | "machine" | "counter" | "bench" | "gurney";
}

const F = (gx: number, gy: number, w: number, d: number, h: number, color: number, kind: FurnDef["kind"]): FurnDef =>
  ({ gx, gy, w, d, h, color, kind });

export const FURNITURE: FurnDef[] = [
  // Ward A — four beds. Count them.
  F(2, 10, 1.1, 2.0, 0.75, 0x9fb2c1, "bed"),
  F(4, 10, 1.1, 2.0, 0.75, 0x9fb2c1, "bed"),
  F(6, 10, 1.1, 2.0, 0.75, 0x9fb2c1, "bed"),
  F(8, 10, 1.1, 2.0, 0.75, 0x9fb2c1, "bed"),
  F(5, 12, 1.4, 0.8, 0.8, 0x5a6a7d, "table"),
  F(1, 13, 1.6, 0.7, 1.5, 0x46566b, "shelf"),
  // Storage
  F(2, 1, 1.8, 0.8, 2.1, 0x4c5d73, "shelf"),
  F(4, 1, 1.8, 0.8, 2.1, 0x4c5d73, "shelf"),
  F(6, 1, 1.8, 0.8, 2.1, 0x4c5d73, "shelf"),
  F(8, 1, 1.8, 0.8, 2.1, 0x4c5d73, "shelf"),
  F(2, 4, 1.2, 1.2, 1.0, 0x6b5a41, "crate"),
  F(9, 4, 1.2, 1.2, 1.3, 0x6b5a41, "crate"),
  F(5, 3, 1.0, 2.0, 0.85, 0x7d8ea0, "gurney"),
  // Records
  F(13, 1, 1.8, 0.8, 2.1, 0x54503f, "shelf"),
  F(15, 1, 0.8, 0.8, 2.1, 0x54503f, "shelf"),
  F(13, 4, 1.6, 0.9, 0.8, 0x5d4a36, "desk"),
  F(12, 2, 0.9, 1.6, 1.6, 0x3f4a5c, "machine"),
  // Pharmacy
  F(21, 1, 1.8, 0.8, 2.1, 0x6f8a7a, "shelf"),
  F(23, 1, 1.8, 0.8, 2.1, 0x6f8a7a, "shelf"),
  F(25, 1, 1.8, 0.8, 2.1, 0x6f8a7a, "shelf"),
  F(23, 4, 2.2, 0.9, 1.05, 0x8b9cae, "counter"),
  F(20, 3, 0.9, 1.6, 1.7, 0x708090, "machine"),
  // Radiology
  F(31, 3, 1.2, 2.4, 0.9, 0xa8b8c8, "gurney"),
  F(33, 1, 1.6, 1.2, 2.2, 0x93a7bd, "machine"),
  F(29, 4, 1.6, 0.9, 0.8, 0x5d4a36, "desk"),
  F(28, 1, 1.0, 0.8, 1.6, 0x46566b, "shelf"),
  // Morgue
  F(13, 11, 1.1, 2.1, 0.85, 0xb8c8d8, "gurney"),
  F(13, 13, 1.1, 2.1, 0.85, 0xb8c8d8, "gurney"),
  F(15, 10, 0.9, 0.9, 1.9, 0x8fa3b8, "machine"),
  // Office
  F(25, 11, 2.4, 1.1, 0.82, 0x4f3a2a, "desk"),
  F(21, 10, 1.8, 0.7, 2.0, 0x4a3b2c, "shelf"),
  F(29, 12, 1.0, 1.0, 1.3, 0x2e3a4a, "machine"),
  F(25, 13, 1.8, 0.7, 0.6, 0x5c2e2e, "bench"),
  // Janitor
  F(33, 11, 1.6, 0.8, 1.9, 0x59616e, "shelf"),
  F(32, 13, 1.0, 1.0, 0.9, 0x6b5a41, "crate"),
  // Waiting
  F(3, 20, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  F(5, 20, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  F(7, 20, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  F(9, 18, 1.2, 0.9, 1.8, 0x74463a, "machine"),
  F(3, 23, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  // Lobby
  F(17, 21, 3.2, 1.0, 1.1, 0x3d4f66, "counter"),
  F(14, 19, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  F(21, 19, 1.8, 0.6, 0.55, 0x37506b, "bench"),
  F(12, 24, 1.0, 1.0, 1.1, 0x4c6b4f, "crate"),
  // Security
  F(30, 19, 2.6, 1.0, 0.85, 0x33445c, "desk"),
  F(28, 19, 1.4, 0.9, 0.85, 0x33445c, "desk"),
  F(33, 18, 0.9, 0.5, 1.6, 0x6b7280, "machine"),
  F(28, 23, 1.8, 0.8, 1.4, 0x46566b, "shelf"),
  // Corridor gurneys / clutter (placed to keep 1-cell passages open)
  F(11, 7, 1.0, 2.0, 0.85, 0x7d8ea0, "gurney"),
  F(27, 16, 1.0, 2.0, 0.85, 0x7d8ea0, "gurney"),
  F(17, 5, 0.9, 0.9, 0.8, 0x6b5a41, "crate"), // on spine — leaves west cell open? spine is x17..18, this blocks 17, 18 stays open
];

export const LOCKERS: { gx: number; gy: number }[] = [
  { gx: 1, gy: 8 },
  { gx: 34, gy: 7 },
  { gx: 10, gy: 13 },
  { gx: 1, gy: 16 },
  { gx: 34, gy: 15 },
  { gx: 24, gy: 24 },
  { gx: 15, gy: 5 },
  { gx: 27, gy: 21 },
];

// ------------------------------------------------------------------- pickups
export type PickupKind = "battery" | "coffee" | "vial" | "fuse" | "radiobattery" | "wristband";

export interface PickupDef { id: string; kind: PickupKind; gx: number; gy: number }

export const PICKUPS: PickupDef[] = [
  { id: "pk_fuse", kind: "fuse", gx: 6, gy: 2 },
  { id: "pk_radiobat", kind: "radiobattery", gx: 23, gy: 3 },
  { id: "pk_bat1", kind: "battery", gx: 29, gy: 20 },
  { id: "pk_bat2", kind: "battery", gx: 33, gy: 12 },
  { id: "pk_bat3", kind: "battery", gx: 21, gy: 3 },
  { id: "pk_bat4", kind: "battery", gx: 25, gy: 4 },
  { id: "pk_bat5", kind: "battery", gx: 3, gy: 3 },
  { id: "pk_bat6", kind: "battery", gx: 22, gy: 12 },
  { id: "pk_bat7", kind: "battery", gx: 6, gy: 22 },
  { id: "pk_cof1", kind: "coffee", gx: 9, gy: 19 },
  { id: "pk_cof2", kind: "coffee", gx: 31, gy: 23 },
  { id: "pk_cof3", kind: "coffee", gx: 14, gy: 4 },
  { id: "pk_vial1", kind: "vial", gx: 22, gy: 3 },
  { id: "pk_vial2", kind: "vial", gx: 24, gy: 3 },
  { id: "pk_vial3", kind: "vial", gx: 7, gy: 12 },
  { id: "pk_vial4", kind: "vial", gx: 34, gy: 4 },
  // collectible patient wristbands (optional, +40 score each)
  { id: "pk_wb1", kind: "wristband", gx: 9, gy: 21 },
  { id: "pk_wb2", kind: "wristband", gx: 2, gy: 10 },
  { id: "pk_wb3", kind: "wristband", gx: 34, gy: 23 },
  { id: "pk_wb4", kind: "wristband", gx: 15, gy: 12 },
  { id: "pk_wb5", kind: "wristband", gx: 28, gy: 5 },
  { id: "pk_wb6", kind: "wristband", gx: 33, gy: 13 },
];

// -------------------------------------------------------------- interactables
export interface InterDef { id: string; gx: number; gy: number; label: string }

export const INTERACTABLES: InterDef[] = [
  { id: "terminal", gx: 28, gy: 19, label: "Security terminal" },
  { id: "monitor", gx: 30, gy: 19, label: "Surveillance monitor" },
  { id: "fusebox", gx: 33, gy: 19, label: "Fuse box" },
  { id: "plaque", gx: 18, gy: 19, label: "Brass plaque" },
  { id: "chart", gx: 4, gy: 11, label: "Anna's chart" },
  { id: "incidentlog", gx: 25, gy: 5, label: "Incident log" },
  { id: "radio", gx: 29, gy: 4, label: "Old radio" },
  { id: "xray", gx: 33, gy: 3, label: "X-ray lightboard" },
  { id: "cabinet", gx: 14, gy: 2, label: "Word-lock cabinet" },
  { id: "recordsfile", gx: 13, gy: 4, label: "Staff file" },
  { id: "folder", gx: 25, gy: 11, label: "Director's folder" },
  { id: "drawer", gx: 26, gy: 12, label: "Desk drawer" },
  { id: "breaker", gx: 12, gy: 12, label: "Main breaker" },
  { id: "body9", gx: 13, gy: 11, label: "Body 9" },
  { id: "toetag", gx: 13, gy: 13, label: "Toe tag" },
];

// ------------------------------------------------------------------- cameras
export interface CamDef { name: string; gx: number; gy: number; tx: number; ty: number }

export const CAMERAS: CamDef[] = [
  { name: "CAM 1 · LOBBY", gx: 12, gy: 18, tx: 19, ty: 23 },
  { name: "CAM 2 · N. CORRIDOR", gx: 2, gy: 7, tx: 22, ty: 8 },
  { name: "CAM 3 · WARD A", gx: 10, gy: 10, tx: 3, ty: 12 },
  { name: "CAM 4 · MID CORRIDOR", gx: 33, gy: 15, tx: 14, ty: 16 },
  { name: "CAM 5 · SPINE / MORGUE", gx: 18, gy: 8, tx: 17, ty: 17 },
];

export const WAYPOINTS: [number, number][] = [
  [5, 7], [18, 7], [31, 8], [17, 3], [17, 12], [4, 15], [18, 16],
  [32, 15], [18, 21], [6, 21], [30, 20], [3, 3], [30, 3], [9, 12],
];

export const PLAYER_SPAWN = { gx: 18, gy: 23 };
export const CHECKPOINT = { gx: 30, gy: 21 };
export const ENEMY_SPAWN = { gx: 9, gy: 10 };

// ---------------------------------------------------------------------- grid
// cell codes: 0 wall, 1 floor, 2 door, 3 blocked (furniture/locker)

export function buildGrid(): Uint8Array {
  const g = new Uint8Array(GW * GH);
  for (const r of ROOMS)
    for (let y = r.y1; y <= r.y2; y++)
      for (let x = r.x1; x <= r.x2; x++) g[y * GW + x] = 1;
  for (const d of DOORS) g[d.gy * GW + d.gx] = 2;
  for (const f of FURNITURE) g[f.gy * GW + f.gx] = 3;
  for (const l of LOCKERS) g[l.gy * GW + l.gx] = 3;
  return g;
}
