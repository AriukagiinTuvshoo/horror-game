import { useCallback, useEffect, useRef, useState } from "react";
import { Engine, type GameEvent, type HudSnapshot, type SaveData } from "@/game/engine";
import {
  DEFAULT_SETTINGS, ANNA_QUESTION, RADIO_PUZZLE, PHARMACY_CODE, OFFICE_CODE,
  type Settings, type EndingId,
} from "@/game/content";
import { Hud, NotebookPanel, TouchControls, type Toast } from "@/ui/HUD";
import { DocReader, ChartPuzzle, KeypadPuzzle, RadioPuzzle, VocabMatchPuzzle, ChoiceDialog } from "@/ui/Puzzles";
import {
  TitleScreen, SettingsPanel, HowToPlay, CreditsPanel, ScoresPanel, PauseMenu, EndingScreen,
  type MenuPage, type ScoreEntry,
} from "@/ui/Menus";
import { tl, tr } from "@/game/i18n";

type Overlay =
  | { kind: "doc"; id: string; fromNotebook?: boolean }
  | { kind: "puzzle"; id: string }
  | { kind: "choice"; id: string }
  | { kind: "notebook" }
  | { kind: "pause" }
  | { kind: "settings" }
  | null;

const IS_TOUCH =
  typeof window !== "undefined" &&
  (window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window);

const ENDING_LABEL: Record<EndingId, string> = {
  escape: "ESCAPE", truth: "TRUTH", bad: "ADMITTED", secret: "SECRET ★",
};

function loadJSON<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch { return fallback; }
}

export default function App() {
  const [screen, setScreen] = useState<"menu" | "game">("menu");
  const [menuPage, setMenuPage] = useState<MenuPage>("home");
  const [settings, setSettings] = useState<Settings>(() => ({
    ...DEFAULT_SETTINGS,
    ...(IS_TOUCH ? { graphics: "low" as const } : {}),
    ...loadJSON("lns_settings", {}),
  }));
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadJSON("lns_scores", []));
  const [hasSave, setHasSave] = useState<boolean>(() => !!localStorage.getItem("lns_save"));

  const [snap, setSnap] = useState<HudSnapshot | null>(null);
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [ending, setEnding] = useState<EndingId | null>(null);
  const [results, setResults] = useState({ score: 0, timeMin: 0, catches: 0, evidence: 0, vocab: 0, missions: 0 });
  const [savedScore, setSavedScore] = useState(false);
  const [subtitle, setSubtitle] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [banner, setBanner] = useState<number | null>(null);
  const [caughtKey, setCaughtKey] = useState(0);
  const [staticKey, setStaticKey] = useState(0);
  const [sprintTouch, setSprintTouch] = useState(false);
  const [fadeIn, setFadeIn] = useState(false);
  const [locked, setLocked] = useState(false);
  const [lockHintOff, setLockHintOff] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const overlayRef = useRef<Overlay>(null);
  overlayRef.current = overlay;
  const endingRef = useRef<EndingId | null>(null);
  endingRef.current = ending;
  const pendingRef = useRef<{ mode: "new" } | { mode: "load"; save: SaveData }>({ mode: "new" });
  const toastId = useRef(0);
  const subtitleTimer = useRef<number>(0);
  const bannerTimer = useRef<number>(0);

  // -------------------------------------------------------------- settings
  const changeSettings = useCallback((s: Settings) => {
    setSettings(s);
    localStorage.setItem("lns_settings", JSON.stringify(s));
    engineRef.current?.applySettings(s);
  }, []);

  // ---------------------------------------------------------- engine events
  const handleEvent = useCallback((e: GameEvent) => {
    const eng = engineRef.current;
    switch (e.type) {
      case "mission":
        setBanner(e.index);
        window.clearTimeout(bannerTimer.current);
        bannerTimer.current = window.setTimeout(() => setBanner(null), 4200);
        break;
      case "openPuzzle":
        setOverlay({ kind: "puzzle", id: e.id });
        eng?.setPaused(true);
        break;
      case "openDoc":
        setOverlay({ kind: "doc", id: e.id });
        eng?.setPaused(true);
        break;
      case "choice":
        setOverlay({ kind: "choice", id: e.id });
        eng?.setPaused(true);
        break;
      case "subtitle":
        setSubtitle(tl(e.text, settingsRef.current.language));
        window.clearTimeout(subtitleTimer.current);
        subtitleTimer.current = window.setTimeout(() => setSubtitle(null), 6000);
        break;
      case "toast": {
        const id = ++toastId.current;
        setToasts((t) => [...t.slice(-4), { id, text: tl(e.text, settingsRef.current.language), kind: e.kind }]);
        window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4300);
        break;
      }
      case "caught":
        setCaughtKey((k) => k + 1);
        break;
      case "ending":
        if (eng) setResults(eng.getResults());
        setEnding(e.id);
        setOverlay(null);
        setSavedScore(false);
        localStorage.removeItem("lns_save");
        setHasSave(false);
        break;
      case "requestPause":
        if (!overlayRef.current && !endingRef.current) {
          setOverlay({ kind: "pause" });
          eng?.setPaused(true);
        }
        break;
      case "openNotebook":
        if (!endingRef.current) {
          setOverlay({ kind: "notebook" });
          eng?.setPaused(true);
        }
        break;
      case "checkpoint":
        if (eng && !endingRef.current) {
          try {
            localStorage.setItem("lns_save", JSON.stringify(eng.serialize()));
            setHasSave(true);
          } catch { /* storage full/blocked */ }
        }
        break;
      case "staticBurst":
        setStaticKey((k) => k + 1);
        break;
      case "cameraMode":
        break;
    }
  }, []);

  // ------------------------------------------------------------ game mount
  useEffect(() => {
    if (screen !== "game" || !containerRef.current) return;
    const eng = new Engine(containerRef.current, handleEvent);
    eng.touchMode = IS_TOUCH;
    eng.applySettings(settingsRef.current);
    engineRef.current = eng;
    setFadeIn(false);
    const ft = window.setTimeout(() => setFadeIn(true), 60);
    if (pendingRef.current.mode === "load") eng.loadGame(pendingRef.current.save);
    else eng.newGame(settingsRef.current.difficulty);
    const iv = window.setInterval(() => setSnap(eng.getSnapshot()), 100);
    setSnap(eng.getSnapshot());
    const onLock = () => setLocked(!!document.pointerLockElement);
    document.addEventListener("pointerlockchange", onLock);
    return () => {
      window.clearTimeout(ft);
      window.clearInterval(iv);
      document.removeEventListener("pointerlockchange", onLock);
      eng.dispose();
      engineRef.current = null;
      setSnap(null);
      setLocked(false);
    };
  }, [screen, handleEvent]);

  // ------------------------------------------------------------- key: ESC/N
  useEffect(() => {
    if (screen !== "game") return;
    const onKey = (e: KeyboardEvent) => {
      const ov = overlayRef.current;
      if (!ov) return;
      if (e.code === "Escape") {
        if (ov.kind === "doc") closeDoc(ov.id, ov.fromNotebook);
        else if (ov.kind === "notebook" || ov.kind === "puzzle") resume();
        else if (ov.kind === "pause") resume();
        else if (ov.kind === "settings") setOverlay({ kind: "pause" });
      }
      if (e.code === "KeyN" && ov.kind === "notebook") resume();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [screen]);

  // --------------------------------------------------------------- helpers
  const resume = () => {
    setOverlay(null);
    engineRef.current?.setPaused(false);
  };

  const closeDoc = (id: string, fromNotebook?: boolean) => {
    engineRef.current?.onDocClosed(id);
    if (fromNotebook) setOverlay({ kind: "notebook" });
    else resume();
  };

  const startNew = () => {
    localStorage.removeItem("lns_save");
    setHasSave(false);
    pendingRef.current = { mode: "new" };
    resetRunState();
    if (screen === "game" && engineRef.current) {
      engineRef.current.newGame(settingsRef.current.difficulty);
    } else setScreen("game");
  };

  const continueGame = () => {
    const save = loadJSON<SaveData | null>("lns_save", null);
    if (!save) return;
    pendingRef.current = { mode: "load", save };
    resetRunState();
    setScreen("game");
  };

  const resetRunState = () => {
    setEnding(null);
    setOverlay(null);
    setToasts([]);
    setSubtitle(null);
    setBanner(null);
    setSavedScore(false);
  };

  const toMenu = (clearSave = false) => {
    if (clearSave) { localStorage.removeItem("lns_save"); setHasSave(false); }
    resetRunState();
    setMenuPage("home");
    setScreen("menu");
  };

  const saveAndQuit = () => {
    const eng = engineRef.current;
    if (eng) {
      try { localStorage.setItem("lns_save", JSON.stringify(eng.serialize())); setHasSave(true); } catch { /* noop */ }
    }
    toMenu();
  };

  const saveScore = (name: string) => {
    if (!ending) return;
    localStorage.setItem("lns_name", name);
    const entry: ScoreEntry = {
      name, score: results.score, ending: ENDING_LABEL[ending],
      time: Math.min(results.timeMin, 360), date: new Date().toISOString(),
    };
    const next = [...scores, entry].sort((a, b) => b.score - a.score).slice(0, 10);
    setScores(next);
    localStorage.setItem("lns_scores", JSON.stringify(next));
    setSavedScore(true);
  };

  const restart = () => {
    resetRunState();
    engineRef.current?.newGame(settingsRef.current.difficulty);
  };

  // ------------------------------------------------------------ puzzle glue
  const eng = () => engineRef.current;
  const puzzleId = overlay?.kind === "puzzle" ? overlay.id : null;
  const keypadDoor = puzzleId?.startsWith("keypad:") ? puzzleId.slice(7) : null;

  // --------------------------------------------------------------- render
  if (screen === "menu") {
    if (menuPage === "settings") return <div className="relative h-full"><SettingsPanel settings={settings} onChange={changeSettings} onBack={() => setMenuPage("home")} /></div>;
    // eslint-disable-next-line react-hooks/rules-of-hooks
    if (menuPage === "howto") return <div className="relative h-full"><HowToPlay onBack={() => setMenuPage("home")} lang={settings.language} /></div>;
    if (menuPage === "credits") return <div className="relative h-full"><CreditsPanel onBack={() => setMenuPage("home")} lang={settings.language} /></div>;
    if (menuPage === "scores") return <div className="relative h-full"><ScoresPanel scores={scores} onBack={() => setMenuPage("home")} lang={settings.language} /></div>;
    return (
      <div className="relative h-full">
        <TitleScreen
          hasSave={hasSave}
          scores={scores}
          difficulty={settings.difficulty}
          avatar={settings.avatar}
          lang={settings.language}
          onDifficulty={(d) => changeSettings({ ...settings, difficulty: d })}
          onAvatar={(a) => changeSettings({ ...settings, avatar: a })}
          onLang={(l) => changeSettings({ ...settings, language: l })}
          onNew={startNew}
          onContinue={continueGame}
          go={setMenuPage}
        />
      </div>
    );
  }

  return (
    <div
      className="relative h-full w-full overflow-hidden bg-black"
      onContextMenu={(e) => e.preventDefault()}
      onPointerDown={() => eng()?.audio.init()}
    >
      <div ref={containerRef} className={`absolute inset-0 touch-none ${snap?.cameraMode ? "cam-filter" : ""}`} />
      <div className="grain pointer-events-none absolute inset-0 z-10" />

      {/* pointer-lock fallback */}
      {!IS_TOUCH && !locked && !lockHintOff && !overlay && !ending && snap && !snap.cameraMode && (
        <button
          onClick={() => { eng()?.lockPointer(); window.setTimeout(() => setLockHintOff(true), 350); }}
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/45"
        >
          <span className="rise-in border border-[#2b3d59] bg-black/80 px-6 py-4 text-center">
            <span className="block font-type text-xl text-[#eaf4ff]">{tr(settings.language, "clickControl")}</span>
            <span className="mt-1 block font-mono2 text-[11px] tracking-widest text-[#7d93ad]">{tr(settings.language, "camViewHint")}</span>
          </span>
        </button>
      )}

      {/* cinematic fade-in */}
      <div className={`pointer-events-none absolute inset-0 z-30 bg-black transition-opacity duration-[1400ms] ${fadeIn ? "opacity-0" : "opacity-100"}`} />

      {snap && (
        <Hud
          snap={snap}
          subtitle={subtitle}
          toasts={toasts}
          bannerMission={banner}
          caughtKey={caughtKey}
          staticKey={staticKey}
          showSubtitles={settings.subtitles}
          showMarker={settings.objectiveMarker}
          lang={settings.language}
          onAction={(name) => eng()?.action(name)}
        />
      )}

      {IS_TOUCH && !overlay && !ending && snap && !snap.cameraMode && (
        <TouchControls
          onMove={(x, y) => eng()?.setTouchMove(x, y)}
          onLook={(dx, dy) => eng()?.addTouchLook(dx, dy)}
          onAction={(name) => {
            if (name === "pause") { setOverlay({ kind: "pause" }); eng()?.setPaused(true); }
            else eng()?.action(name);
          }}
          sprint={sprintTouch}
          setSprint={(b) => { setSprintTouch(b); eng()?.setTouchSprint(b); }}
          lang={settings.language}
        />
      )}

      {/* touch pause fallback for camera mode is in HUD; also add a small pause hit-area for touch users when HUD visible */}
      {overlay?.kind === "doc" && snap && (
        <DocReader
          docId={overlay.id}
          difficulty={settings.difficulty}
          lang={settings.language}
          learned={snap.vocab}
          onLearn={(w) => eng()?.learnWord(w)}
          onClose={() => closeDoc(overlay.id, overlay.fromNotebook)}
        />
      )}

      {puzzleId === "chart" && snap && (
        <ChartPuzzle
          difficulty={settings.difficulty}
          lang={settings.language}
          learned={snap.vocab}
          onLearn={(w) => eng()?.learnWord(w)}
          onAnswer={(idx) => {
            const ok = idx === ANNA_QUESTION[settings.difficulty].answer;
            eng()?.resolvePuzzle("chart", ok);
            if (ok) resume();
            return ok;
          }}
          onHint={() => eng()?.hintUsed()}
          onClose={resume}
        />
      )}

      {keypadDoor && snap && (
        <KeypadPuzzle
          title={keypadDoor === "d_pharmacy" ? tr(settings.language, "pharmacyKeypad") : tr(settings.language, "officeKeypad")}
          lang={settings.language}
          codeHint={
            keypadDoor === "d_pharmacy" && snap.codePharmacyKnown ? PHARMACY_CODE
            : keypadDoor === "d_office" && snap.codeOfficeKnown ? OFFICE_CODE
            : undefined
          }
          onSubmit={(code) => {
            const ok = eng()?.tryKeypad(keypadDoor, code) ?? false;
            if (ok) resume();
            return ok;
          }}
          onClose={resume}
        />
      )}

      {puzzleId === "radio" && (
        <RadioPuzzle
          voiceOn={settings.voice}
          lang={settings.language}
          onPlay={(done) => {
            const e = eng();
            if (!e) { done(); return; }
            e.audio.staticBurst(0.8);
            let finished = false;
            const finish = () => { if (!finished) { finished = true; done(); } };
            window.setTimeout(() => e.audio.speak(RADIO_PUZZLE.spoken, finish), 500);
            window.setTimeout(finish, 11000);
          }}
          onAnswer={(idx) => {
            const ok = idx === RADIO_PUZZLE.answer;
            eng()?.resolvePuzzle("radio", ok);
            if (ok) resume();
            return ok;
          }}
          onHint={() => eng()?.hintUsed()}
          onClose={resume}
        />
      )}

      {puzzleId === "cabinet" && (
        <VocabMatchPuzzle
          lang={settings.language}
          onComplete={() => { eng()?.resolvePuzzle("cabinet", true); resume(); }}
          onStrike={() => eng()?.resolvePuzzle("cabinet", false)}
          onHint={() => eng()?.hintUsed()}
          onClose={resume}
        />
      )}

      {overlay?.kind === "choice" && (
        <ChoiceDialog
          id={overlay.id}
          lang={settings.language}
          onChoose={(c) => { eng()?.makeChoice(overlay.id, c); resume(); }}
        />
      )}

      {overlay?.kind === "notebook" && snap && (
        <NotebookPanel
          snap={snap}
          lang={settings.language}
          onClose={resume}
          onOpenDoc={(id) => setOverlay({ kind: "doc", id, fromNotebook: true })}
          onQuizReward={(w) => eng()?.quizReward(w)}
          onHint={() => eng()?.hintUsed()}
        />
      )}

      {overlay?.kind === "pause" && (
        <PauseMenu
          lang={settings.language}
          onResume={resume}
          onSettings={() => setOverlay({ kind: "settings" })}
          onRestart={restart}
          onSaveQuit={saveAndQuit}
          onQuit={() => toMenu(true)}
        />
      )}

      {overlay?.kind === "settings" && (
        <SettingsPanel settings={settings} onChange={changeSettings} onBack={() => setOverlay({ kind: "pause" })} />
      )}

      {ending && (
        <div className="absolute inset-0 z-50">
          <EndingScreen
            endingId={ending}
            lang={settings.language}
            results={results}
            scores={scores}
            saved={savedScore}
            onSaveScore={saveScore}
            onRestart={restart}
            onMenu={() => toMenu()}
          />
        </div>
      )}
    </div>
  );
}
